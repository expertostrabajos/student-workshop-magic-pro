-- Enable RLS on work_orders_safe view
ALTER VIEW public.work_orders_safe SET (security_invoker = on);

-- Enable RLS on the view (views need special handling)
-- First, let's recreate the view with proper security
DROP VIEW IF EXISTS public.work_orders_safe;

-- Recreate the view with security_invoker
CREATE VIEW public.work_orders_safe
WITH (security_invoker = on) AS
SELECT 
    id,
    order_number,
    title,
    description,
    subject,
    work_type,
    academic_level,
    word_count,
    status,
    deadline,
    created_at,
    updated_at,
    delivered_at,
    archived_at,
    price,
    paid_amount,
    payment_date,
    payment_method,
    rejection_reason,
    specific_requirements,
    assigned_expert_id,
    assigned_expert_name,
    client_id,
    -- Only show PII if user is admin or the owner
    CASE 
        WHEN is_admin() OR client_id = auth.uid() THEN client_name
        ELSE 'Confidencial'
    END as client_name,
    CASE 
        WHEN is_admin() OR client_id = auth.uid() THEN client_email
        ELSE 'Confidencial'
    END as client_email,
    CASE 
        WHEN is_admin() OR client_id = auth.uid() THEN client_phone
        ELSE NULL
    END as client_phone
FROM public.work_orders
WHERE 
    -- Users can only see their own orders, admins see all
    is_admin() OR client_id = auth.uid();