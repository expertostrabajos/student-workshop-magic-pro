-- Habilitar RLS en la vista work_orders_safe
ALTER VIEW public.work_orders_safe SET (security_barrier = true);

-- Crear políticas RLS para la vista
-- Nota: Las vistas con security_invoker heredan RLS de tablas base,
-- pero agregaremos una capa adicional de seguridad

-- Primero, recrear la vista con restricción de autenticación
DROP VIEW IF EXISTS public.work_orders_safe;

CREATE VIEW public.work_orders_safe
WITH (security_invoker = on) AS
SELECT 
    id,
    order_number,
    title,
    description,
    subject,
    work_type,
    academic_level,
    word_count,
    status,
    deadline,
    price,
    paid_amount,
    payment_date,
    payment_method,
    assigned_expert_id,
    assigned_expert_name,
    client_id,
    -- Enmascarar PII para no-admins y no-propietarios
    CASE 
        WHEN is_admin() OR auth.uid() = client_id THEN client_name 
        ELSE '***' 
    END AS client_name,
    CASE 
        WHEN is_admin() OR auth.uid() = client_id THEN client_email 
        ELSE '***@***.***' 
    END AS client_email,
    CASE 
        WHEN is_admin() OR auth.uid() = client_id THEN client_phone 
        ELSE '***-***-****' 
    END AS client_phone,
    specific_requirements,
    rejection_reason,
    created_at,
    updated_at,
    delivered_at,
    archived_at
FROM public.work_orders
WHERE auth.uid() IS NOT NULL;