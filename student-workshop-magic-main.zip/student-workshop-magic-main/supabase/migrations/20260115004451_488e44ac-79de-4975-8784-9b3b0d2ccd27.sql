-- Agregar políticas de seguridad faltantes

-- Política DELETE para work_orders (solo admins)
CREATE POLICY "Only admins can delete orders"
ON public.work_orders
FOR DELETE
USING (is_admin());

-- Políticas para work_order_history (hacer inmutable)
CREATE POLICY "No one can update history"
ON public.work_order_history
FOR UPDATE
USING (false);

CREATE POLICY "Only admins can delete history"
ON public.work_order_history
FOR DELETE
USING (is_admin());

-- Políticas para work_order_files
CREATE POLICY "Experts can update own uploaded files"
ON public.work_order_files
FOR UPDATE
USING (
    uploaded_by = auth.uid()::text OR is_admin()
);

CREATE POLICY "Experts can delete own uploaded files"
ON public.work_order_files
FOR DELETE
USING (
    uploaded_by = auth.uid()::text OR is_admin()
);

-- Políticas para user_roles (prevenir escalación de privilegios)
CREATE POLICY "No self-service role creation"
ON public.user_roles
FOR INSERT
WITH CHECK (is_admin());

CREATE POLICY "No self-service role updates"
ON public.user_roles
FOR UPDATE
USING (is_admin());

CREATE POLICY "No self-service role deletion"
ON public.user_roles
FOR DELETE
USING (is_admin());