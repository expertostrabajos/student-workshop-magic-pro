-- Create a secure view for clients that hides sensitive data from other clients' orders
-- This view only shows the client's own sensitive data, not others'

CREATE OR REPLACE VIEW public.work_orders_safe
WITH (security_invoker = on) AS
SELECT 
    id,
    order_number,
    title,
    description,
    work_type,
    subject,
    academic_level,
    word_count,
    status,
    deadline,
    price,
    paid_amount,
    payment_date,
    payment_method,
    assigned_expert_name,
    specific_requirements,
    rejection_reason,
    delivered_at,
    archived_at,
    created_at,
    updated_at,
    client_id,
    assigned_expert_id,
    -- Only show sensitive client data if user is the owner OR is an admin
    CASE 
        WHEN client_id = auth.uid() OR is_admin() THEN client_name
        ELSE NULL
    END as client_name,
    CASE 
        WHEN client_id = auth.uid() OR is_admin() THEN client_email
        ELSE NULL
    END as client_email,
    CASE 
        WHEN client_id = auth.uid() OR is_admin() THEN client_phone
        ELSE NULL
    END as client_phone
FROM public.work_orders;

-- Grant access to the view
GRANT SELECT ON public.work_orders_safe TO authenticated;

-- Add comment for documentation
COMMENT ON VIEW public.work_orders_safe IS 'Secure view of work_orders that hides sensitive client data (name, email, phone) from non-owners and non-admins';