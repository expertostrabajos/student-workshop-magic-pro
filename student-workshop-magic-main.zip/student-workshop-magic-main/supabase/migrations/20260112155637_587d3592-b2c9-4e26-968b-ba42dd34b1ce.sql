-- Crear tabla de órdenes de trabajo
CREATE TABLE public.work_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    subject TEXT NOT NULL,
    work_type TEXT NOT NULL,
    academic_level TEXT NOT NULL,
    word_count TEXT,
    deadline TIMESTAMP WITH TIME ZONE NOT NULL,
    status TEXT NOT NULL DEFAULT 'created' CHECK (status IN ('created', 'pending_payment', 'paid', 'assigned', 'in_progress', 'review', 'rejected', 'approved', 'delivered', 'archived')),
    client_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    client_name TEXT NOT NULL,
    client_email TEXT NOT NULL,
    client_phone TEXT,
    assigned_expert_id UUID,
    assigned_expert_name TEXT,
    price DECIMAL(12, 2),
    paid_amount DECIMAL(12, 2),
    payment_method TEXT,
    payment_date TIMESTAMP WITH TIME ZONE,
    rejection_reason TEXT,
    specific_requirements TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    delivered_at TIMESTAMP WITH TIME ZONE,
    archived_at TIMESTAMP WITH TIME ZONE
);

-- Crear tabla de historial de transiciones
CREATE TABLE public.work_order_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    work_order_id UUID NOT NULL REFERENCES public.work_orders(id) ON DELETE CASCADE,
    from_status TEXT NOT NULL,
    to_status TEXT NOT NULL,
    performed_by TEXT NOT NULL,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Crear tabla de archivos adjuntos
CREATE TABLE public.work_order_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    work_order_id UUID NOT NULL REFERENCES public.work_orders(id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    file_url TEXT NOT NULL,
    file_type TEXT NOT NULL CHECK (file_type IN ('attachment', 'deliverable')),
    uploaded_by TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Índices para mejorar rendimiento
CREATE INDEX idx_work_orders_status ON public.work_orders(status);
CREATE INDEX idx_work_orders_client_id ON public.work_orders(client_id);
CREATE INDEX idx_work_orders_deadline ON public.work_orders(deadline);
CREATE INDEX idx_work_order_history_work_order_id ON public.work_order_history(work_order_id);
CREATE INDEX idx_work_order_files_work_order_id ON public.work_order_files(work_order_id);

-- Habilitar RLS
ALTER TABLE public.work_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.work_order_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.work_order_files ENABLE ROW LEVEL SECURITY;

-- Función para verificar si el usuario es admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.user_roles 
        WHERE user_id = auth.uid() 
        AND role = 'admin'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Crear tipo de rol si no existe
DO $$ BEGIN
    CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Crear tabla de roles de usuario
CREATE TABLE IF NOT EXISTS public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para work_orders
-- Los clientes pueden ver sus propias órdenes
CREATE POLICY "Clients can view own orders" ON public.work_orders
    FOR SELECT USING (auth.uid() = client_id);

-- Los admins pueden ver todas las órdenes
CREATE POLICY "Admins can view all orders" ON public.work_orders
    FOR SELECT USING (public.is_admin());

-- Los admins pueden insertar órdenes
CREATE POLICY "Admins can insert orders" ON public.work_orders
    FOR INSERT WITH CHECK (public.is_admin());

-- Los clientes pueden crear sus propias órdenes
CREATE POLICY "Clients can create own orders" ON public.work_orders
    FOR INSERT WITH CHECK (auth.uid() = client_id);

-- Los admins pueden actualizar cualquier orden
CREATE POLICY "Admins can update all orders" ON public.work_orders
    FOR UPDATE USING (public.is_admin());

-- Políticas RLS para work_order_history
CREATE POLICY "Anyone can view order history for their orders" ON public.work_order_history
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.work_orders 
            WHERE id = work_order_id 
            AND (client_id = auth.uid() OR public.is_admin())
        )
    );

CREATE POLICY "Admins can insert history" ON public.work_order_history
    FOR INSERT WITH CHECK (public.is_admin());

-- Políticas RLS para work_order_files
CREATE POLICY "Anyone can view files for their orders" ON public.work_order_files
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.work_orders 
            WHERE id = work_order_id 
            AND (client_id = auth.uid() OR public.is_admin())
        )
    );

CREATE POLICY "Admins can manage files" ON public.work_order_files
    FOR ALL USING (public.is_admin());

-- Políticas para user_roles
CREATE POLICY "Users can view own roles" ON public.user_roles
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage roles" ON public.user_roles
    FOR ALL USING (public.is_admin());

-- Trigger para actualizar updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_work_orders_updated_at
    BEFORE UPDATE ON public.work_orders
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Función para generar número de orden
CREATE OR REPLACE FUNCTION public.generate_order_number()
RETURNS TRIGGER AS $$
DECLARE
    year_part TEXT;
    seq_num INT;
BEGIN
    year_part := to_char(now(), 'YYYY');
    SELECT COALESCE(MAX(CAST(SUBSTRING(order_number FROM 10) AS INT)), 0) + 1
    INTO seq_num
    FROM public.work_orders
    WHERE order_number LIKE 'ORD-' || year_part || '-%';
    
    NEW.order_number := 'ORD-' || year_part || '-' || LPAD(seq_num::TEXT, 4, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER generate_work_order_number
    BEFORE INSERT ON public.work_orders
    FOR EACH ROW
    WHEN (NEW.order_number IS NULL OR NEW.order_number = '')
    EXECUTE FUNCTION public.generate_order_number();

-- Habilitar realtime para work_orders
ALTER PUBLICATION supabase_realtime ADD TABLE public.work_orders;