-- Función de validación para work_orders
CREATE OR REPLACE FUNCTION public.validate_work_order()
RETURNS TRIGGER AS $$
BEGIN
    -- Validar precio (debe ser no negativo)
    IF NEW.price IS NOT NULL AND NEW.price < 0 THEN
        RAISE EXCEPTION 'El precio no puede ser negativo: %', NEW.price;
    END IF;
    
    -- Validar monto pagado (debe ser no negativo)
    IF NEW.paid_amount IS NOT NULL AND NEW.paid_amount < 0 THEN
        RAISE EXCEPTION 'El monto pagado no puede ser negativo: %', NEW.paid_amount;
    END IF;
    
    -- Validar que el monto pagado no exceda el precio
    IF NEW.paid_amount IS NOT NULL AND NEW.price IS NOT NULL AND NEW.paid_amount > NEW.price THEN
        RAISE EXCEPTION 'El monto pagado (%) no puede exceder el precio (%)', NEW.paid_amount, NEW.price;
    END IF;
    
    -- Validar email del cliente (formato básico)
    IF NEW.client_email IS NOT NULL AND NEW.client_email !~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
        RAISE EXCEPTION 'Email inválido: %', NEW.client_email;
    END IF;
    
    -- Validar longitud del título (1-500 caracteres)
    IF NEW.title IS NULL OR length(trim(NEW.title)) < 1 THEN
        RAISE EXCEPTION 'El título no puede estar vacío';
    END IF;
    
    IF length(NEW.title) > 500 THEN
        RAISE EXCEPTION 'El título excede el límite de 500 caracteres (actual: %)', length(NEW.title);
    END IF;
    
    -- Validar longitud de descripción (máximo 10000 caracteres)
    IF NEW.description IS NOT NULL AND length(NEW.description) > 10000 THEN
        RAISE EXCEPTION 'La descripción excede el límite de 10000 caracteres (actual: %)', length(NEW.description);
    END IF;
    
    -- Validar que la fecha límite no sea en el pasado (solo para nuevos registros)
    IF TG_OP = 'INSERT' AND NEW.deadline < now() - interval '1 hour' THEN
        RAISE EXCEPTION 'La fecha límite no puede ser en el pasado: %', NEW.deadline;
    END IF;
    
    -- Validar teléfono del cliente (si se proporciona, debe tener formato válido)
    IF NEW.client_phone IS NOT NULL AND length(NEW.client_phone) > 0 THEN
        -- Eliminar espacios y caracteres comunes para validar longitud
        IF length(regexp_replace(NEW.client_phone, '[^0-9]', '', 'g')) < 7 THEN
            RAISE EXCEPTION 'El teléfono debe tener al menos 7 dígitos: %', NEW.client_phone;
        END IF;
        IF length(regexp_replace(NEW.client_phone, '[^0-9]', '', 'g')) > 15 THEN
            RAISE EXCEPTION 'El teléfono no puede tener más de 15 dígitos: %', NEW.client_phone;
        END IF;
    END IF;
    
    -- Validar nombre del cliente
    IF NEW.client_name IS NULL OR length(trim(NEW.client_name)) < 2 THEN
        RAISE EXCEPTION 'El nombre del cliente debe tener al menos 2 caracteres';
    END IF;
    
    IF length(NEW.client_name) > 200 THEN
        RAISE EXCEPTION 'El nombre del cliente excede el límite de 200 caracteres';
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Crear trigger para validar work_orders
DROP TRIGGER IF EXISTS validate_work_order_trigger ON public.work_orders;
CREATE TRIGGER validate_work_order_trigger
    BEFORE INSERT OR UPDATE ON public.work_orders
    FOR EACH ROW
    EXECUTE FUNCTION public.validate_work_order();

-- Agregar comentarios descriptivos
COMMENT ON FUNCTION public.validate_work_order() IS 'Valida campos críticos de work_orders: precio, email, título, descripción, teléfono y nombre del cliente';