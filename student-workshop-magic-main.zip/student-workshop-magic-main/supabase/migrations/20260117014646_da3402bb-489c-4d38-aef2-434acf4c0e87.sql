-- Tabla para gestionar revisores/expertos
CREATE TABLE public.reviewers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    specialty TEXT NOT NULL,
    current_workload INTEGER NOT NULL DEFAULT 0,
    completed_works INTEGER NOT NULL DEFAULT 0,
    average_quality NUMERIC(3,1) DEFAULT 0.0,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    CONSTRAINT valid_quality CHECK (average_quality >= 0 AND average_quality <= 10),
    CONSTRAINT valid_workload CHECK (current_workload >= 0),
    CONSTRAINT valid_completed CHECK (completed_works >= 0)
);

-- Habilitar RLS
ALTER TABLE public.reviewers ENABLE ROW LEVEL SECURITY;

-- Solo admins pueden ver todos los revisores
CREATE POLICY "Admins can view all reviewers"
ON public.reviewers FOR SELECT
USING (is_admin());

-- Solo admins pueden crear revisores
CREATE POLICY "Admins can insert reviewers"
ON public.reviewers FOR INSERT
WITH CHECK (is_admin());

-- Solo admins pueden actualizar revisores
CREATE POLICY "Admins can update reviewers"
ON public.reviewers FOR UPDATE
USING (is_admin());

-- Solo admins pueden eliminar revisores
CREATE POLICY "Admins can delete reviewers"
ON public.reviewers FOR DELETE
USING (is_admin());

-- Trigger para actualizar updated_at
CREATE TRIGGER update_reviewers_updated_at
    BEFORE UPDATE ON public.reviewers
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Comentario descriptivo
COMMENT ON TABLE public.reviewers IS 'Tabla de revisores/expertos que pueden ser asignados a órdenes de trabajo';