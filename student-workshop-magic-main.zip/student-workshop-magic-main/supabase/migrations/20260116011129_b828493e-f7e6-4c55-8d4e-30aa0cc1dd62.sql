-- Agregar política UPDATE para que clientes puedan actualizar sus propias órdenes
CREATE POLICY "Clients can update own orders"
ON public.work_orders
FOR UPDATE
USING (auth.uid() = client_id)
WITH CHECK (auth.uid() = client_id);