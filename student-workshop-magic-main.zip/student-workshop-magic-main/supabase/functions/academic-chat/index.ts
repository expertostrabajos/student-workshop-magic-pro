import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = `Eres un asistente académico virtual de StudentHelp, la plataforma #1 en Colombia para ayuda con trabajos académicos. Tu rol es:

1. Responder preguntas académicas sobre cualquier materia (matemáticas, ciencias, literatura, historia, programación, etc.)
2. Explicar conceptos difíciles de manera clara, usando analogías y ejemplos prácticos
3. Dar consejos sobre técnicas de estudio, organización del tiempo y productividad
4. Orientar sobre cómo estructurar trabajos académicos (ensayos, tesis, informes, presentaciones)
5. Resolver ejercicios paso a paso cuando el estudiante lo necesite
6. Proporcionar información sobre los servicios de StudentHelp cuando sea relevante

Directrices de formato:
- Responde siempre en español
- Usa **markdown** para formatear tus respuestas: negritas, listas, encabezados, bloques de código cuando aplique
- Sé amable, paciente y motivador
- Usa ejemplos prácticos y analogías cotidianas
- Si no sabes algo, admítelo honestamente
- Mantén las respuestas completas pero bien organizadas

Información de StudentHelp:
- Ayuda con ensayos, trabajos de investigación, presentaciones, tesis y más
- Precios desde $2.500 COP (ensayos cortos) hasta $10.000 COP (proyectos completos)
- Pagos por Nequi al +57 3142135852
- Tiempos de entrega: 3-5 días (trabajos cortos), 1-2 semanas (proyectos extensos)
- Garantía de calidad y revisiones incluidas`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "openai/gpt-5",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Límite de solicitudes excedido, intenta más tarde." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Se requiere agregar créditos a la cuenta." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(JSON.stringify({ error: "Error en el servicio de IA" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("academic-chat error:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Error desconocido" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
