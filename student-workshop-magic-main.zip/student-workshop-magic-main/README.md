
# Welcome to your Lovable project

## Project info

**URL**: https://lovable.dev/projects/6ebf7f10-0bb4-4f73-988d-1183cddde5f9

## How can I edit this code?

There are several ways of editing your application.

**Use Lovable**

Simply visit the [Lovable Project](https://lovable.dev/projects/6ebf7f10-0bb4-4f73-988d-1183cddde5f9) and start prompting.

Changes made via Lovable will be committed automatically to this repo.

**Use your preferred IDE**

If you want to work locally using your own IDE, you can clone this repo and push changes. Pushed changes will also be reflected in Lovable.

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Follow these steps:

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start the development server with auto-reloading and an instant preview.
npm run dev
```

> **IMPORTANT NOTE FOR LOCAL DEVELOPMENT**:
> This project is designed to be run using a development server. Opening the index.html file directly in a browser will result in CORS errors and missing resources.
>
> Always use `npm run dev` to start the development server, which will serve the files properly and prevent CORS issues.
>
> If you encounter 404 errors for files like index-*.js, index-*.css, or image files, this is because these files are generated during the build process and are not present in the source code.

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How can I deploy this project?

Simply open [Lovable](https://lovable.dev/projects/6ebf7f10-0bb4-4f73-988d-1183cddde5f9) and click on Share -> Publish.

## I want to use a custom domain - is that possible?

We don't support custom domains (yet). If you want to deploy your project under your own domain then we recommend using Netlify. Visit our docs for more details: [Custom domains](https://docs.lovable.dev/tips-tricks/custom-domain/)

## Troubleshooting

If you encounter any issues while running the project:

1. **Missing JavaScript and CSS files**: Files like `index-*.js` and `index-*.css` are generated during the build process. They won't exist until you run `npm run dev` or `npm run build`.

2. **CORS Errors**: If you're seeing CORS errors in the console, make sure you're accessing the project through the development server (`npm run dev`) rather than opening the HTML file directly.

3. **Missing Images**: Make sure all image paths are relative to the project root when using the development server.

4. **GPT Engineer Script**: The script at `https://cdn.gpteng.co/gptengineer.js` is needed for the Lovable environment but might not be necessary for local development. The error handler will let the site function without it.
