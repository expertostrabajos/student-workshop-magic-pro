// Tipos para el sistema de órdenes de trabajo con máquina de estados

export type WorkOrderStatus = 
  | 'created'        // Recién creado
  | 'pending_payment' // Pendiente de pago
  | 'paid'           // Pagado
  | 'assigned'       // Asignado a un experto
  | 'in_progress'    // En proceso de elaboración
  | 'review'         // En revisión por el cliente
  | 'rejected'       // Rechazado (requiere correcciones)
  | 'approved'       // Aprobado por el cliente
  | 'delivered'      // Entregado
  | 'archived';      // Archivado

export interface WorkOrderTransition {
  from: WorkOrderStatus;
  to: WorkOrderStatus;
  label: string;
  requiresApproval?: boolean;
  requiresPayment?: boolean;
}

export interface WorkOrder {
  id: string;
  orderNumber: string;
  title: string;
  description: string;
  subject: string;
  workType: string;
  academicLevel: string;
  wordCount: string;
  specificRequirements?: string;
  deadline: Date;
  status: WorkOrderStatus;
  clientId: string;
  clientName: string;
  clientEmail: string;
  clientPhone?: string;
  assignedExpertId?: string;
  assignedExpertName?: string;
  price?: number;
  paidAmount?: number;
  paymentMethod?: string;
  paymentDate?: Date;
  createdAt: Date;
  updatedAt: Date;
  deliveredAt?: Date;
  archivedAt?: Date;
  rejectionReason?: string;
  files?: WorkOrderFile[];
  history: WorkOrderHistoryEntry[];
}

export interface WorkOrderFile {
  id: string;
  name: string;
  url: string;
  type: 'attachment' | 'deliverable';
  uploadedAt: Date;
  uploadedBy: string;
}

export interface WorkOrderHistoryEntry {
  id: string;
  timestamp: Date;
  fromStatus: WorkOrderStatus;
  toStatus: WorkOrderStatus;
  performedBy: string;
  notes?: string;
}

// Definición de transiciones válidas
export const VALID_TRANSITIONS: WorkOrderTransition[] = [
  { from: 'created', to: 'pending_payment', label: 'Enviar a pago' },
  { from: 'pending_payment', to: 'paid', label: 'Confirmar pago', requiresPayment: true },
  { from: 'pending_payment', to: 'created', label: 'Volver a creación' },
  { from: 'paid', to: 'assigned', label: 'Asignar experto' },
  { from: 'assigned', to: 'in_progress', label: 'Iniciar trabajo' },
  { from: 'in_progress', to: 'review', label: 'Enviar a revisión' },
  { from: 'review', to: 'approved', label: 'Aprobar trabajo', requiresApproval: true },
  { from: 'review', to: 'rejected', label: 'Solicitar correcciones', requiresApproval: true },
  { from: 'rejected', to: 'in_progress', label: 'Reanudar correcciones' },
  { from: 'approved', to: 'delivered', label: 'Marcar como entregado' },
  { from: 'delivered', to: 'archived', label: 'Archivar trabajo' },
];

// Configuración de estados
export const STATUS_CONFIG: Record<WorkOrderStatus, {
  label: string;
  color: string;
  bgColor: string;
  icon: string;
  description: string;
}> = {
  created: {
    label: 'Recién Creado',
    color: 'text-gray-700',
    bgColor: 'bg-gray-100',
    icon: 'FileText',
    description: 'La solicitud ha sido recibida y está pendiente de cotización'
  },
  pending_payment: {
    label: 'Pendiente de Pago',
    color: 'text-yellow-700',
    bgColor: 'bg-yellow-100',
    icon: 'CreditCard',
    description: 'Esperando confirmación del pago del cliente'
  },
  paid: {
    label: 'Pagado',
    color: 'text-emerald-700',
    bgColor: 'bg-emerald-100',
    icon: 'CheckCircle',
    description: 'Pago confirmado, pendiente de asignación'
  },
  assigned: {
    label: 'Asignado',
    color: 'text-blue-700',
    bgColor: 'bg-blue-100',
    icon: 'UserCheck',
    description: 'Un experto ha sido asignado al trabajo'
  },
  in_progress: {
    label: 'En Proceso',
    color: 'text-indigo-700',
    bgColor: 'bg-indigo-100',
    icon: 'Clock',
    description: 'El trabajo está siendo elaborado'
  },
  review: {
    label: 'En Revisión',
    color: 'text-purple-700',
    bgColor: 'bg-purple-100',
    icon: 'Eye',
    description: 'El cliente está revisando el trabajo'
  },
  rejected: {
    label: 'Rechazado',
    color: 'text-red-700',
    bgColor: 'bg-red-100',
    icon: 'XCircle',
    description: 'El cliente solicitó correcciones'
  },
  approved: {
    label: 'Aprobado',
    color: 'text-green-700',
    bgColor: 'bg-green-100',
    icon: 'ThumbsUp',
    description: 'El trabajo ha sido aprobado por el cliente'
  },
  delivered: {
    label: 'Entregado',
    color: 'text-teal-700',
    bgColor: 'bg-teal-100',
    icon: 'Package',
    description: 'El trabajo ha sido entregado al cliente'
  },
  archived: {
    label: 'Archivado',
    color: 'text-slate-700',
    bgColor: 'bg-slate-100',
    icon: 'Archive',
    description: 'El trabajo ha sido archivado'
  }
};

// Función para obtener transiciones válidas desde un estado
export function getValidTransitions(currentStatus: WorkOrderStatus): WorkOrderTransition[] {
  return VALID_TRANSITIONS.filter(t => t.from === currentStatus);
}

// Función para verificar si una transición es válida
export function isValidTransition(from: WorkOrderStatus, to: WorkOrderStatus): boolean {
  return VALID_TRANSITIONS.some(t => t.from === from && t.to === to);
}

// Orden de estados para visualización
export const STATUS_ORDER: WorkOrderStatus[] = [
  'created',
  'pending_payment',
  'paid',
  'assigned',
  'in_progress',
  'review',
  'approved',
  'delivered',
  'archived'
];

// Estados alternativos (fuera del flujo principal)
export const ALTERNATIVE_STATUSES: WorkOrderStatus[] = ['rejected'];
