export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      reviewers: {
        Row: {
          average_quality: number | null
          completed_works: number
          created_at: string
          current_workload: number
          email: string
          id: string
          is_active: boolean
          name: string
          specialty: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          average_quality?: number | null
          completed_works?: number
          created_at?: string
          current_workload?: number
          email: string
          id?: string
          is_active?: boolean
          name: string
          specialty: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          average_quality?: number | null
          completed_works?: number
          created_at?: string
          current_workload?: number
          email?: string
          id?: string
          is_active?: boolean
          name?: string
          specialty?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      work_order_files: {
        Row: {
          created_at: string
          file_name: string
          file_type: string
          file_url: string
          id: string
          uploaded_by: string
          work_order_id: string
        }
        Insert: {
          created_at?: string
          file_name: string
          file_type: string
          file_url: string
          id?: string
          uploaded_by: string
          work_order_id: string
        }
        Update: {
          created_at?: string
          file_name?: string
          file_type?: string
          file_url?: string
          id?: string
          uploaded_by?: string
          work_order_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "work_order_files_work_order_id_fkey"
            columns: ["work_order_id"]
            isOneToOne: false
            referencedRelation: "work_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_order_files_work_order_id_fkey"
            columns: ["work_order_id"]
            isOneToOne: false
            referencedRelation: "work_orders_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      work_order_history: {
        Row: {
          created_at: string
          from_status: string
          id: string
          notes: string | null
          performed_by: string
          to_status: string
          work_order_id: string
        }
        Insert: {
          created_at?: string
          from_status: string
          id?: string
          notes?: string | null
          performed_by: string
          to_status: string
          work_order_id: string
        }
        Update: {
          created_at?: string
          from_status?: string
          id?: string
          notes?: string | null
          performed_by?: string
          to_status?: string
          work_order_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "work_order_history_work_order_id_fkey"
            columns: ["work_order_id"]
            isOneToOne: false
            referencedRelation: "work_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_order_history_work_order_id_fkey"
            columns: ["work_order_id"]
            isOneToOne: false
            referencedRelation: "work_orders_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      work_orders: {
        Row: {
          academic_level: string
          archived_at: string | null
          assigned_expert_id: string | null
          assigned_expert_name: string | null
          client_email: string
          client_id: string | null
          client_name: string
          client_phone: string | null
          created_at: string
          deadline: string
          delivered_at: string | null
          description: string | null
          id: string
          order_number: string
          paid_amount: number | null
          payment_date: string | null
          payment_method: string | null
          price: number | null
          rejection_reason: string | null
          specific_requirements: string | null
          status: string
          subject: string
          title: string
          updated_at: string
          word_count: string | null
          work_type: string
        }
        Insert: {
          academic_level: string
          archived_at?: string | null
          assigned_expert_id?: string | null
          assigned_expert_name?: string | null
          client_email: string
          client_id?: string | null
          client_name: string
          client_phone?: string | null
          created_at?: string
          deadline: string
          delivered_at?: string | null
          description?: string | null
          id?: string
          order_number: string
          paid_amount?: number | null
          payment_date?: string | null
          payment_method?: string | null
          price?: number | null
          rejection_reason?: string | null
          specific_requirements?: string | null
          status?: string
          subject: string
          title: string
          updated_at?: string
          word_count?: string | null
          work_type: string
        }
        Update: {
          academic_level?: string
          archived_at?: string | null
          assigned_expert_id?: string | null
          assigned_expert_name?: string | null
          client_email?: string
          client_id?: string | null
          client_name?: string
          client_phone?: string | null
          created_at?: string
          deadline?: string
          delivered_at?: string | null
          description?: string | null
          id?: string
          order_number?: string
          paid_amount?: number | null
          payment_date?: string | null
          payment_method?: string | null
          price?: number | null
          rejection_reason?: string | null
          specific_requirements?: string | null
          status?: string
          subject?: string
          title?: string
          updated_at?: string
          word_count?: string | null
          work_type?: string
        }
        Relationships: []
      }
    }
    Views: {
      work_orders_safe: {
        Row: {
          academic_level: string | null
          archived_at: string | null
          assigned_expert_id: string | null
          assigned_expert_name: string | null
          client_email: string | null
          client_id: string | null
          client_name: string | null
          client_phone: string | null
          created_at: string | null
          deadline: string | null
          delivered_at: string | null
          description: string | null
          id: string | null
          order_number: string | null
          paid_amount: number | null
          payment_date: string | null
          payment_method: string | null
          price: number | null
          rejection_reason: string | null
          specific_requirements: string | null
          status: string | null
          subject: string | null
          title: string | null
          updated_at: string | null
          word_count: string | null
          work_type: string | null
        }
        Insert: {
          academic_level?: string | null
          archived_at?: string | null
          assigned_expert_id?: string | null
          assigned_expert_name?: string | null
          client_email?: never
          client_id?: string | null
          client_name?: never
          client_phone?: never
          created_at?: string | null
          deadline?: string | null
          delivered_at?: string | null
          description?: string | null
          id?: string | null
          order_number?: string | null
          paid_amount?: number | null
          payment_date?: string | null
          payment_method?: string | null
          price?: number | null
          rejection_reason?: string | null
          specific_requirements?: string | null
          status?: string | null
          subject?: string | null
          title?: string | null
          updated_at?: string | null
          word_count?: string | null
          work_type?: string | null
        }
        Update: {
          academic_level?: string | null
          archived_at?: string | null
          assigned_expert_id?: string | null
          assigned_expert_name?: string | null
          client_email?: never
          client_id?: string | null
          client_name?: never
          client_phone?: never
          created_at?: string | null
          deadline?: string | null
          delivered_at?: string | null
          description?: string | null
          id?: string | null
          order_number?: string | null
          paid_amount?: number | null
          payment_date?: string | null
          payment_method?: string | null
          price?: number | null
          rejection_reason?: string | null
          specific_requirements?: string | null
          status?: string | null
          subject?: string | null
          title?: string | null
          updated_at?: string | null
          word_count?: string | null
          work_type?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      is_admin: { Args: never; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
    },
  },
} as const
