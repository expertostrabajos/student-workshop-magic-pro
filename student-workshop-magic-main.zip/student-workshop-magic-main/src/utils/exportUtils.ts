import { WorkOrder } from '@/types/workOrder';

export function exportToCSV(data: Record<string, any>[], filename: string) {
  if (data.length === 0) return;

  const headers = Object.keys(data[0]);
  const csvRows = [
    headers.join(','),
    ...data.map(row =>
      headers.map(h => {
        const val = row[h];
        const str = val === null || val === undefined ? '' : String(val);
        return `"${str.replace(/"/g, '""')}"`;
      }).join(',')
    )
  ];

  const blob = new Blob(['\uFEFF' + csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}_${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

export function exportOrdersToCSV(orders: WorkOrder[]) {
  const data = orders.map(o => ({
    'Número': o.orderNumber,
    'Título': o.title,
    'Estado': o.status,
    'Cliente': o.clientName,
    'Email': o.clientEmail,
    'Tipo': o.workType,
    'Nivel': o.academicLevel,
    'Materia': o.subject,
    'Precio': o.price || '',
    'Pagado': o.paidAmount || '',
    'Método Pago': o.paymentMethod || '',
    'Fecha Creación': o.createdAt.toLocaleDateString(),
    'Fecha Límite': o.deadline.toLocaleDateString(),
    'Experto': o.assignedExpertName || '',
  }));
  exportToCSV(data, 'ordenes_trabajo');
}

export function exportUsersToCSV(users: { name: string; email: string; createdAt: string }[]) {
  const data = users.map(u => ({
    'Nombre': u.name || 'Sin nombre',
    'Email': u.email,
    'Registrado': new Date(u.createdAt).toLocaleDateString(),
  }));
  exportToCSV(data, 'usuarios');
}
