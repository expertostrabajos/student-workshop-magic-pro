
/**
 * Utility functions for SEO management
 * Contains helper functions for setting and managing meta tags,
 * generating sitemaps, and other SEO-related functionality
 */

/**
 * Updates meta tags dynamically for different pages
 * @param title - Page title
 * @param description - Page description
 * @param keywords - Array of keywords
 */
export const updateMetaTags = (
  title: string,
  description: string,
  keywords: string[]
): void => {
  // Update document title
  document.title = title;
  
  // Update meta description
  const metaDescription = document.querySelector('meta[name="description"]');
  if (metaDescription) {
    metaDescription.setAttribute('content', description);
  }
  
  // Find or create meta keywords
  let metaKeywords = document.querySelector('meta[name="keywords"]');
  if (!metaKeywords) {
    metaKeywords = document.createElement('meta');
    metaKeywords.setAttribute('name', 'keywords');
    document.head.appendChild(metaKeywords);
  }
  metaKeywords.setAttribute('content', keywords.join(', '));
};
