
// Function to schedule a reminder using localStorage (in a real app, this would use a backend service)
export const scheduleReminder = (requestId: string, email: string, deadline: string, reminderDays: number) => {
  // Calculate the reminder date (X days before deadline)
  const deadlineDate = new Date(deadline);
  const reminderDate = new Date(deadlineDate);
  reminderDate.setDate(deadlineDate.getDate() - reminderDays);
  
  // Store the reminder in localStorage
  const reminders = JSON.parse(localStorage.getItem('workReminders') || '[]');
  reminders.push({
    id: `reminder-${Date.now()}`,
    requestId,
    email,
    deadline,
    reminderDate: reminderDate.toISOString(),
    sent: false
  });
  
  localStorage.setItem('workReminders', JSON.stringify(reminders));
  
  console.log(`Reminder scheduled for ${reminderDate.toLocaleDateString()} (${reminderDays} days before deadline)`);
  
  return reminderDate;
};

// Function to check for pending reminders - this would be called by a background process
export const checkReminders = () => {
  const reminders = JSON.parse(localStorage.getItem('workReminders') || '[]');
  const now = new Date();
  
  let remindersSent = 0;
  
  const updatedReminders = reminders.map(reminder => {
    if (!reminder.sent && new Date(reminder.reminderDate) <= now) {
      // In a real implementation, this would send an actual email
      console.log(`REMINDER: Work request ${reminder.requestId} is due on ${new Date(reminder.deadline).toLocaleDateString()}`);
      
      // Mark as sent
      remindersSent++;
      return { ...reminder, sent: true };
    }
    return reminder;
  });
  
  if (remindersSent > 0) {
    localStorage.setItem('workReminders', JSON.stringify(updatedReminders));
  }
  
  return remindersSent;
};
