
/**
 * Manejador central de peticiones API con cacheo y manejo de errores
 */

// Cache simple en memoria
let apiCache: Record<string, { data: any; timestamp: number }> = {};
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutos en milisegundos

// Endpoints disponibles
const API_ENDPOINTS = {
  SERVICES: '/api/services',
  PRICING: '/api/pricing',
  TESTIMONIALS: '/api/testimonials',
  FAQS: '/api/faqs'
};

// Opciones para configurar una petición
interface FetchOptions {
  useCache?: boolean;
  cacheDuration?: number; // en milisegundos
  timeout?: number; // en milisegundos
}

/**
 * Función principal para realizar peticiones con manejo de errores y cacheo
 */
export const fetchApi = async <T>(
  endpoint: string, 
  options: FetchOptions = { useCache: true, cacheDuration: CACHE_DURATION, timeout: 5000 }
): Promise<T> => {
  // Verificar si hay datos en cache válidos
  if (options.useCache) {
    const cacheEntry = apiCache[endpoint];
    const now = Date.now();
    
    if (cacheEntry && (now - cacheEntry.timestamp < (options.cacheDuration || CACHE_DURATION))) {
      console.log(`Usando datos en caché para: ${endpoint}`);
      return cacheEntry.data as T;
    }
  }
  
  try {
    // Crear AbortController para timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), options.timeout);
    
    const response = await fetch(endpoint, { signal: controller.signal });
    clearTimeout(timeoutId);
    
    if (!response.ok) {
      throw new Error(`Error al obtener ${endpoint}: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    
    // Guardar en caché si está habilitado
    if (options.useCache) {
      apiCache[endpoint] = { data, timestamp: Date.now() };
    }
    
    return data as T;
  } catch (error) {
    // Manejo personalizado de errores
    if (error instanceof DOMException && error.name === 'AbortError') {
      console.error(`Timeout al obtener datos de ${endpoint}`);
      // Usar datos en caché si existen, incluso si están vencidos
      if (apiCache[endpoint]) {
        console.warn(`Usando datos en caché vencidos para ${endpoint} debido a timeout`);
        return apiCache[endpoint].data as T;
      }
    }
    
    console.error(`Error en la petición a ${endpoint}:`, error);
    throw error;
  }
};

/**
 * Obtener servicios disponibles
 */
export const getServices = async () => {
  return fetchApi(API_ENDPOINTS.SERVICES);
};

/**
 * Obtener información de precios
 */
export const getPricing = async () => {
  return fetchApi(API_ENDPOINTS.PRICING);
};

/**
 * Obtener testimonios
 */
export const getTestimonials = async () => {
  return fetchApi(API_ENDPOINTS.TESTIMONIALS);
};

/**
 * Obtener preguntas frecuentes
 */
export const getFaqs = async () => {
  return fetchApi(API_ENDPOINTS.FAQS);
};

/**
 * Limpiar cache de la API
 */
export const clearApiCache = (endpoint?: string) => {
  if (endpoint) {
    delete apiCache[endpoint];
  } else {
    apiCache = {};
  }
};
