import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { 
  WorkOrder, 
  WorkOrderStatus, 
  WorkOrderHistoryEntry,
  isValidTransition,
  getValidTransitions 
} from '@/types/workOrder';
import { toast } from 'sonner';

interface UseWorkOrderStateReturn {
  order: WorkOrder | null;
  isTransitioning: boolean;
  isLoading: boolean;
  transition: (toStatus: WorkOrderStatus, notes?: string, performedBy?: string) => Promise<boolean>;
  getAvailableTransitions: () => ReturnType<typeof getValidTransitions>;
  setOrder: (order: WorkOrder) => void;
  updateOrder: (updates: Partial<WorkOrder>) => void;
  loadOrder: (orderId: string) => Promise<void>;
  saveOrder: () => Promise<boolean>;
}

// Helper para mapear datos de DB a WorkOrder
function mapDbToWorkOrder(dbOrder: any, history: any[] = []): WorkOrder {
  return {
    id: dbOrder.id,
    orderNumber: dbOrder.order_number || '',
    title: dbOrder.title,
    description: dbOrder.description || '',
    subject: dbOrder.subject,
    workType: dbOrder.work_type,
    academicLevel: dbOrder.academic_level,
    wordCount: dbOrder.word_count || '',
    specificRequirements: dbOrder.specific_requirements,
    deadline: new Date(dbOrder.deadline),
    status: dbOrder.status as WorkOrderStatus,
    clientId: dbOrder.client_id || '',
    clientName: dbOrder.client_name,
    clientEmail: dbOrder.client_email,
    clientPhone: dbOrder.client_phone,
    assignedExpertId: dbOrder.assigned_expert_id,
    assignedExpertName: dbOrder.assigned_expert_name,
    price: dbOrder.price ? parseFloat(dbOrder.price) : undefined,
    paidAmount: dbOrder.paid_amount ? parseFloat(dbOrder.paid_amount) : undefined,
    paymentMethod: dbOrder.payment_method,
    paymentDate: dbOrder.payment_date ? new Date(dbOrder.payment_date) : undefined,
    createdAt: new Date(dbOrder.created_at),
    updatedAt: new Date(dbOrder.updated_at),
    deliveredAt: dbOrder.delivered_at ? new Date(dbOrder.delivered_at) : undefined,
    archivedAt: dbOrder.archived_at ? new Date(dbOrder.archived_at) : undefined,
    rejectionReason: dbOrder.rejection_reason,
    history: history.map(h => ({
      id: h.id,
      timestamp: new Date(h.created_at),
      fromStatus: h.from_status as WorkOrderStatus,
      toStatus: h.to_status as WorkOrderStatus,
      performedBy: h.performed_by,
      notes: h.notes
    }))
  };
}

export function useWorkOrderState(initialOrder?: WorkOrder): UseWorkOrderStateReturn {
  const [order, setOrderState] = useState<WorkOrder | null>(initialOrder || null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const loadOrder = useCallback(async (orderId: string) => {
    setIsLoading(true);
    try {
      const { data: orderData, error: orderError } = await supabase
        .from('work_orders')
        .select('*')
        .eq('id', orderId)
        .maybeSingle();

      if (orderError) throw orderError;
      if (!orderData) {
        toast.error('Orden no encontrada');
        return;
      }

      const { data: historyData, error: historyError } = await supabase
        .from('work_order_history')
        .select('*')
        .eq('work_order_id', orderId)
        .order('created_at', { ascending: false });

      if (historyError) throw historyError;

      setOrderState(mapDbToWorkOrder(orderData, historyData || []));
    } catch (error: any) {
      console.error('Error loading order:', error);
      toast.error('Error al cargar la orden');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const saveOrder = useCallback(async (): Promise<boolean> => {
    if (!order) return false;

    try {
      const { error } = await supabase
        .from('work_orders')
        .update({
          title: order.title,
          description: order.description,
          subject: order.subject,
          work_type: order.workType,
          academic_level: order.academicLevel,
          word_count: order.wordCount,
          deadline: order.deadline.toISOString(),
          status: order.status,
          assigned_expert_id: order.assignedExpertId,
          assigned_expert_name: order.assignedExpertName,
          price: order.price,
          paid_amount: order.paidAmount,
          payment_method: order.paymentMethod,
          payment_date: order.paymentDate?.toISOString(),
          rejection_reason: order.rejectionReason,
          delivered_at: order.deliveredAt?.toISOString(),
          archived_at: order.archivedAt?.toISOString()
        })
        .eq('id', order.id);

      if (error) throw error;
      return true;
    } catch (error: any) {
      console.error('Error saving order:', error);
      toast.error('Error al guardar la orden');
      return false;
    }
  }, [order]);

  const transition = useCallback(async (
    toStatus: WorkOrderStatus, 
    notes?: string, 
    performedBy: string = 'Sistema'
  ): Promise<boolean> => {
    if (!order) {
      toast.error('No hay orden seleccionada');
      return false;
    }

    if (!isValidTransition(order.status, toStatus)) {
      toast.error('Transición no válida', {
        description: `No se puede pasar de "${order.status}" a "${toStatus}"`
      });
      return false;
    }

    setIsTransitioning(true);

    try {
      // Actualizar estado de la orden en DB
      const updateData: any = {
        status: toStatus,
        ...(toStatus === 'delivered' && { delivered_at: new Date().toISOString() }),
        ...(toStatus === 'archived' && { archived_at: new Date().toISOString() }),
      };

      const { error: updateError } = await supabase
        .from('work_orders')
        .update(updateData)
        .eq('id', order.id);

      if (updateError) throw updateError;

      // Insertar entrada en el historial
      const { error: historyError } = await supabase
        .from('work_order_history')
        .insert({
          work_order_id: order.id,
          from_status: order.status,
          to_status: toStatus,
          performed_by: performedBy,
          notes
        });

      if (historyError) throw historyError;

      // Crear entrada de historial local
      const historyEntry: WorkOrderHistoryEntry = {
        id: `hist-${Date.now()}`,
        timestamp: new Date(),
        fromStatus: order.status,
        toStatus,
        performedBy,
        notes
      };

      // Actualizar orden local
      const updatedOrder: WorkOrder = {
        ...order,
        status: toStatus,
        updatedAt: new Date(),
        history: [historyEntry, ...order.history],
        ...(toStatus === 'delivered' && { deliveredAt: new Date() }),
        ...(toStatus === 'archived' && { archivedAt: new Date() }),
      };

      setOrderState(updatedOrder);

      toast.success('Estado actualizado', {
        description: `El trabajo ahora está en estado: ${toStatus}`
      });

      return true;
    } catch (error: any) {
      console.error('Error updating order status:', error);
      toast.error('Error al actualizar el estado');
      return false;
    } finally {
      setIsTransitioning(false);
    }
  }, [order]);

  const getAvailableTransitions = useCallback(() => {
    if (!order) return [];
    return getValidTransitions(order.status);
  }, [order]);

  const setOrder = useCallback((newOrder: WorkOrder) => {
    setOrderState(newOrder);
  }, []);

  const updateOrder = useCallback((updates: Partial<WorkOrder>) => {
    if (!order) return;
    setOrderState({
      ...order,
      ...updates,
      updatedAt: new Date()
    });
  }, [order]);

  return {
    order,
    isTransitioning,
    isLoading,
    transition,
    getAvailableTransitions,
    setOrder,
    updateOrder,
    loadOrder,
    saveOrder
  };
}
