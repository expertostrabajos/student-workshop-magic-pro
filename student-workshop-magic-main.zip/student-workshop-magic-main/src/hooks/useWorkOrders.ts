import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { WorkOrder, WorkOrderStatus } from '@/types/workOrder';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

interface UseWorkOrdersReturn {
  orders: WorkOrder[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
  createOrder: (orderData: Partial<WorkOrder>) => Promise<WorkOrder | null>;
  updateOrderStatus: (orderId: string, status: WorkOrderStatus, notes?: string) => Promise<boolean>;
  updateOrder: (orderId: string, updates: Partial<WorkOrder>) => Promise<boolean>;
}

function mapDbToWorkOrder(dbOrder: any, history: any[] = []): WorkOrder {
  return {
    id: dbOrder.id,
    orderNumber: dbOrder.order_number || '',
    title: dbOrder.title,
    description: dbOrder.description || '',
    subject: dbOrder.subject,
    workType: dbOrder.work_type,
    academicLevel: dbOrder.academic_level,
    wordCount: dbOrder.word_count || '',
    specificRequirements: dbOrder.specific_requirements,
    deadline: new Date(dbOrder.deadline),
    status: dbOrder.status as WorkOrderStatus,
    clientId: dbOrder.client_id || '',
    clientName: dbOrder.client_name || 'Cliente',
    clientEmail: dbOrder.client_email || '',
    clientPhone: dbOrder.client_phone,
    assignedExpertId: dbOrder.assigned_expert_id,
    assignedExpertName: dbOrder.assigned_expert_name,
    price: dbOrder.price ? parseFloat(dbOrder.price) : undefined,
    paidAmount: dbOrder.paid_amount ? parseFloat(dbOrder.paid_amount) : undefined,
    paymentMethod: dbOrder.payment_method,
    paymentDate: dbOrder.payment_date ? new Date(dbOrder.payment_date) : undefined,
    createdAt: new Date(dbOrder.created_at),
    updatedAt: new Date(dbOrder.updated_at),
    deliveredAt: dbOrder.delivered_at ? new Date(dbOrder.delivered_at) : undefined,
    archivedAt: dbOrder.archived_at ? new Date(dbOrder.archived_at) : undefined,
    rejectionReason: dbOrder.rejection_reason,
    history: history.map(h => ({
      id: h.id,
      timestamp: new Date(h.created_at),
      fromStatus: h.from_status as WorkOrderStatus,
      toStatus: h.to_status as WorkOrderStatus,
      performedBy: h.performed_by,
      notes: h.notes
    }))
  };
}

export function useWorkOrders(): UseWorkOrdersReturn {
  const { isAdmin } = useAuth();
  const [orders, setOrders] = useState<WorkOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Admins usan la tabla completa, clientes usan la vista segura
      // La vista oculta datos sensibles (email, phone, name) de otros clientes
      const query = isAdmin 
        ? supabase.from('work_orders').select('*')
        : supabase.from('work_orders_safe' as any).select('*');
      
      const { data: ordersData, error: ordersError } = await query.order('created_at', { ascending: false });

      if (ordersError) throw ordersError;

      if (!ordersData || ordersData.length === 0) {
        setOrders([]);
        return;
      }

      // Obtener historial de todas las órdenes
      const orderIds = ordersData.map(o => o.id);
      const { data: historyData, error: historyError } = await supabase
        .from('work_order_history')
        .select('*')
        .in('work_order_id', orderIds)
        .order('created_at', { ascending: false });

      if (historyError) throw historyError;

      // Mapear órdenes con su historial
      const mappedOrders = ordersData.map(order => {
        const orderHistory = (historyData || []).filter(h => h.work_order_id === order.id);
        return mapDbToWorkOrder(order, orderHistory);
      });

      setOrders(mappedOrders);
    } catch (err: any) {
      console.error('Error fetching orders:', err);
      setError(err.message || 'Error al cargar las órdenes');
      toast.error('Error al cargar las órdenes');
    } finally {
      setIsLoading(false);
    }
  }, [isAdmin]);

  const createOrder = useCallback(async (orderData: Partial<WorkOrder>): Promise<WorkOrder | null> => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      
      // Generar un número de orden temporal - el trigger lo actualizará
      const tempOrderNumber = `ORD-${Date.now()}`;
      
      const insertData: any = {
        order_number: tempOrderNumber,
        title: orderData.title || 'Sin título',
        description: orderData.description || null,
        subject: orderData.subject || 'General',
        work_type: orderData.workType || 'Ensayo',
        academic_level: orderData.academicLevel || 'Universidad',
        word_count: orderData.wordCount || null,
        deadline: orderData.deadline?.toISOString() || new Date().toISOString(),
        client_id: orderData.clientId || userData?.user?.id || null,
        client_name: orderData.clientName || 'Cliente',
        client_email: orderData.clientEmail || userData?.user?.email || '',
        price: orderData.price || null,
        specific_requirements: orderData.description || null,
        status: 'created'
      };

      const { data, error } = await supabase
        .from('work_orders')
        .insert(insertData)
        .select()
        .single();

      if (error) throw error;

      // Insertar historial inicial
      await supabase.from('work_order_history').insert({
        work_order_id: data.id,
        from_status: 'created',
        to_status: 'created',
        performed_by: 'Sistema',
        notes: 'Orden creada'
      });

      const newOrder = mapDbToWorkOrder(data, []);
      setOrders(prev => [newOrder, ...prev]);
      
      toast.success('Orden creada exitosamente');
      return newOrder;
    } catch (err: any) {
      console.error('Error creating order:', err);
      toast.error('Error al crear la orden: ' + (err.message || 'Error desconocido'));
      return null;
    }
  }, []);

  const updateOrderStatus = useCallback(async (
    orderId: string, 
    status: WorkOrderStatus, 
    notes?: string
  ): Promise<boolean> => {
    try {
      const currentOrder = orders.find(o => o.id === orderId);
      if (!currentOrder) return false;

      const { data: userData } = await supabase.auth.getUser();
      const performedBy = userData?.user?.email || 'Admin';

      const updateData: any = {
        status,
        ...(status === 'delivered' && { delivered_at: new Date().toISOString() }),
        ...(status === 'archived' && { archived_at: new Date().toISOString() }),
      };

      const { error: updateError } = await supabase
        .from('work_orders')
        .update(updateData)
        .eq('id', orderId);

      if (updateError) throw updateError;

      // Insertar historial
      await supabase.from('work_order_history').insert({
        work_order_id: orderId,
        from_status: currentOrder.status,
        to_status: status,
        performed_by: performedBy,
        notes
      });

      // Actualizar estado local
      setOrders(prev => prev.map(o => 
        o.id === orderId 
          ? { 
              ...o, 
              status, 
              updatedAt: new Date(),
              ...(status === 'delivered' && { deliveredAt: new Date() }),
              ...(status === 'archived' && { archivedAt: new Date() }),
            } 
          : o
      ));

      return true;
    } catch (err: any) {
      console.error('Error updating order status:', err);
      toast.error('Error al actualizar el estado');
      return false;
    }
  }, [orders]);

  const updateOrder = useCallback(async (
    orderId: string, 
    updates: Partial<WorkOrder>
  ): Promise<boolean> => {
    try {
      const dbUpdates: any = {};
      
      if (updates.assignedExpertId !== undefined) dbUpdates.assigned_expert_id = updates.assignedExpertId;
      if (updates.assignedExpertName !== undefined) dbUpdates.assigned_expert_name = updates.assignedExpertName;
      if (updates.price !== undefined) dbUpdates.price = updates.price;
      if (updates.paidAmount !== undefined) dbUpdates.paid_amount = updates.paidAmount;
      if (updates.paymentMethod !== undefined) dbUpdates.payment_method = updates.paymentMethod;
      if (updates.paymentDate !== undefined) dbUpdates.payment_date = updates.paymentDate?.toISOString();
      if (updates.rejectionReason !== undefined) dbUpdates.rejection_reason = updates.rejectionReason;

      const { error } = await supabase
        .from('work_orders')
        .update(dbUpdates)
        .eq('id', orderId);

      if (error) throw error;

      // Actualizar estado local
      setOrders(prev => prev.map(o => 
        o.id === orderId 
          ? { ...o, ...updates, updatedAt: new Date() } 
          : o
      ));

      return true;
    } catch (err: any) {
      console.error('Error updating order:', err);
      toast.error('Error al actualizar la orden');
      return false;
    }
  }, []);

  // Cargar órdenes al montar y suscribirse a cambios en tiempo real
  useEffect(() => {
    fetchOrders();

    // Suscripción a cambios en tiempo real
    const channel = supabase
      .channel('work-orders-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'work_orders' },
        () => {
          // Recargar órdenes cuando hay cambios
          fetchOrders();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchOrders]);

  return {
    orders,
    isLoading,
    error,
    refetch: fetchOrders,
    createOrder,
    updateOrderStatus,
    updateOrder
  };
}
