
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  date: string;
  isRead: boolean;
  link?: string;
}

export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const { user } = useAuth();

  const updateUnreadCount = useCallback((notifs: Notification[]) => {
    setUnreadCount(notifs.filter(n => !n.isRead).length);
  }, []);

  // Listen for real-time work_orders changes and create notifications
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('notifications-realtime')
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'work_orders' },
        (payload) => {
          const oldStatus = (payload.old as any)?.status;
          const newStatus = (payload.new as any)?.status;
          const title = (payload.new as any)?.title || 'Orden';

          if (oldStatus !== newStatus) {
            const statusMessages: Record<string, string> = {
              paid: `El pago de "${title}" ha sido confirmado.`,
              assigned: `"${title}" ha sido asignada a un experto.`,
              in_progress: `"${title}" está ahora en progreso.`,
              in_review: `"${title}" está en revisión.`,
              delivered: `"${title}" ha sido entregada.`,
              rejected: `"${title}" ha sido rechazada.`,
            };

            const msg = statusMessages[newStatus] || `"${title}" cambió a estado: ${newStatus}`;
            
            addNotification({
              title: 'Actualización de orden',
              message: msg,
              type: newStatus === 'rejected' ? 'error' : newStatus === 'delivered' ? 'success' : 'info',
              link: '/dashboard'
            });
          }
        }
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'work_orders' },
        (payload) => {
          const title = (payload.new as any)?.title || 'Nueva orden';
          addNotification({
            title: 'Nueva orden creada',
            message: `Se ha creado la orden "${title}".`,
            type: 'info',
            link: '/dashboard'
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const markAsRead = useCallback((id: string) => {
    setNotifications(prev => {
      const updated = prev.map(n => n.id === id ? { ...n, isRead: true } : n);
      updateUnreadCount(updated);
      return updated;
    });
  }, [updateUnreadCount]);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => {
      const updated = prev.map(n => ({ ...n, isRead: true }));
      setUnreadCount(0);
      return updated;
    });
  }, []);

  const addNotification = useCallback((notification: Omit<Notification, 'id' | 'date' | 'isRead'>) => {
    const newNotification: Notification = {
      ...notification,
      id: Date.now().toString() + Math.random().toString(36).slice(2),
      date: new Date().toISOString(),
      isRead: false
    };
    
    setNotifications(prev => {
      const updated = [newNotification, ...prev].slice(0, 50); // Keep max 50
      updateUnreadCount(updated);
      return updated;
    });
    
    return newNotification.id;
  }, [updateUnreadCount]);

  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => {
      const updated = prev.filter(n => n.id !== id);
      updateUnreadCount(updated);
      return updated;
    });
  }, [updateUnreadCount]);

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    addNotification,
    removeNotification
  };
}
