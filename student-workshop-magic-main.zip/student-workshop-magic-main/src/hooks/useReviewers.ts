import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Reviewer {
  id: string;
  userId?: string;
  name: string;
  email: string;
  specialty: string;
  currentWorkload: number;
  completedWorks: number;
  averageQuality: number;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

interface UseReviewersReturn {
  reviewers: Reviewer[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
  createReviewer: (reviewerData: Omit<Reviewer, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Reviewer | null>;
  updateReviewer: (reviewerId: string, updates: Partial<Reviewer>) => Promise<boolean>;
  deleteReviewer: (reviewerId: string) => Promise<boolean>;
}

function mapDbToReviewer(dbReviewer: any): Reviewer {
  return {
    id: dbReviewer.id,
    userId: dbReviewer.user_id,
    name: dbReviewer.name,
    email: dbReviewer.email,
    specialty: dbReviewer.specialty,
    currentWorkload: dbReviewer.current_workload,
    completedWorks: dbReviewer.completed_works,
    averageQuality: parseFloat(dbReviewer.average_quality) || 0,
    isActive: dbReviewer.is_active,
    createdAt: new Date(dbReviewer.created_at),
    updatedAt: new Date(dbReviewer.updated_at)
  };
}

export function useReviewers(): UseReviewersReturn {
  const [reviewers, setReviewers] = useState<Reviewer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchReviewers = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { data, error: fetchError } = await supabase
        .from('reviewers')
        .select('*')
        .order('name', { ascending: true });

      if (fetchError) throw fetchError;

      const mappedReviewers = (data || []).map(mapDbToReviewer);
      setReviewers(mappedReviewers);
    } catch (err: any) {
      console.error('Error fetching reviewers:', err);
      setError(err.message || 'Error al cargar revisores');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createReviewer = useCallback(async (
    reviewerData: Omit<Reviewer, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<Reviewer | null> => {
    try {
      const { data, error: insertError } = await supabase
        .from('reviewers')
        .insert({
          user_id: reviewerData.userId,
          name: reviewerData.name,
          email: reviewerData.email,
          specialty: reviewerData.specialty,
          current_workload: reviewerData.currentWorkload,
          completed_works: reviewerData.completedWorks,
          average_quality: reviewerData.averageQuality,
          is_active: reviewerData.isActive
        })
        .select()
        .single();

      if (insertError) throw insertError;

      const newReviewer = mapDbToReviewer(data);
      setReviewers(prev => [...prev, newReviewer].sort((a, b) => a.name.localeCompare(b.name)));
      toast.success('Revisor creado exitosamente');
      return newReviewer;
    } catch (err: any) {
      console.error('Error creating reviewer:', err);
      toast.error('Error al crear revisor: ' + err.message);
      return null;
    }
  }, []);

  const updateReviewer = useCallback(async (
    reviewerId: string,
    updates: Partial<Reviewer>
  ): Promise<boolean> => {
    try {
      const dbUpdates: any = {};
      if (updates.name !== undefined) dbUpdates.name = updates.name;
      if (updates.email !== undefined) dbUpdates.email = updates.email;
      if (updates.specialty !== undefined) dbUpdates.specialty = updates.specialty;
      if (updates.currentWorkload !== undefined) dbUpdates.current_workload = updates.currentWorkload;
      if (updates.completedWorks !== undefined) dbUpdates.completed_works = updates.completedWorks;
      if (updates.averageQuality !== undefined) dbUpdates.average_quality = updates.averageQuality;
      if (updates.isActive !== undefined) dbUpdates.is_active = updates.isActive;
      if (updates.userId !== undefined) dbUpdates.user_id = updates.userId;

      const { error: updateError } = await supabase
        .from('reviewers')
        .update(dbUpdates)
        .eq('id', reviewerId);

      if (updateError) throw updateError;

      setReviewers(prev => 
        prev.map(r => r.id === reviewerId ? { ...r, ...updates } : r)
      );
      return true;
    } catch (err: any) {
      console.error('Error updating reviewer:', err);
      toast.error('Error al actualizar revisor: ' + err.message);
      return false;
    }
  }, []);

  const deleteReviewer = useCallback(async (reviewerId: string): Promise<boolean> => {
    try {
      const { error: deleteError } = await supabase
        .from('reviewers')
        .delete()
        .eq('id', reviewerId);

      if (deleteError) throw deleteError;

      setReviewers(prev => prev.filter(r => r.id !== reviewerId));
      toast.success('Revisor eliminado exitosamente');
      return true;
    } catch (err: any) {
      console.error('Error deleting reviewer:', err);
      toast.error('Error al eliminar revisor: ' + err.message);
      return false;
    }
  }, []);

  useEffect(() => {
    fetchReviewers();
  }, [fetchReviewers]);

  return {
    reviewers,
    isLoading,
    error,
    refetch: fetchReviewers,
    createReviewer,
    updateReviewer,
    deleteReviewer
  };
}
