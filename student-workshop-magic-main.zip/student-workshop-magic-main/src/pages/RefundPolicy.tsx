
import Navbar from "@/components/Navbar";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const RefundPolicy = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="pt-24 pb-12 md:pt-32 md:pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver al inicio
            </Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Política de Reembolsos</h1>
          
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="prose max-w-none">
              <p className="mb-4">
                <strong>Última actualización:</strong> 1 de junio de 2023
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">1. Condiciones generales</h2>
              <p className="mb-4">
                En StudentHelp, nos esforzamos por ofrecer servicios académicos de la más alta calidad. Esta política de reembolsos está diseñada para establecer un proceso justo y transparente para solicitar reembolsos cuando sea necesario.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">2. Elegibilidad para reembolsos</h2>
              <p className="mb-4">
                Puedes ser elegible para un reembolso en las siguientes circunstancias:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li><strong>Reembolso completo:</strong>
                  <ul className="list-disc ml-6 mb-2">
                    <li>Si cancelamos tu pedido debido a la falta de un experto disponible</li>
                    <li>Si el trabajo entregado no cumple con ninguno de los requisitos principales especificados</li>
                    <li>Si el trabajo se entrega después del plazo acordado y ya no lo necesitas</li>
                  </ul>
                </li>
                <li><strong>Reembolso parcial:</strong>
                  <ul className="list-disc ml-6 mb-2">
                    <li>Si el trabajo entregado cumple parcialmente con los requisitos especificados</li>
                    <li>Si el trabajo se entrega con retraso pero aún lo puedes utilizar</li>
                    <li>Si decidimos de mutuo acuerdo que un reembolso parcial es la solución más justa</li>
                  </ul>
                </li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">3. Periodo para solicitar reembolsos</h2>
              <p className="mb-4">
                Debes solicitar un reembolso dentro de los siguientes plazos:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Para problemas de calidad o incumplimiento de requisitos: dentro de los 7 días posteriores a la entrega del trabajo</li>
                <li>Para trabajos entregados con retraso: dentro de las 48 horas posteriores a la entrega tardía</li>
                <li>Para cancelaciones por parte del cliente: los reembolsos se procesarán según la etapa en que se encuentre el trabajo</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">4. Proceso de solicitud de reembolso</h2>
              <p className="mb-4">
                Para solicitar un reembolso, sigue estos pasos:
              </p>
              <ol className="list-decimal ml-6 mb-4">
                <li>Contacta a nuestro equipo de atención al cliente a través del formulario de contacto o por correo electrónico a refunds@studenthelp.com</li>
                <li>Proporciona tu número de pedido y la información detallada sobre el motivo de tu solicitud</li>
                <li>Adjunta cualquier evidencia relevante que respalde tu solicitud</li>
                <li>Nuestro equipo revisará tu caso y te responderá dentro de 48 horas hábiles</li>
              </ol>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">5. Evaluación de las solicitudes</h2>
              <p className="mb-4">
                Cada solicitud de reembolso será evaluada individualmente, considerando:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Las instrucciones originales proporcionadas</li>
                <li>La calidad del trabajo entregado</li>
                <li>El cumplimiento de los plazos acordados</li>
                <li>Las revisiones ya realizadas</li>
                <li>Cualquier comunicación previa sobre el trabajo</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">6. Procesamiento de reembolsos</h2>
              <p className="mb-4">
                Si tu solicitud de reembolso es aprobada:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Los reembolsos se procesarán utilizando el mismo método de pago original</li>
                <li>El tiempo de procesamiento puede variar de 3 a 15 días hábiles, dependiendo de tu entidad financiera</li>
                <li>Te notificaremos por correo electrónico cuando el reembolso haya sido procesado</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">7. Cancelaciones</h2>
              <p className="mb-4">
                Si necesitas cancelar un pedido:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Cancelación antes de la asignación a un experto: reembolso completo</li>
                <li>Cancelación después de la asignación pero antes del inicio del trabajo: reembolso del 90%</li>
                <li>Cancelación con trabajo en progreso: el reembolso dependerá del avance del trabajo (generalmente entre 30% y 70%)</li>
                <li>Cancelación después de la entrega: sujeta a las condiciones de reembolso estándar</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">8. Excepciones</h2>
              <p className="mb-4">
                No se ofrecerán reembolsos en los siguientes casos:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Solicitudes realizadas después del período establecido de 7 días</li>
                <li>Cuando el cliente ha aprobado explícitamente el trabajo entregado</li>
                <li>Si el cliente cambia significativamente los requisitos después de haber iniciado el trabajo</li>
                <li>Por insatisfacción subjetiva cuando el trabajo cumple objetivamente con todos los requisitos especificados</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">9. Resolución de disputas</h2>
              <p className="mb-4">
                Si no estás de acuerdo con la resolución de tu solicitud de reembolso, puedes solicitar una revisión adicional por parte de nuestro equipo de gestión. Nos comprometemos a resolver todas las disputas de manera justa y equitativa.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">10. Contacto</h2>
              <p className="mb-4">
                Si tienes preguntas sobre nuestra política de reembolsos, por favor contáctanos a través de nuestro formulario de contacto o envía un correo electrónico a refunds@studenthelp.com.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RefundPolicy;
