
import Navbar from "@/components/Navbar";
import AboutSection from "@/components/AboutSection";
import { useEffect } from "react";
import { updateMetaTags } from "@/utils/seoUtils";

const AcercaDe = () => {
  useEffect(() => {
    // Actualizar metadatos para SEO
    updateMetaTags(
      "Acerca de EXPERTO_TRABAJOS | Soporte Académico en Colombia",
      "Conoce más sobre nuestra misión, visión y servicios de soporte académico para estudiantes en Colombia",
      ["soporte académico", "misión", "visión", "Colombia", "ayuda académica"]
    );
    
    // Añadir tracking de página
    console.log("Página 'Acerca de' visitada");
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <AboutSection />
    </div>
  );
};

export default AcercaDe;
