
import React, { useState, useEffect, lazy, Suspense, memo } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import SearchBar from "@/components/SearchBar";
import SEOTags from "@/components/SEOTags";
import { Button } from "@/components/ui/button";
import { BookOpen, MessageSquare, Smartphone, CheckCircle, ShieldCheck, Clock, RefreshCw } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import LazySection from "@/components/LazySection";
import Footer from "@/components/Footer";
import ScrollToTop from "@/components/ScrollToTop";
import TrustCounters from "@/components/TrustCounters";
import { motion } from "framer-motion";

const ContactForm = lazy(() => import("@/components/ContactForm"));
const WorkRequestForm = lazy(() => import("@/components/WorkRequestForm"));
const Testimonials = lazy(() => import("@/components/Testimonials"));
const FAQ = lazy(() => import("@/components/FAQ"));
const ServicesSection = lazy(() => import("@/components/ServicesSection"));
const PricingSection = lazy(() => import("@/components/PricingSection"));
const CookieConsent = lazy(() => import("@/components/CookieConsent"));
const EmailSubscribe = lazy(() => import("@/components/EmailSubscribe"));

const SkeletonLoader = memo(() => (
  <div className="w-full h-32 flex flex-col space-y-3 p-4">
    <Skeleton className="w-full h-8" />
    <Skeleton className="w-3/4 h-6" />
  </div>
));

const FeatureBox = memo(({ icon, title, description, linkText, linkUrl }: { 
  icon: React.ReactNode; 
  title: string; 
  description: string;
  linkText: string;
  linkUrl: string;
}) => (
  <div className="bg-card border border-border rounded-xl p-6 text-center hover:shadow-lg hover:border-primary/30 transition-all duration-300 group">
    <div className="bg-primary/10 rounded-xl p-4 inline-flex mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
      {icon}
    </div>
    <h3 className="text-xl font-semibold text-foreground mb-2">{title}</h3>
    <p className="text-muted-foreground mb-5 text-sm leading-relaxed">
      {description}
    </p>
    <Button asChild variant="outline" className="rounded-lg">
      <Link to={linkUrl}>{linkText}</Link>
    </Button>
  </div>
));

const guarantees = [
  {
    icon: <ShieldCheck className="h-6 w-6" />,
    title: "100% Original",
    description: "Cada trabajo es único y verificado con herramientas anti-plagio profesionales.",
  },
  {
    icon: <Clock className="h-6 w-6" />,
    title: "Entrega Puntual",
    description: "Garantizamos la entrega dentro del plazo acordado o te devolvemos tu dinero.",
  },
  {
    icon: <RefreshCw className="h-6 w-6" />,
    title: "Revisiones Gratis",
    description: "Incluimos hasta 3 revisiones sin costo adicional para asegurar tu satisfacción.",
  },
  {
    icon: <CheckCircle className="h-6 w-6" />,
    title: "Calidad Garantizada",
    description: "Expertos con títulos de maestría y doctorado en diversas áreas del conocimiento.",
  },
];

const Index = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const navigationStart = performance.now();
    const measurePerformance = () => {
      setIsVisible(true);
      if (import.meta.env.DEV) {
        console.log(`Tiempo de carga: ${(performance.now() - navigationStart).toFixed(2)}ms`);
      }
    };
    requestAnimationFrame(measurePerformance);
  }, []);

  const seoKeywords = [
    "trabajos académicos", "ensayos", "tesis", "proyectos de investigación", 
    "ayuda académica", "redacción académica", "Colombia"
  ];
  
  const features = [
    {
      icon: <BookOpen className="h-7 w-7 text-primary" />,
      title: "Biblioteca de Recursos",
      description: "Accede a guías académicas, plantillas y ejemplos para mejorar tus trabajos",
      linkText: "Explorar biblioteca",
      linkUrl: "/resource-library"
    },
    {
      icon: <MessageSquare className="h-7 w-7 text-primary" />,
      title: "Mensajería Directa",
      description: "Comunícate directamente con tus escritores para resolver dudas al instante",
      linkText: "Iniciar chat",
      linkUrl: "/academic-tools"
    },
    {
      icon: <Smartphone className="h-7 w-7 text-primary" />,
      title: "Panel Móvil",
      description: "Gestiona tus trabajos académicos desde cualquier dispositivo móvil",
      linkText: "Ver en móvil",
      linkUrl: "/dashboard"
    }
  ];
  
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SEOTags seoKeywords={seoKeywords} />
      <SearchBar />
      <HeroSection isVisible={isVisible} />
      <TrustCounters />

      {/* Servicios - loaded eagerly since it's right after hero */}
      <Suspense fallback={<SkeletonLoader />}>
        <ServicesSection />
      </Suspense>

      {/* Garantías */}
      <section id="garantias" className="py-16 md:py-24 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-foreground mb-4">Nuestras Garantías</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Tu tranquilidad es nuestra prioridad. Ofrecemos garantías reales para que confíes en nuestro servicio.
            </p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {guarantees.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="bg-card border border-border rounded-xl p-6 text-center hover:shadow-lg hover:border-primary/30 transition-all duration-300"
              >
                <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 text-primary rounded-xl mb-4">
                  {item.icon}
                </div>
                <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Funcionalidades destacadas */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-foreground mb-4">Herramientas para tu Éxito</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Plataforma integral con todo lo que necesitas para gestionar tus trabajos académicos
            </p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <FeatureBox {...feature} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <LazySection height="h-48">
        <Suspense fallback={<SkeletonLoader />}>
          <PricingSection />
        </Suspense>
      </LazySection>

      <LazySection height="h-48">
        <Suspense fallback={<SkeletonLoader />}>
          <Testimonials />
        </Suspense>
      </LazySection>

      <LazySection height="h-64">
        <section id="solicitar" className="py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-foreground mb-4">Solicita tu Trabajo</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Completa el formulario o usa nuestro asistente de IA para generar contenido personalizado.
              </p>
            </div>
            <Suspense fallback={<SkeletonLoader />}>
              <WorkRequestForm />
            </Suspense>
          </div>
        </section>
      </LazySection>

      <LazySection height="h-48">
        <Suspense fallback={<SkeletonLoader />}>
          <FAQ />
        </Suspense>
      </LazySection>

      <LazySection height="h-64">
        <section id="contacto" className="py-16 md:py-24 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-foreground mb-4">Contáctanos</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                ¿Tienes alguna pregunta? No dudes en ponerte en contacto con nosotros.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Suspense fallback={<SkeletonLoader />}>
                  <ContactForm />
                </Suspense>
              </div>
              <div>
                <Suspense fallback={<SkeletonLoader />}>
                  <EmailSubscribe />
                </Suspense>
              </div>
            </div>
          </div>
        </section>
      </LazySection>

      <Suspense fallback={null}>
        <CookieConsent />
      </Suspense>

      <Footer />
      <ScrollToTop />
    </div>
  );
};

export default Index;
