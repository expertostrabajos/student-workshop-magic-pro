
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { 
  FileText, 
  Folder, 
  Search,
  Filter,
  Plus,
  Calendar,
  Clock,
  Download,
  Trash,
  Tag
} from "lucide-react";
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import FileUploadComponent from "@/components/FileUploadComponent";
import { useNotificationContext } from "@/components/NotificationProvider";

interface Document {
  id: string;
  name: string;
  type: string;
  size: string;
  date: string;
  relatedWork?: string;
  category: 'material' | 'assignment' | 'revision';
}

const DocumentLibrary = () => {
  const [documents, setDocuments] = useState<Document[]>([
    {
      id: "1",
      name: "Instrucciones para ensayo.pdf",
      type: "PDF",
      size: "2.3 MB",
      date: "2025-04-07",
      relatedWork: "Análisis del Impacto Ambiental",
      category: 'material'
    },
    {
      id: "2",
      name: "Referencias bibliográficas.docx",
      type: "Word",
      size: "1.1 MB",
      date: "2025-04-06",
      relatedWork: "Ensayo de Literatura Comparada",
      category: 'material'
    },
    {
      id: "3",
      name: "Presentación final.pptx",
      type: "PowerPoint",
      size: "5.7 MB",
      date: "2025-04-05",
      relatedWork: "Análisis del Impacto Ambiental",
      category: 'assignment'
    }
  ]);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState<'all' | 'material' | 'assignment' | 'revision'>('all');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const { addNotification } = useNotificationContext();

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         (doc.relatedWork && doc.relatedWork.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = activeCategory === 'all' || doc.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const handleFilesUploaded = (files: File[]) => {
    // In a real implementation, this would upload to a server
    const newDocuments = files.map(file => ({
      id: `new-${Date.now()}-${file.name}`,
      name: file.name,
      type: file.name.split('.').pop()?.toUpperCase() || 'Unknown',
      size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
      date: new Date().toISOString().split('T')[0],
      category: 'material' as const
    }));
    
    setDocuments(prev => [...newDocuments, ...prev]);
    
    addNotification({
      title: "Documentos guardados",
      message: `Se han añadido ${files.length} documento(s) a tu biblioteca.`,
      type: "success"
    });
  };

  const deleteDocument = (id: string) => {
    setDocuments(prev => prev.filter(doc => doc.id !== id));
    toast.success("Documento eliminado correctamente");
  };

  const downloadDocument = (doc: Document) => {
    // In a real implementation, this would trigger a download
    toast.success(`Descargando ${doc.name}...`);
    
    addNotification({
      title: "Descarga iniciada",
      message: `Tu archivo "${doc.name}" se está descargando.`,
      type: "info"
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Biblioteca de Documentos</h1>
            <p className="text-gray-600">Gestiona tus materiales académicos y trabajos</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline" asChild>
              <Link to="/dashboard">
                Volver al Dashboard
              </Link>
            </Button>
            <Button onClick={() => setShowUploadModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Subir Documentos
            </Button>
          </div>
        </div>
        
        <div className="mb-8">
          <div className="bg-white p-4 rounded-lg shadow-sm flex flex-col sm:flex-row gap-4 items-center">
            <div className="relative w-full sm:w-96">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar documentos..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex space-x-4 w-full sm:w-auto">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center">
                    <Filter className="w-4 h-4 mr-2" />
                    <span className="hidden sm:inline">Filtrar por</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuLabel>Categoría</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setActiveCategory('all')}>
                    Todos
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setActiveCategory('material')}>
                    Materiales
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setActiveCategory('assignment')}>
                    Trabajos Entregados
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setActiveCategory('revision')}>
                    Revisiones
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
        
        {showUploadModal && (
          <Card className="mb-8">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Subir Nuevos Documentos</CardTitle>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setShowUploadModal(false)}
                >
                  Cerrar
                </Button>
              </div>
              <CardDescription>
                Sube los materiales que necesites para tu trabajo académico
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FileUploadComponent 
                onFilesUploaded={handleFilesUploaded}
                showCard={false}
              />
            </CardContent>
          </Card>
        )}
        
        {filteredDocuments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDocuments.map((doc) => (
              <Card key={doc.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <CardContent className="p-0">
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center">
                        <div className="bg-blue-100 p-2 rounded text-blue-700 mr-3">
                          <FileText className="h-8 w-8" />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900 text-sm">{doc.name}</h3>
                          <p className="text-xs text-gray-500">{doc.type} • {doc.size}</p>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <span className="sr-only">Abrir menu</span>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                              <circle cx="12" cy="12" r="1" />
                              <circle cx="12" cy="5" r="1" />
                              <circle cx="12" cy="19" r="1" />
                            </svg>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => downloadDocument(doc)}>
                            <Download className="mr-2 h-4 w-4" />
                            <span>Descargar</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => deleteDocument(doc.id)} className="text-red-600">
                            <Trash className="mr-2 h-4 w-4" />
                            <span>Eliminar</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    {doc.relatedWork && (
                      <div className="bg-gray-50 px-2 py-1 rounded text-xs text-gray-600 inline-flex items-center mt-2">
                        <Tag className="h-3 w-3 mr-1" />
                        {doc.relatedWork}
                      </div>
                    )}
                    
                    <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {new Date(doc.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center">
                        <span className={`w-2 h-2 rounded-full mr-1 ${
                          doc.category === 'material' ? 'bg-blue-500' : 
                          doc.category === 'assignment' ? 'bg-green-500' : 'bg-purple-500'
                        }`}></span>
                        {doc.category === 'material' ? 'Material' : 
                         doc.category === 'assignment' ? 'Trabajo' : 'Revisión'}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="bg-white p-12 rounded-lg shadow-sm text-center">
            <Folder className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">No se encontraron documentos</h3>
            <p className="text-gray-500 mb-4">
              {searchTerm ? 'No hay resultados para tu búsqueda' : 'Comienza subiendo tus primeros documentos'}
            </p>
            <Button onClick={() => setShowUploadModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Subir Documentos
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default DocumentLibrary;
