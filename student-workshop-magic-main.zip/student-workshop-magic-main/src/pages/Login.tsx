
import { useState, useEffect } from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Mail, Lock, LogIn, Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { signIn, loading, isAdmin } = useAuth();
  
  const [userCredentials, setUserCredentials] = useState({ email: "", password: "" });
  const [adminCredentials, setAdminCredentials] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  
  useEffect(() => {
    if (location.state?.message) {
      toast.success(location.state.message);
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location.state, navigate]);
  
  const handleUserLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!userCredentials.email.trim() || !userCredentials.password.trim()) {
      setError("Por favor, ingresa tu correo y contraseña");
      return;
    }
    try {
      await signIn(userCredentials.email, userCredentials.password);
      navigate("/dashboard");
    } catch (error) {
      console.error("Error en inicio de sesión:", error);
    }
  };
  
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!adminCredentials.email.trim() || !adminCredentials.password.trim()) {
      setError("Por favor, ingresa tu correo y contraseña de administrador");
      return;
    }
    try {
      await signIn(adminCredentials.email, adminCredentials.password);
      setTimeout(() => {
        if (isAdmin) {
          navigate("/admin");
        } else {
          setError("No tienes permisos de administrador");
        }
      }, 1000);
    } catch (error) {
      console.error("Error en inicio de sesión de administrador:", error);
    }
  };

  const PasswordInput = ({ id, value, onChange, placeholder }: { id: string; value: string; onChange: (v: string) => void; placeholder?: string }) => (
    <div className="relative">
      <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
      <Input
        id={id}
        type={showPassword ? "text" : "password"}
        placeholder={placeholder || "••••••••"}
        className="pl-10"
        required
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
      <button
        type="button"
        className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
        onClick={() => setShowPassword(!showPassword)}
      >
        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </button>
    </div>
  );

  const ErrorMessage = () => error ? (
    <div className="bg-destructive/10 p-3 rounded-md flex items-center text-destructive text-sm">
      <AlertCircle className="h-4 w-4 mr-2" />
      {error}
    </div>
  ) : null;

  const LoadingButton = ({ children }: { children: React.ReactNode }) => (
    <Button type="submit" className="w-full" disabled={loading}>
      {loading ? (
        <span className="flex items-center">
          <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Iniciando sesión...
        </span>
      ) : (
        <span className="flex items-center">
          <LogIn className="mr-2 h-4 w-4" />
          {children}
        </span>
      )}
    </Button>
  );
  
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground">StudentHelp</h1>
          <p className="text-muted-foreground mt-2">Accede a tu cuenta para continuar</p>
        </div>

        <Tabs defaultValue="usuario" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="usuario">Usuario</TabsTrigger>
            <TabsTrigger value="admin">Administrador</TabsTrigger>
          </TabsList>

          <TabsContent value="usuario">
            <Card>
              <CardHeader>
                <CardTitle>Iniciar sesión como Usuario</CardTitle>
                <CardDescription>
                  Ingresa tus credenciales para acceder a nuestros servicios académicos.
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleUserLogin}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="user-email">Correo electrónico</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="user-email"
                        type="email"
                        placeholder="tu@correo.com"
                        className="pl-10"
                        required
                        value={userCredentials.email}
                        onChange={(e) => setUserCredentials({...userCredentials, email: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="user-password">Contraseña</Label>
                      <Link to="/reset-password" className="text-sm text-primary hover:underline">
                        ¿Olvidaste tu contraseña?
                      </Link>
                    </div>
                    <PasswordInput
                      id="user-password"
                      value={userCredentials.password}
                      onChange={(v) => setUserCredentials({...userCredentials, password: v})}
                    />
                  </div>
                  
                  <ErrorMessage />
                  <LoadingButton>Iniciar sesión</LoadingButton>
                  
                  <div className="mt-6 text-center">
                    <span className="text-muted-foreground">¿No tienes una cuenta?{" "}</span>
                    <Link to="/register" className="text-primary hover:underline font-medium">
                      Regístrate ahora
                    </Link>
                  </div>
                  
                  <p className="text-sm text-center text-muted-foreground mt-4">
                    Al iniciar sesión, aceptas nuestros{" "}
                    <Link to="/terms-of-service" className="text-primary hover:underline">Términos de Servicio</Link>
                    {" "}y{" "}
                    <Link to="/privacy-policy" className="text-primary hover:underline">Política de Privacidad</Link>
                  </p>
                </CardContent>
              </form>
            </Card>
          </TabsContent>

          <TabsContent value="admin">
            <Card>
              <CardHeader>
                <CardTitle>Acceso Administrativo</CardTitle>
                <CardDescription>
                  Ingresa tus credenciales para administrar la plataforma.
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleAdminLogin}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Correo electrónico</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="admin@experto-trabajos.com"
                        className="pl-10"
                        required
                        value={adminCredentials.email}
                        onChange={(e) => setAdminCredentials({...adminCredentials, email: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Contraseña</Label>
                    <PasswordInput
                      id="password"
                      value={adminCredentials.password}
                      onChange={(v) => setAdminCredentials({...adminCredentials, password: v})}
                    />
                  </div>
                  
                  <ErrorMessage />
                  <LoadingButton>Iniciar sesión como Admin</LoadingButton>
                </CardContent>
              </form>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-6 text-center">
          <Link to="/" className="text-primary hover:underline">
            Volver al inicio
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
