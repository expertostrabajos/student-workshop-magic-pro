import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ArrowLeft, Copy, Check, AlertCircle, Send } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";

const Checkout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [paymentCompleted, setPaymentCompleted] = useState(false);
  const [paymentDetails, setPaymentDetails] = useState({
    amount: "",
    date: new Date().toISOString().split('T')[0],
    reference: ""
  });
  const [whatsappNotifications, setWhatsappNotifications] = useState(false);
  
  const { plan } = location.state || { 
    plan: { title: "Plan Básico", price: "50.000", features: [] } 
  };

  useEffect(() => {
    if (!location.state?.plan) {
      navigate("/");
    }
    document.title = `Pago - ${plan.title} | StudentHelp`;
  }, [location.state, navigate, plan]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText("3142135852")
      .then(() => {
        setCopied(true);
        toast.success("Número copiado al portapapeles");
        setTimeout(() => setCopied(false), 2000);
      })
      .catch(() => {
        toast.error("No se pudo copiar el número");
      });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFile(e.target.files[0]);
    }
  };

  const handlePaymentDetailsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPaymentDetails({
      ...paymentDetails,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadedFile) {
      toast.error("Por favor, sube un comprobante de pago");
      return;
    }
    if (!paymentDetails.amount.trim()) {
      toast.error("Por favor, indica el monto del pago");
      return;
    }
    setIsUploading(true);
    setTimeout(() => {
      setIsUploading(false);
      setPaymentCompleted(true);
      toast.success("¡Comprobante recibido con éxito!");
      setTimeout(() => {
        toast.success(
          <div className="flex flex-col gap-1">
            <p className="font-semibold">Notificación enviada por correo</p>
            <p className="text-sm">Hemos enviado un correo de confirmación con los detalles de tu pago.</p>
          </div>, 
          { duration: 5000 }
        );
      }, 1000);
      const referenceCode = `REF-${Date.now().toString().slice(-6)}`;
      setTimeout(() => {
        navigate("/dashboard", { 
          state: { 
            paymentSuccess: true,
            referenceCode,
            plan: plan.title,
            amount: paymentDetails.amount || plan.price,
            whatsappNotifications
          } 
        });
      }, 3000);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background pt-16 pb-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center text-sm text-muted-foreground hover:text-foreground mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Volver
        </button>
        
        <div className="bg-card rounded-xl shadow-md overflow-hidden border">
          {/* Cabecera */}
          <div className="bg-primary p-6 text-primary-foreground">
            <h1 className="text-2xl font-bold">Checkout - {plan.title}</h1>
            <p className="mt-1 opacity-90">Completa tu pago para continuar</p>
          </div>
          
          <div className="p-6">
            {paymentCompleted ? (
              <div className="text-center py-8">
                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-primary/10">
                  <Check className="h-6 w-6 text-primary" />
                </div>
                <h2 className="mt-4 text-lg font-medium text-foreground">¡Pago recibido!</h2>
                <p className="mt-2 text-sm text-muted-foreground">
                  Estamos procesando tu pago. Se ha enviado una confirmación a tu correo electrónico.
                  {whatsappNotifications && " También recibirás notificaciones por WhatsApp."}
                </p>
                <p className="mt-2 text-sm text-muted-foreground">
                  Serás redirigido a tu dashboard en unos segundos.
                </p>
              </div>
            ) : (
              <>
                <div className="mb-8">
                  <h2 className="text-lg font-medium text-foreground mb-4">Resumen del pedido</h2>
                  <div className="bg-muted/50 rounded-lg p-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-muted-foreground">Plan:</span>
                      <span className="font-medium">{plan.title}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Precio:</span>
                      <span className="font-medium">${plan.price} COP</span>
                    </div>
                    <Separator className="my-4" />
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span>${plan.price} COP</span>
                    </div>
                  </div>
                </div>
                
                <div className="mb-8">
                  <h2 className="text-lg font-medium text-foreground mb-4">Instrucciones de pago</h2>
                  <div className="bg-primary/5 border border-primary/20 rounded-lg p-6 mb-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                      <div>
                        <p className="text-sm text-primary font-medium mb-2">Envía tu pago a este número de Nequi:</p>
                        <div className="flex items-center">
                          <span className="text-2xl font-bold text-primary mr-2">+57 3142135852</span>
                          <button 
                            onClick={copyToClipboard} 
                            className="p-1.5 bg-card rounded-md border border-primary/30 hover:bg-primary/10"
                          >
                            {copied ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4 text-primary" />}
                          </button>
                        </div>
                      </div>
                      <div className="mt-4 sm:mt-0">
                        <div className="w-24 h-24 bg-card p-2 border border-primary/30 rounded-lg">
                          <div className="w-full h-full bg-[url('https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=nequi://qr/57/3142135852/50000')] bg-no-repeat bg-center bg-contain"></div>
                        </div>
                      </div>
                    </div>
                    <ul className="mt-4 space-y-2 text-sm text-primary/80">
                      <li className="flex items-start"><span className="mr-2 font-bold">1.</span><span>Abre la app de Nequi en tu teléfono.</span></li>
                      <li className="flex items-start"><span className="mr-2 font-bold">2.</span><span>Selecciona la opción "Enviar" y envía exactamente ${plan.price} COP al número indicado.</span></li>
                      <li className="flex items-start"><span className="mr-2 font-bold">3.</span><span>Guarda el comprobante de pago (captura de pantalla).</span></li>
                      <li className="flex items-start"><span className="mr-2 font-bold">4.</span><span>Completa el formulario a continuación con los detalles de tu pago y sube el comprobante.</span></li>
                    </ul>
                  </div>
                </div>
                
                <form onSubmit={handleSubmit}>
                  <h2 className="text-lg font-medium text-foreground mb-4">Comprobante y detalles de pago</h2>
                  <div className="space-y-4 mb-6">
                    <div>
                      <label htmlFor="amount" className="block text-sm font-medium text-foreground mb-1">
                        Monto pagado (COP) *
                      </label>
                      <input
                        type="text"
                        id="amount"
                        name="amount"
                        value={paymentDetails.amount}
                        onChange={handlePaymentDetailsChange}
                        placeholder={`${plan.price}`}
                        className="w-full px-4 py-2 border border-border bg-background text-foreground rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="date" className="block text-sm font-medium text-foreground mb-1">
                        Fecha de pago *
                      </label>
                      <input
                        type="date"
                        id="date"
                        name="date"
                        value={paymentDetails.date}
                        onChange={handlePaymentDetailsChange}
                        className="w-full px-4 py-2 border border-border bg-background text-foreground rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="reference" className="block text-sm font-medium text-foreground mb-1">
                        Referencia o número de confirmación (opcional)
                      </label>
                      <input
                        type="text"
                        id="reference"
                        name="reference"
                        value={paymentDetails.reference}
                        onChange={handlePaymentDetailsChange}
                        placeholder="Ej: Código de transacción de Nequi"
                        className="w-full px-4 py-2 border border-border bg-background text-foreground rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                      />
                    </div>
                  </div>
                  
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:bg-muted/50 transition-colors mb-6">
                    <input type="file" id="payment-proof" onChange={handleFileChange} className="hidden" accept="image/*,.pdf" />
                    <label htmlFor="payment-proof" className="cursor-pointer">
                      <div className="mx-auto w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
                        <svg className="w-6 h-6 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                      </div>
                      {uploadedFile ? (
                        <div className="text-sm text-foreground font-medium">
                          Archivo seleccionado: {uploadedFile.name}
                        </div>
                      ) : (
                        <>
                          <p className="text-sm font-medium text-foreground">Haz clic para subir tu comprobante de pago *</p>
                          <p className="text-xs text-muted-foreground mt-1">PNG, JPG o PDF (Max. 10MB)</p>
                        </>
                      )}
                    </label>
                  </div>
                  
                  <div className="flex items-start mb-6 space-x-2">
                    <Checkbox 
                      id="whatsapp-notifications" 
                      checked={whatsappNotifications}
                      onCheckedChange={(checked) => setWhatsappNotifications(checked as boolean)}
                    />
                    <div className="grid gap-1.5 leading-none">
                      <label htmlFor="whatsapp-notifications" className="text-sm font-medium leading-none">
                        También quiero recibir notificaciones por WhatsApp
                      </label>
                      <p className="text-sm text-muted-foreground">
                        Se enviará información sobre el estado del pago y del trabajo académico al WhatsApp +57 3142135852
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start mb-6 space-x-2">
                    <Checkbox id="terms" required />
                    <div className="grid gap-1.5 leading-none">
                      <label htmlFor="terms" className="text-sm font-medium leading-none">
                        Acepto los <a href="/terms-of-service" className="text-primary hover:underline">Términos de Servicio</a> y la <a href="/privacy-policy" className="text-primary hover:underline">Política de Privacidad</a>
                      </label>
                    </div>
                  </div>
                  
                  <Button type="submit" disabled={!uploadedFile || isUploading} className="w-full py-3">
                    {isUploading ? "Procesando..." : "Confirmar Pago"}
                  </Button>
                </form>
              </>
            )}
          </div>
        </div>
        
        <div className="mt-8 bg-card rounded-xl shadow-sm p-6 border">
          <div className="flex items-start">
            <AlertCircle className="w-5 h-5 text-amber-500 mr-3 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-foreground">Información importante</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Una vez verificado tu pago, nos pondremos en contacto contigo para coordinar los detalles de tu trabajo académico.
                Puedes hacer seguimiento del estado de tu pedido desde tu panel personal.
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                <span className="font-medium">¿Prefieres recibir actualizaciones por WhatsApp?</span> Marca la casilla correspondiente
                durante el proceso de pago y te mantendremos informado a través de WhatsApp sobre el estado de tu trabajo.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
