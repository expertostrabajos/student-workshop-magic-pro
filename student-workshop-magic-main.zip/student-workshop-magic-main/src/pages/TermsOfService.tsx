
import Navbar from "@/components/Navbar";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const TermsOfService = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="pt-24 pb-12 md:pt-32 md:pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver al inicio
            </Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Términos de Servicio</h1>
          
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="prose max-w-none">
              <p className="mb-4">
                <strong>Última actualización:</strong> 1 de junio de 2023
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">1. Aceptación de los términos</h2>
              <p className="mb-4">
                Al acceder o utilizar los servicios de StudentHelp, aceptas estar sujeto a estos Términos de Servicio. Si no estás de acuerdo con alguna parte de estos términos, no podrás utilizar nuestros servicios.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">2. Descripción del servicio</h2>
              <p className="mb-4">
                StudentHelp proporciona asistencia académica, incluyendo pero no limitado a: redacción de ensayos, trabajos de investigación, proyectos académicos y revisión de documentos. Nuestros servicios están diseñados para servir como apoyo educativo y referencia para tu propio trabajo académico.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">3. Uso apropiado</h2>
              <p className="mb-4">
                Al utilizar nuestros servicios, te comprometes a:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Utilizar los materiales proporcionados únicamente como referencia y guía</li>
                <li>No presentar el trabajo entregado como propio sin las debidas adaptaciones y citas</li>
                <li>Respetar las políticas de integridad académica de tu institución</li>
                <li>No utilizar nuestros servicios para actividades fraudulentas o plagio</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">4. Calidad y entrega</h2>
              <p className="mb-4">
                Nos comprometemos a entregar trabajos de alta calidad dentro de los plazos acordados. Sin embargo:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>La calidad del trabajo depende de la claridad de tus instrucciones y requisitos</li>
                <li>Los plazos están sujetos a confirmación después de evaluar la complejidad del trabajo</li>
                <li>Nos reservamos el derecho a rechazar solicitudes que consideremos inapropiadas o contrarias a nuestras políticas</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">5. Revisiones y correcciones</h2>
              <p className="mb-4">
                Ofrecemos revisiones gratuitas dentro de los 7 días posteriores a la entrega, siempre que:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Las revisiones solicitadas no alteran sustancialmente el alcance original del trabajo</li>
                <li>Las instrucciones para la revisión sean claras y específicas</li>
                <li>El número de revisiones esté dentro del límite establecido para tu plan contratado</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">6. Pagos y reembolsos</h2>
              <p className="mb-4">
                Las condiciones de pago y política de reembolsos se detallan en nuestra Política de Reembolsos. En general:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>El pago debe realizarse por adelantado para iniciar el trabajo</li>
                <li>Los reembolsos están disponibles en circunstancias específicas y dentro de los plazos establecidos</li>
                <li>Las disputas serán resueltas de manera justa y equitativa</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">7. Propiedad intelectual</h2>
              <p className="mb-4">
                Una vez completado el pago total, recibes una licencia para utilizar el contenido entregado para tu uso personal y académico. Sin embargo:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>No puedes distribuir, vender o publicar el contenido</li>
                <li>StudentHelp conserva el derecho a utilizar trabajos entregados de forma anónima como ejemplos, eliminando toda información identificable</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">8. Limitación de responsabilidad</h2>
              <p className="mb-4">
                StudentHelp proporciona materiales de referencia académica, pero no es responsable de:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>El uso indebido del material por parte del cliente</li>
                <li>Las consecuencias derivadas del incumplimiento de políticas académicas institucionales</li>
                <li>Cualquier penalización impuesta por instituciones educativas</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">9. Terminación</h2>
              <p className="mb-4">
                Nos reservamos el derecho a suspender o terminar el acceso a nuestros servicios si determinamos que ha habido una violación de estos términos o un uso inapropiado de nuestros servicios.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">10. Cambios a los términos</h2>
              <p className="mb-4">
                Podemos modificar estos términos en cualquier momento, publicando la versión actualizada en nuestro sitio web. Tu uso continuado de nuestros servicios después de dichos cambios constituye tu aceptación de los nuevos términos.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">11. Contacto</h2>
              <p className="mb-4">
                Si tienes preguntas sobre estos Términos de Servicio, por favor contáctanos a través de nuestro formulario de contacto o envía un correo electrónico a terms@studenthelp.com.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;
