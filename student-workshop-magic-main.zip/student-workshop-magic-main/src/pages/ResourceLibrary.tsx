
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { 
  BookOpen, 
  Search, 
  Filter, 
  BookMarked,
  Download,
  Share2,
  Bookmark,
  FileText,
  Video,
  GraduationCap,
  Sparkles,
  BookmarkCheck,
  Star,
  ArrowLeft,
  Tag
} from "lucide-react";
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

interface Resource {
  id: string;
  title: string;
  type: "guide" | "template" | "example" | "tutorial" | "reference";
  category: string;
  description: string;
  author: string;
  date: string;
  downloadUrl: string;
  tags: string[];
  rating: number;
  downloads: number;
  bookmarked?: boolean;
}

const ResourceLibrary = () => {
  const [resources, setResources] = useState<Resource[]>([
    {
      id: "1",
      title: "Guía completa para la redacción de tesis",
      type: "guide",
      category: "Tesis",
      description: "Guía detallada con todos los componentes esenciales de una tesis académica y consejos para cada sección.",
      author: "Dra. Marta Rodríguez",
      date: "2025-03-15",
      downloadUrl: "#",
      tags: ["tesis", "estructura", "metodología"],
      rating: 4.8,
      downloads: 1245,
      bookmarked: true
    },
    {
      id: "2",
      title: "Plantilla APA para ensayos académicos",
      type: "template",
      category: "Ensayos",
      description: "Plantilla lista para usar con todos los formatos y estilos APA actualizados a la última edición.",
      author: "Carlos Mendoza",
      date: "2025-02-10",
      downloadUrl: "#",
      tags: ["APA", "ensayo", "formato"],
      rating: 4.6,
      downloads: 2789
    },
    {
      id: "3",
      title: "50 ejemplos de análisis literario",
      type: "example",
      category: "Literatura",
      description: "Colección de análisis literarios de diferentes obras clásicas y contemporáneas.",
      author: "Prof. Laura Gómez",
      date: "2025-01-20",
      downloadUrl: "#",
      tags: ["literatura", "análisis", "ejemplos"],
      rating: 4.7,
      downloads: 1876
    },
    {
      id: "4",
      title: "Tutorial: Cómo usar fuentes primarias en historia",
      type: "tutorial",
      category: "Historia",
      description: "Guía paso a paso para identificar, analizar e incorporar fuentes primarias en trabajos de historia.",
      author: "Dr. Andrés Fernández",
      date: "2024-12-05",
      downloadUrl: "#",
      tags: ["historia", "fuentes primarias", "investigación"],
      rating: 4.5,
      downloads: 923
    },
    {
      id: "5",
      title: "Manual de estadística para ciencias sociales",
      type: "reference",
      category: "Estadística",
      description: "Referencia completa de métodos estadísticos aplicados a investigaciones en ciencias sociales.",
      author: "Dra. Patricia Vargas",
      date: "2025-03-01",
      downloadUrl: "#",
      tags: ["estadística", "SPSS", "análisis cuantitativo"],
      rating: 4.9,
      downloads: 3421
    },
    {
      id: "6",
      title: "Ejemplos de proyectos de investigación en psicología",
      type: "example",
      category: "Psicología",
      description: "Proyectos de investigación en diversas áreas de la psicología con metodologías detalladas.",
      author: "Prof. Ramón Suárez",
      date: "2025-02-28",
      downloadUrl: "#",
      tags: ["psicología", "investigación", "metodología"],
      rating: 4.4,
      downloads: 1587
    }
  ]);
  
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeType, setActiveType] = useState<string | null>(null);
  
  const categories = Array.from(new Set(resources.map(resource => resource.category)));
  const types = [
    { id: "guide", label: "Guías" },
    { id: "template", label: "Plantillas" },
    { id: "example", label: "Ejemplos" },
    { id: "tutorial", label: "Tutoriales" },
    { id: "reference", label: "Referencias" }
  ];
  
  const filteredResources = resources.filter(resource => {
    const matchesSearch = searchTerm === "" || 
                          resource.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          resource.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          resource.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = activeCategory === null || resource.category === activeCategory;
    
    const matchesType = activeType === null || resource.type === activeType;
    
    return matchesSearch && matchesCategory && matchesType;
  });

  const toggleBookmark = (id: string) => {
    setResources(prevResources => 
      prevResources.map(resource => 
        resource.id === id ? { ...resource, bookmarked: !resource.bookmarked } : resource
      )
    );
    
    const resource = resources.find(r => r.id === id);
    if (resource) {
      toast.success(
        resource.bookmarked 
          ? "Recurso eliminado de guardados" 
          : "Recurso guardado para acceso rápido"
      );
    }
  };
  
  const handleDownload = (resource: Resource) => {
    toast.success(`Descargando "${resource.title}"`);
    // En una implementación real, esto iniciaría la descarga del archivo
  };
  
  const getTypeIcon = (type: string) => {
    switch (type) {
      case "guide":
        return <BookOpen className="h-5 w-5 text-blue-500" />;
      case "template":
        return <FileText className="h-5 w-5 text-green-500" />;
      case "example":
        return <BookMarked className="h-5 w-5 text-purple-500" />;
      case "tutorial":
        return <Video className="h-5 w-5 text-red-500" />;
      case "reference":
        return <GraduationCap className="h-5 w-5 text-amber-500" />;
      default:
        return <BookOpen className="h-5 w-5 text-gray-500" />;
    }
  };
  
  const getTypeLabel = (type: string) => {
    switch (type) {
      case "guide": return "Guía";
      case "template": return "Plantilla";
      case "example": return "Ejemplo";
      case "tutorial": return "Tutorial";
      case "reference": return "Referencia";
      default: return type;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <div className="flex items-center">
              <Link to="/" className="text-blue-600 hover:text-blue-800 flex items-center mr-4">
                <ArrowLeft className="h-4 w-4 mr-1" />
                <span>Volver</span>
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">Biblioteca de Recursos Académicos</h1>
            </div>
            <p className="text-gray-600">Guías, plantillas y ejemplos para tus trabajos académicos</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar recursos académicos..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="w-full">
                    <Filter className="h-4 w-4 mr-2" />
                    {activeCategory ? activeCategory : "Filtrar por categoría"}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setActiveCategory(null)}>
                    Todas las categorías
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  {categories.map(category => (
                    <DropdownMenuItem 
                      key={category} 
                      onClick={() => setActiveCategory(category)}
                    >
                      {category}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            
            <div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="w-full">
                    <Tag className="h-4 w-4 mr-2" />
                    {activeType ? getTypeLabel(activeType) : "Filtrar por tipo"}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setActiveType(null)}>
                    Todos los tipos
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  {types.map(type => (
                    <DropdownMenuItem 
                      key={type.id} 
                      onClick={() => setActiveType(type.id)}
                    >
                      {type.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
        
        <Tabs defaultValue="all" className="mb-6">
          <TabsList>
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="bookmarked">Guardados</TabsTrigger>
            <TabsTrigger value="popular">Más populares</TabsTrigger>
            <TabsTrigger value="recent">Recientes</TabsTrigger>
          </TabsList>
        </Tabs>
        
        {filteredResources.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredResources.map(resource => (
              <Card key={resource.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <CardHeader className="p-4 pb-2">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      {getTypeIcon(resource.type)}
                      <Badge className="ml-2" variant="outline">
                        {getTypeLabel(resource.type)}
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => toggleBookmark(resource.id)}
                      className="h-8 w-8"
                    >
                      {resource.bookmarked ? (
                        <BookmarkCheck className="h-5 w-5 text-blue-500" />
                      ) : (
                        <Bookmark className="h-5 w-5" />
                      )}
                    </Button>
                  </div>
                  <CardTitle className="mt-2 text-lg">
                    {resource.title}
                  </CardTitle>
                  <CardDescription className="line-clamp-2">
                    {resource.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="flex flex-wrap gap-1 mb-3">
                    {resource.tags.map((tag, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <Separator className="my-3" />
                  <div className="flex items-center justify-between text-sm">
                    <div>
                      <p className="text-gray-500 text-xs">Por {resource.author}</p>
                      <div className="flex items-center mt-1">
                        <Star className="h-4 w-4 text-yellow-400 mr-1" />
                        <span className="text-gray-700">{resource.rating.toFixed(1)}</span>
                        <span className="mx-2 text-gray-300">•</span>
                        <span className="text-gray-500">{resource.downloads} descargas</span>
                      </div>
                    </div>
                    <div className="flex space-x-1">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="h-8 px-2"
                        onClick={() => handleDownload(resource)}
                      >
                        <Download className="h-4 w-4 mr-1" />
                        Descargar
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow p-10 text-center">
            <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-800 mb-1">No se encontraron recursos</h3>
            <p className="text-gray-500 max-w-md mx-auto">
              No encontramos recursos que coincidan con tus criterios de búsqueda. Intenta ajustar los filtros o buscar con otros términos.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResourceLibrary;
