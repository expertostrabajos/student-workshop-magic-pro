
import Navbar from "@/components/Navbar";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="pt-24 pb-12 md:pt-32 md:pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver al inicio
            </Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Política de Privacidad</h1>
          
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="prose max-w-none">
              <p className="mb-4">
                <strong>Última actualización:</strong> 1 de junio de 2023
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">1. Información que recopilamos</h2>
              <p className="mb-4">
                En StudentHelp, valoramos tu privacidad y nos comprometemos a proteger tus datos personales. Recopilamos la siguiente información:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Información de contacto: nombre, correo electrónico, número de teléfono</li>
                <li>Información académica: institución educativa, nivel de estudios, cursos</li>
                <li>Detalles de los trabajos solicitados y documentos proporcionados</li>
                <li>Información de pago: procesada de manera segura a través de nuestros proveedores de pago (Nequi)</li>
                <li>Archivos y documentos que subas a nuestra plataforma</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">2. Cómo utilizamos tu información</h2>
              <p className="mb-4">
                Utilizamos la información recopilada para:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Proporcionar y mejorar nuestros servicios académicos</li>
                <li>Procesar tus solicitudes y pagos</li>
                <li>Comunicarnos contigo sobre tu trabajo y actualizaciones del servicio</li>
                <li>Personalizar tu experiencia en nuestra plataforma</li>
                <li>Cumplir con nuestras obligaciones legales</li>
                <li>Gestionar y almacenar los archivos que compartes con nosotros para la realización de trabajos académicos</li>
                <li>Enviar notificaciones sobre el estado de tu solicitud y comunicaciones relacionadas con tu trabajo</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">3. Almacenamiento y protección de archivos</h2>
              <p className="mb-4">
                Todos los archivos que subes a nuestra plataforma:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Son almacenados en servidores seguros con cifrado</li>
                <li>Solo son accesibles para el personal autorizado involucrado en la realización de tu trabajo</li>
                <li>Se utilizan exclusivamente para el propósito de completar tu solicitud académica</li>
                <li>Se conservan por un período limitado después de completar tu trabajo para posibles consultas o revisiones</li>
              </ul>
              <p className="mb-4">
                No compartimos tus archivos con terceros no autorizados y aplicamos estrictas medidas de seguridad para proteger tu información.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">4. Protección de datos</h2>
              <p className="mb-4">
                Implementamos medidas de seguridad técnicas y organizativas para proteger tus datos personales contra acceso no autorizado, pérdida o alteración. Todos los documentos y trabajos académicos se tratan con la más estricta confidencialidad.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">5. Procesamiento de pagos</h2>
              <p className="mb-4">
                Actualmente, aceptamos pagos exclusivamente a través de Nequi. Cuando realizas un pago:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>No almacenamos datos completos de tarjetas de crédito ni información bancaria sensible</li>
                <li>Las transacciones son procesadas a través de conexiones seguras</li>
                <li>Mantenemos registros de transacciones con fines contables y de servicio al cliente</li>
                <li>Los comprobantes de pago que subas se almacenan de forma segura y solo se utilizan para verificar tu transacción</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">6. Compartir información</h2>
              <p className="mb-4">
                No vendemos ni compartimos tu información personal con terceros, excepto:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Con nuestros expertos académicos para completar tu trabajo (bajo estrictos acuerdos de confidencialidad)</li>
                <li>Con proveedores de servicios que nos ayudan a operar nuestra plataforma</li>
                <li>Cuando sea requerido por ley o en respuesta a procesos legales</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">7. Tus derechos</h2>
              <p className="mb-4">
                Tienes derecho a:
              </p>
              <ul className="list-disc ml-6 mb-4">
                <li>Acceder a tus datos personales</li>
                <li>Corregir información inexacta</li>
                <li>Solicitar la eliminación de tus datos</li>
                <li>Oponerte al procesamiento de tus datos</li>
                <li>Retirar tu consentimiento en cualquier momento</li>
                <li>Solicitar copias de los archivos que has subido a nuestra plataforma</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">8. Cookies y tecnologías similares</h2>
              <p className="mb-4">
                Utilizamos cookies y tecnologías similares para mejorar tu experiencia en nuestro sitio, recordar tus preferencias y analizar el tráfico. Puedes gestionar tus preferencias de cookies a través de la configuración de tu navegador.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">9. Cambios a esta política</h2>
              <p className="mb-4">
                Podemos actualizar esta política de privacidad periódicamente. Te notificaremos sobre cambios significativos mediante un aviso en nuestro sitio web o por correo electrónico.
              </p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">10. Contacto</h2>
              <p className="mb-4">
                Si tienes preguntas o inquietudes sobre nuestra política de privacidad o el manejo de tus datos personales, por favor contáctanos a través de nuestro formulario de contacto o envía un correo electrónico a privacy@studenthelp.com.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
