
import Navbar from "@/components/Navbar";
import { ArrowLeft, PlayCircle, BookOpen, ClipboardCheck, Clock, Mail } from "lucide-react";
import { Link } from "react-router-dom";

const HowItWorks = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="pt-24 pb-12 md:pt-32 md:pb-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver al inicio
            </Link>
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Cómo Funciona StudentHelp</h1>
          <p className="text-lg text-gray-600 mb-10">Una guía paso a paso para utilizar nuestros servicios académicos</p>
          
          <div className="mb-16">
            <div className="relative aspect-w-16 aspect-h-9 rounded-xl overflow-hidden">
              <iframe
                className="absolute w-full h-full"
                src="https://www.youtube.com/embed/dQw4w9WgXcQ" // Este es un placeholder, reemplaza con el ID real
                title="Tutorial: Cómo usar StudentHelp"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-green-500 mb-4">
                <ClipboardCheck className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-semibold mb-3">1. Envía tu solicitud</h3>
              <p className="text-gray-600">
                Completa el formulario de solicitud con todos los detalles de tu trabajo académico. Sé específico sobre el tema, extensión, estilo de citación y cualquier requisito especial.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-green-500 mb-4">
                <Clock className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-semibold mb-3">2. Recibe tu cotización</h3>
              <p className="text-gray-600">
                Recibirás una cotización personalizada basada en la complejidad y el plazo de tu trabajo. Una vez que apruebes y realices el pago, asignaremos el experto ideal para tu proyecto.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-green-500 mb-4">
                <BookOpen className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-semibold mb-3">3. Seguimiento del progreso</h3>
              <p className="text-gray-600">
                Podrás seguir el progreso de tu trabajo a través de tu cuenta. Te mantendremos informado en cada etapa, desde la asignación hasta la revisión final.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-green-500 mb-4">
                <Mail className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-semibold mb-3">4. Recibe tu trabajo</h3>
              <p className="text-gray-600">
                Recibirás tu trabajo finalizado antes del plazo acordado. Cada trabajo pasa por un riguroso control de calidad para garantizar la originalidad y excelencia académica.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-green-500 mb-4">
                <PlayCircle className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-semibold mb-3">5. Solicita revisiones</h3>
              <p className="text-gray-600">
                Si necesitas cambios, puedes solicitar revisiones gratuitas dentro de los 7 días posteriores a la entrega. Estamos comprometidos con tu satisfacción total.
              </p>
            </div>
          </div>
          
          <div className="bg-white p-8 rounded-lg shadow-sm mb-16">
            <h2 className="text-2xl font-semibold mb-4">Preguntas frecuentes sobre el proceso</h2>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">¿Cómo elegir el tipo de trabajo correcto?</h3>
                <p className="text-gray-600">
                  En el formulario de solicitud, selecciona el tipo de trabajo que mejor se adapte a tus necesidades. Si no estás seguro, selecciona "Otro" y describe tu trabajo. Nuestro equipo te guiará al formato correcto.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">¿Qué información debo incluir en mi solicitud?</h3>
                <p className="text-gray-600">
                  Para obtener el mejor resultado, incluye: instrucciones detalladas, rúbricas o guías proporcionadas por tu profesor, ejemplos de trabajos anteriores si los tienes, fuentes específicas si son requeridas, y el estilo de citación (APA, MLA, Chicago, etc.).
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">¿Cómo funciona el sistema de revisiones?</h3>
                <p className="text-gray-600">
                  Después de recibir tu trabajo, puedes solicitar revisiones a través de tu cuenta. Especifica claramente los cambios necesarios, y nuestro experto realizará las modificaciones correspondientes. El número de revisiones gratuitas depende del plan contratado.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">¿Qué hago si tengo problemas con la entrega?</h3>
                <p className="text-gray-600">
                  Si experimentas cualquier problema con la entrega de tu trabajo, contacta inmediatamente a nuestro servicio de atención al cliente a través del chat o correo electrónico. Nuestro equipo está disponible 24/7 para asistirte.
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <h2 className="text-2xl font-semibold mb-6">¿Listo para comenzar?</h2>
            <Link
              to="/#solicitar"
              className="inline-block bg-green-500 text-white px-8 py-3 rounded-lg hover:bg-green-600 transition-colors duration-300"
            >
              Solicitar trabajo académico
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HowItWorks;
