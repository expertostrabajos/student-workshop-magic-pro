import React from "react";
import { Link } from "react-router-dom";
import { 
  Calendar, 
  MessageSquare, 
  BarChart3, 
  CreditCard, 
  Library,
  Smartphone,
  ArrowLeft
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import CalendarScheduler from "@/components/CalendarScheduler";
import EnhancedProgressTracker from "@/components/EnhancedProgressTracker";
import EnhancedPaymentSystem from "@/components/EnhancedPaymentSystem";
import RecommendationSystem from "@/components/RecommendationSystem";

// Añadir importación del nuevo componente de mensajería directa
import DirectMessaging from "@/components/DirectMessaging";
import MobileDashboard from "@/components/MobileDashboard";

// En el componente AcademicTools, añadir las nuevas herramientas
const AcademicTools = () => {

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Herramientas Académicas</h1>
          <p className="text-gray-600">
            Conjunto integrado de herramientas para apoyar tu éxito académico
          </p>
        </div>

        <Tabs defaultValue="calendar">
          <div className="flex justify-between items-center mb-6">
            <TabsList>
              <TabsTrigger value="calendar">
                <Calendar className="h-4 w-4 mr-2" />
                Calendario
              </TabsTrigger>
              <TabsTrigger value="chat">
                <MessageSquare className="h-4 w-4 mr-2" />
                Chat con Tutores
              </TabsTrigger>
              <TabsTrigger value="progress">
                <BarChart3 className="h-4 w-4 mr-2" />
                Progreso
              </TabsTrigger>
              <TabsTrigger value="payments">
                <CreditCard className="h-4 w-4 mr-2" />
                Pagos
              </TabsTrigger>
              <TabsTrigger value="recommendations">
                <Library className="h-4 w-4 mr-2" />
                Recomendaciones
              </TabsTrigger>
              <TabsTrigger value="mobile">
                <Smartphone className="h-4 w-4 mr-2" />
                Móvil
              </TabsTrigger>
            </TabsList>
            <Link to="/dashboard">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver a Dashboard
              </Button>
            </Link>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
            <TabsContent value="calendar">
              <CalendarScheduler />
            </TabsContent>
            
            <TabsContent value="chat">
              <DirectMessaging />
            </TabsContent>
            
            <TabsContent value="progress">
              <EnhancedProgressTracker />
            </TabsContent>
            
            <TabsContent value="payments">
              <EnhancedPaymentSystem />
            </TabsContent>
            
            <TabsContent value="recommendations">
              <RecommendationSystem />
            </TabsContent>
            
            <TabsContent value="mobile">
              <MobileDashboard />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
};

export default AcademicTools;
