
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { 
  CreditCard, FileText, Clock, BarChart4, Eye, BookOpen, FolderOpen, Calendar,
  MessageSquare, GraduationCap, Lightbulb
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import WorkProgressTracker from "@/components/WorkProgressTracker";
import NotificationCenter from "@/components/NotificationCenter";
import { useNotificationContext } from "@/components/NotificationProvider";

interface Payment {
  id: string; date: string; amount: string; plan: string;
  status: "pending" | "verified" | "rejected";
}

interface Assignment {
  id: string; title: string; subject: string; deadline: string;
  status: "pending" | "in_progress" | "review" | "completed"; progress: number;
}

const statusLabels = {
  pending: { label: "Pendiente", color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400" },
  verified: { label: "Verificado", color: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" },
  rejected: { label: "Rechazado", color: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400" },
  in_progress: { label: "En progreso", color: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400" },
  review: { label: "En revisión", color: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400" },
  completed: { label: "Completado", color: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" }
};

const Dashboard = () => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [activeTab, setActiveTab] = useState<"assignments" | "payments" | "progress">("progress");
  const { notifications, unreadCount, markAsRead, markAllAsRead, removeNotification, addNotification } = useNotificationContext();

  useEffect(() => {
    const timer = setTimeout(() => {
      if (notifications.length === 0) {
        addNotification({
          title: "¡Bienvenido al dashboard!",
          message: "Ahora puedes recibir notificaciones sobre el progreso de tus trabajos.",
          type: "info"
        });
      }
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  const getStatusBadge = (status: string) => {
    const statusInfo = statusLabels[status as keyof typeof statusLabels];
    return (
      <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${statusInfo.color}`}>
        {statusInfo.label}
      </span>
    );
  };

  const getProgressBar = (progress: number) => (
    <div className="w-full bg-muted rounded-full h-2.5 mt-2">
      <div className="bg-primary h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Dashboard del Estudiante</h1>
            <p className="text-muted-foreground">Gestiona tus pagos y trabajos académicos</p>
          </div>
          <div className="flex items-center space-x-3">
            <NotificationCenter 
              notifications={notifications} unreadCount={unreadCount}
              onMarkAsRead={markAsRead} onMarkAllAsRead={markAllAsRead} onRemove={removeNotification}
            />
            <Button asChild>
              <Link to="/">Solicitar Nuevo Trabajo</Link>
            </Button>
          </div>
        </div>
        
        <div className="mb-8 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-4 shadow-sm">
          <div className="flex items-start">
            <div className="shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/50 mr-3">
              <svg className="w-5 h-5 text-blue-500" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4 11.9V16.8C4 17.9201 4 18.4802 4.21799 18.908C4.40973 19.2843 4.71569 19.5903 5.09202 19.782C5.51984 20 6.07989 20 7.2 20H16.8C17.9201 20 18.4802 20 18.908 19.782C19.2843 19.5903 19.5903 19.2843 19.782 18.908C20 18.4802 20 17.9201 20 16.8V11.9M4 11.9V7.2C4 6.07989 4 5.51984 4.21799 5.09202C4.40973 4.71569 4.71569 4.40973 5.09202 4.21799C5.51984 4 6.07989 4 7.2 4H16.8C17.9201 4 18.4802 4 18.908 4.21799C19.2843 4.40973 19.5903 4.71569 19.782 5.09202C20 5.51984 20 6.07989 20 7.2V11.9M4 11.9H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M8 8L16 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M8 12L16 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M8 16L16 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div>
              <h3 className="font-medium text-blue-800 dark:text-blue-300">Recibe notificaciones por WhatsApp</h3>
              <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">
                ¿Quieres recibir actualizaciones sobre el estado de tu trabajo directamente a tu WhatsApp? 
                Puedes solicitarlo al momento de realizar tu pago o escribirnos al número <span className="font-medium">+57 3142135852</span> 
                con tu ID de trabajo.
              </p>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pagos Realizados</CardTitle>
              <CreditCard className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0</div>
              <p className="text-xs text-muted-foreground">0 verificados</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Trabajos Activos</CardTitle>
              <FileText className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0</div>
              <p className="text-xs text-muted-foreground">0 en progreso</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Próxima Entrega</CardTitle>
              <Clock className="h-4 w-4 text-amber-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">N/A</div>
              <p className="text-xs text-muted-foreground">No hay entregas pendientes</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Biblioteca</CardTitle>
              <FolderOpen className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">
                <Link to="/document-library" className="text-primary hover:underline">Ver documentos</Link>
              </p>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="md:col-span-3">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Tus Documentos Recientes</CardTitle>
                <CardDescription>Accede rápidamente a tus materiales y trabajos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 text-blue-500 mr-3" />
                      <div>
                        <p className="text-sm font-medium">Instrucciones para ensayo.pdf</p>
                        <p className="text-xs text-muted-foreground">PDF • 2.3 MB • Subido el 7 de abril</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">Ver</Button>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 text-blue-500 mr-3" />
                      <div>
                        <p className="text-sm font-medium">Referencias bibliográficas.docx</p>
                        <p className="text-xs text-muted-foreground">Word • 1.1 MB • Subido el 6 de abril</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">Ver</Button>
                  </div>
                </div>
                <div className="mt-4 text-center">
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/document-library">
                      <FolderOpen className="h-4 w-4 mr-2" />
                      Ver Todos los Documentos
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          <Card>
            <CardHeader><CardTitle>Acciones Rápidas</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              <Button asChild variant="outline" className="w-full justify-start">
                <Link to="/document-library"><FolderOpen className="h-4 w-4 mr-2" />Biblioteca de Documentos</Link>
              </Button>
              <Button asChild variant="outline" className="w-full justify-start">
                <Link to="/"><FileText className="h-4 w-4 mr-2" />Solicitar Nuevo Trabajo</Link>
              </Button>
              <Button asChild variant="outline" className="w-full justify-start">
                <Link to="/academic-tools"><GraduationCap className="h-4 w-4 mr-2" />Herramientas Académicas</Link>
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <CreditCard className="h-4 w-4 mr-2" />Realizar Pago
              </Button>
            </CardContent>
          </Card>
        </div>
        
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Herramientas Académicas</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
            <Link to="/academic-tools?tab=calendar">
              <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                  <Calendar className="h-10 w-10 text-blue-500 mb-3" />
                  <h3 className="font-medium">Calendario</h3>
                  <p className="text-xs text-muted-foreground mt-1">Gestiona tus fechas y plazos</p>
                </CardContent>
              </Card>
            </Link>
            <Link to="/academic-tools?tab=chat">
              <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                  <MessageSquare className="h-10 w-10 text-primary mb-3" />
                  <h3 className="font-medium">Chat con Tutores</h3>
                  <p className="text-xs text-muted-foreground mt-1">Resuelve dudas en tiempo real</p>
                </CardContent>
              </Card>
            </Link>
            <Link to="/academic-tools?tab=progress">
              <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                  <BarChart4 className="h-10 w-10 text-purple-500 mb-3" />
                  <h3 className="font-medium">Seguimiento</h3>
                  <p className="text-xs text-muted-foreground mt-1">Controla el progreso de tus trabajos</p>
                </CardContent>
              </Card>
            </Link>
            <Link to="/academic-tools?tab=payment">
              <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                  <CreditCard className="h-10 w-10 text-red-500 mb-3" />
                  <h3 className="font-medium">Pagos</h3>
                  <p className="text-xs text-muted-foreground mt-1">Gestiona tus transacciones</p>
                </CardContent>
              </Card>
            </Link>
            <Link to="/academic-tools?tab=recommendations">
              <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                  <Lightbulb className="h-10 w-10 text-amber-500 mb-3" />
                  <h3 className="font-medium">Recomendaciones</h3>
                  <p className="text-xs text-muted-foreground mt-1">Recursos personalizados</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
        
        <Tabs defaultValue="progress" value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 md:w-auto">
            <TabsTrigger value="progress"><Eye className="w-4 h-4 mr-2" />Progreso</TabsTrigger>
            <TabsTrigger value="assignments"><BookOpen className="w-4 h-4 mr-2" />Mis Trabajos</TabsTrigger>
            <TabsTrigger value="payments"><CreditCard className="w-4 h-4 mr-2" />Mis Pagos</TabsTrigger>
          </TabsList>
          
          <TabsContent value="progress" className="space-y-6"><WorkProgressTracker /></TabsContent>
          
          <TabsContent value="assignments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Trabajos Académicos</CardTitle>
                <CardDescription>Revisa el estado de tus trabajos académicos.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-muted-foreground">No tienes trabajos académicos activos.</p>
                  <Button asChild className="mt-4"><Link to="/">Solicitar un trabajo</Link></Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="payments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Historial de Pagos</CardTitle>
                <CardDescription>Revisa tus pagos y su estado actual.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <CreditCard className="h-12 w-12 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-muted-foreground">No tienes pagos registrados.</p>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <p className="text-xs text-muted-foreground">Los pagos pueden tardar hasta 24 horas en ser verificados.</p>
                <Button variant="outline" size="sm">Exportar registro</Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Dashboard;
