import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Session, User } from '@supabase/supabase-js';
import { toast } from "sonner";

type AuthContextType = {
  session: Session | null;
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, metadata?: { [key: string]: any }) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  checkAdminStatus: () => Promise<boolean>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  // Función para verificar si un usuario es administrador
  const checkAdminStatus = async (): Promise<boolean> => {
    if (!user) return false;
    
    try {
      // Verificar el rol en la tabla user_roles
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (error) {
        console.error("Error checking admin status:", error);
        // Si hay error (por ejemplo, la tabla no existe o RLS bloquea), no es admin
        setIsAdmin(false);
        return false;
      }
      
      // Si no hay datos, el usuario no tiene rol asignado
      if (!data) {
        setIsAdmin(false);
        return false;
      }
      
      const adminStatus = data.role === 'admin';
      setIsAdmin(adminStatus);
      return adminStatus;
    } catch (error) {
      console.error("Error checking admin status:", error);
      setIsAdmin(false);
      return false;
    }
  };

  useEffect(() => {
    // Primero configurar el listener de cambios de auth
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log(`Supabase auth event: ${event}`);
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        // Usar setTimeout para evitar deadlock
        setTimeout(() => {
          checkAdminStatus();
        }, 0);
      } else {
        setIsAdmin(false);
      }
      
      setLoading(false);
    });

    // Luego verificar si hay una sesión activa
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        setTimeout(() => {
          checkAdminStatus();
        }, 0);
      }
      
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast.error("Error al iniciar sesión", {
          description: error.message,
        });
        throw error;
      }

      toast.success("¡Inicio de sesión exitoso!");
      
      // Verificar si es administrador después de iniciar sesión
      await checkAdminStatus();
      
    } catch (error) {
      console.error("Error signing in:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, metadata?: { [key: string]: any }) => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: metadata,
        },
      });

      if (error) {
        toast.error("Error al registrarse", {
          description: error.message,
        });
        throw error;
      }

      toast.success("¡Registro exitoso!", {
        description: "Por favor verifica tu correo electrónico para confirmar tu cuenta."
      });
    } catch (error) {
      console.error("Error signing up:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        toast.error("Error al cerrar sesión", {
          description: error.message,
        });
        throw error;
      }
      
      setIsAdmin(false);
      toast.success("¡Sesión cerrada correctamente!");
    } catch (error) {
      console.error("Error signing out:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async (email: string) => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin + '/reset-password',
      });
      
      if (error) {
        toast.error("Error al enviar el correo de recuperación", {
          description: error.message,
        });
        throw error;
      }
      
      toast.success("Correo de recuperación enviado", {
        description: "Revisa tu bandeja de entrada para recuperar tu contraseña."
      });
    } catch (error) {
      console.error("Error resetting password:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{
      session,
      user,
      loading,
      isAdmin,
      signIn,
      signUp,
      signOut,
      resetPassword,
      checkAdminStatus,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
