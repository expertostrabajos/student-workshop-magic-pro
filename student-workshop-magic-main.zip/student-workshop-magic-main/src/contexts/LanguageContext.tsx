
import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';

type LanguageContextType = {
  currentLanguage: string;
  setLanguage: (code: string) => void;
  isTranslating: boolean;
  setIsTranslating: (state: boolean) => void;
  initTranslate: () => void;
  isTranslateReady: boolean;
};

const LanguageContext = createContext<LanguageContextType>({
  currentLanguage: 'es', 
  setLanguage: () => {},
  isTranslating: false,
  setIsTranslating: () => {},
  initTranslate: () => {},
  isTranslateReady: false,
});

export const useLanguage = () => useContext(LanguageContext);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState<string>(() => {
    return localStorage.getItem('preferredLanguage') || 'es';
  });
  const [isTranslating, setIsTranslating] = useState(false);
  const [isTranslateReady, setIsTranslateReady] = useState(false);
  const initCalledRef = useRef(false);

  useEffect(() => {
    localStorage.setItem('preferredLanguage', currentLanguage);
  }, [currentLanguage]);

  // Only load Google Translate when explicitly requested
  const initTranslate = useCallback(() => {
    if (initCalledRef.current || document.getElementById("google-translate-script")) {
      return;
    }
    initCalledRef.current = true;

    // Add CSS fix
    const style = document.createElement("style");
    style.textContent = `
      .goog-te-banner-frame { display: none !important; }
      body { top: 0 !important; }
      .goog-tooltip { display: none !important; }
      .goog-text-highlight { background-color: transparent !important; box-shadow: none !important; }
      .goog-te-gadget { margin: 0 !important; padding: 0 !important; }
      .goog-te-combo { padding: 6px 10px !important; border-radius: 4px !important; border: 1px solid #ccc !important; font-size: 14px !important; background-color: white !important; color: #333 !important; width: 100% !important; max-width: 200px !important; }
    `;
    document.head.appendChild(style);

    window.googleTranslateElementInit = () => {
      try {
        if (window.google?.translate?.TranslateElement) {
          new window.google.translate.TranslateElement(
            {
              pageLanguage: "es",
              includedLanguages: "af,sq,am,ar,hy,az,eu,be,bn,bs,bg,ca,ceb,zh-CN,zh-TW,co,hr,cs,da,nl,en,eo,et,fi,fr,fy,gl,ka,de,el,gu,ht,ha,haw,he,hi,hmn,hu,is,ig,id,ga,it,ja,jv,kn,kk,km,ko,ku,ky,lo,la,lv,lt,lb,mk,mg,ms,ml,mt,mi,mr,mn,my,ne,no,ny,ps,fa,pl,pt,pa,ro,ru,sm,gd,sr,st,sn,sd,si,sk,sl,so,es,su,sw,sv,tl,tg,ta,te,th,tr,uk,ur,ug,uz,vi,cy,xh,yi,yo,zu",
              autoDisplay: false,
            },
            "google-translate-element"
          );
          setIsTranslateReady(true);

          if (currentLanguage !== 'es') {
            setTimeout(() => {
              const selectElement = document.querySelector('.goog-te-combo') as HTMLSelectElement;
              if (selectElement) {
                selectElement.value = currentLanguage;
                selectElement.dispatchEvent(new Event('change'));
              }
            }, 1000);
          }
        }
      } catch (error) {
        console.warn("Google Translate initialization skipped:", error);
      }
    };

    const script = document.createElement("script");
    script.src = "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
    script.id = "google-translate-script";
    script.async = true;
    document.body.appendChild(script);
  }, [currentLanguage]);

  const setLanguage = useCallback((code: string) => {
    setIsTranslating(true);
    setCurrentLanguage(code);

    // Init translate if not yet loaded
    if (!initCalledRef.current) {
      initTranslate();
      // Wait for script to load then apply
      const waitForTranslate = setInterval(() => {
        const selectElement = document.querySelector('.goog-te-combo') as HTMLSelectElement;
        if (selectElement) {
          clearInterval(waitForTranslate);
          selectElement.value = code;
          selectElement.dispatchEvent(new Event('change'));
          setTimeout(() => setIsTranslating(false), 3000);
        }
      }, 500);
      // Timeout fallback
      setTimeout(() => {
        clearInterval(waitForTranslate);
        setIsTranslating(false);
      }, 10000);
      return;
    }

    try {
      const selectElement = document.querySelector('.goog-te-combo') as HTMLSelectElement;
      if (selectElement) {
        selectElement.value = code;
        selectElement.dispatchEvent(new Event('change'));
        setTimeout(() => setIsTranslating(false), 3000);
      } else {
        setIsTranslating(false);
      }
    } catch (error) {
      console.error("Error changing language:", error);
      setIsTranslating(false);
    }
  }, [initTranslate]);

  return (
    <LanguageContext.Provider value={{ currentLanguage, setLanguage, isTranslating, setIsTranslating, initTranslate, isTranslateReady }}>
      <div id="google-translate-element" className="hidden"></div>
      {children}
    </LanguageContext.Provider>
  );
};

declare global {
  interface Window {
    googleTranslateElementInit: () => void;
    google: {
      translate: {
        TranslateElement: any;
      };
    };
  }
}
