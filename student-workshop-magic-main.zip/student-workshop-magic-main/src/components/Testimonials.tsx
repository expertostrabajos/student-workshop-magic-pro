
import { useState } from "react";
import { Star, Quote, ThumbsUp, MessageSquare, User } from "lucide-react";

interface Testimonial {
  id: string;
  name: string;
  role: string;
  institution: string;
  content: string;
  rating: number;
  avatar?: string;
}

const testimonials: Testimonial[] = [
  {
    id: "1",
    name: "Ana Martínez",
    role: "Estudiante",
    institution: "Universidad Nacional",
    content: "El servicio superó mis expectativas. Mi ensayo fue entregado a tiempo y la calidad fue excepcional. Definitivamente volveré a utilizar StudentHelp para futuros trabajos.",
    rating: 5,
    avatar: "https://randomuser.me/api/portraits/women/12.jpg"
  },
  {
    id: "2",
    name: "Carlos Rodríguez",
    role: "Estudiante de Maestría",
    institution: "Universidad de los Andes",
    content: "Mi proyecto de investigación requería un análisis estadístico complejo que no estaba seguro de cómo abordar. El equipo de StudentHelp no solo entregó un trabajo excelente, sino que también me explicó la metodología utilizada.",
    rating: 5,
    avatar: "https://randomuser.me/api/portraits/men/32.jpg"
  },
  {
    id: "3",
    name: "Laura Gómez",
    role: "Estudiante de Doctorado",
    institution: "Universidad del Rosario",
    content: "He utilizado varios servicios similares en el pasado, pero StudentHelp es por lejos el mejor. La atención personalizada y la calidad del trabajo académico son incomparables.",
    rating: 4,
    avatar: "https://randomuser.me/api/portraits/women/44.jpg"
  },
  {
    id: "4",
    name: "Miguel Ángel",
    role: "Estudiante",
    institution: "Universidad de Antioquia",
    content: "Necesitaba ayuda urgente con mi ensayo de literatura y StudentHelp respondió en tiempo récord. El resultado fue excelente y recibí una calificación sobresaliente.",
    rating: 5
  },
  {
    id: "5",
    name: "Daniela Vargas",
    role: "Estudiante de Pregrado",
    institution: "Universidad Javeriana",
    content: "Lo que más me impresionó fue la originalidad del trabajo y la profundidad del análisis. El servicio vale cada peso invertido.",
    rating: 5,
    avatar: "https://randomuser.me/api/portraits/women/68.jpg"
  }
];

const TestimonialCard = ({ testimonial }: { testimonial: Testimonial }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md flex flex-col h-full hover:shadow-lg transition-shadow duration-300">
      <div className="flex items-start mb-4">
        <div className="mr-4">
          <div className="relative">
            {testimonial.avatar ? (
              <img
                src={testimonial.avatar}
                alt={testimonial.name}
                className="w-14 h-14 rounded-full object-cover"
              />
            ) : (
              <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center">
                <User className="w-6 h-6 text-green-600" />
              </div>
            )}
            <Quote className="absolute -bottom-2 -right-2 w-6 h-6 text-green-500 bg-white rounded-full p-1" />
          </div>
        </div>
        <div>
          <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
          <p className="text-sm text-gray-600">{testimonial.role}</p>
          <p className="text-xs text-gray-500">{testimonial.institution}</p>
          <div className="flex mt-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
      <p className="text-gray-600 italic flex-grow">{testimonial.content}</p>
      <div className="flex items-center justify-end space-x-2 mt-4 text-green-500">
        <div className="flex items-center text-xs">
          <ThumbsUp className="w-3 h-3 mr-1" />
          <span>Útil</span>
        </div>
        <div className="flex items-center text-xs">
          <MessageSquare className="w-3 h-3 mr-1" />
          <span>Comentar</span>
        </div>
      </div>
    </div>
  );
};

const Testimonials = () => {
  const [currentPage, setCurrentPage] = useState(0);
  const testimonialsPerPage = 3;
  const pageCount = Math.ceil(testimonials.length / testimonialsPerPage);

  const displayedTestimonials = testimonials.slice(
    currentPage * testimonialsPerPage,
    (currentPage + 1) * testimonialsPerPage
  );

  return (
    <section id="testimonios" className="py-12 md:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Lo que dicen nuestros estudiantes</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Nos enorgullecemos de brindar un servicio excepcional y ayudar a los estudiantes a alcanzar sus metas académicas.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {displayedTestimonials.map((testimonial) => (
            <TestimonialCard key={testimonial.id} testimonial={testimonial} />
          ))}
        </div>

        {pageCount > 1 && (
          <div className="flex justify-center mt-8">
            <div className="flex space-x-2">
              {Array.from({ length: pageCount }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentPage(i)}
                  className={`w-3 h-3 rounded-full ${
                    currentPage === i ? "bg-green-500" : "bg-gray-300"
                  }`}
                  aria-label={`Página ${i + 1}`}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Testimonials;
