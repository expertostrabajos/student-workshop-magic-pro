
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { 
  Loader2, 
  CheckCircle, 
  CreditCard, 
  Lock, 
  ShieldCheck, 
  ArrowRight,
  CreditCard as CardIcon,
  Banknote,
  DollarSign,
  Upload,
  FileText,
  AlertTriangle,
  ReceiptText,
  Wallet,
  CalendarClock,
  ArrowDownUp,
  BarChart,
  ShieldAlert,
  QrCode,
  Building,
  FileImage
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface PaymentMethod {
  id: string;
  type: 'card' | 'transfer' | 'mobile' | 'crypto' | 'pse';
  name: string;
  icon: React.ReactNode;
  description: string;
}

interface PaymentPlan {
  id: string;
  title: string;
  price: string;
  originalPrice?: string;
  features: string[];
  recommended?: boolean;
  badge?: string;
}

const EnhancedPaymentSystem = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<PaymentPlan>({
    id: "premium",
    title: "Plan Premium",
    price: "199.000",
    features: [
      "Apoyo académico personalizado",
      "Revisiones ilimitadas",
      "Formato a elección",
      "Garantía de calidad"
    ]
  });
  const [couponCode, setCouponCode] = useState("");
  const [couponApplied, setCouponApplied] = useState(false);
  const [showReceiptUpload, setShowReceiptUpload] = useState(false);
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null);
  const [paymentReason, setPaymentReason] = useState("academic_work");
  const [showDiscountDialog, setShowDiscountDialog] = useState(false);
  const [discountCountdown, setDiscountCountdown] = useState(600); // 10 minutes in seconds
  const navigate = useNavigate();

  const paymentMethods: PaymentMethod[] = [
    {
      id: "card",
      type: "card",
      name: "Tarjeta de Crédito",
      icon: <CardIcon className="h-6 w-6" />,
      description: "Pago inmediato con tarjeta de crédito o débito."
    },
    {
      id: "transfer",
      type: "transfer",
      name: "Transferencia Bancaria",
      icon: <Banknote className="h-6 w-6" />,
      description: "Transferencia a nuestra cuenta bancaria."
    },
    {
      id: "nequi",
      type: "mobile",
      name: "Nequi / Daviplata",
      icon: <Wallet className="h-6 w-6" />,
      description: "Pago a través de billeteras móviles."
    },
    {
      id: "pse",
      type: "pse",
      name: "PSE",
      icon: <Building className="h-6 w-6" />,
      description: "Pago seguro electrónico con tu banco."
    }
  ];

  const paymentPlans: PaymentPlan[] = [
    {
      id: "basic",
      title: "Plan Básico",
      price: "149.000",
      features: [
        "Apoyo académico estándar",
        "2 revisiones incluidas",
        "Formato básico",
        "Entrega en 7 días"
      ]
    },
    {
      id: "premium",
      title: "Plan Premium",
      price: "199.000",
      originalPrice: "249.000",
      badge: "Más Popular",
      recommended: true,
      features: [
        "Apoyo académico personalizado",
        "Revisiones ilimitadas",
        "Formato a elección",
        "Entrega en 5 días",
        "Garantía de calidad"
      ]
    },
    {
      id: "platinum",
      title: "Plan Platinum",
      price: "299.000",
      features: [
        "Apoyo académico premium",
        "Revisiones ilimitadas",
        "Todos los formatos disponibles",
        "Entrega en 3 días",
        "Garantía de calidad",
        "Asistencia prioritaria 24/7"
      ]
    }
  ];

  // Countdown timer for special offer
  useEffect(() => {
    if (showDiscountDialog && discountCountdown > 0) {
      const timer = setTimeout(() => {
        setDiscountCountdown(discountCountdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (discountCountdown === 0) {
      setShowDiscountDialog(false);
    }
  }, [discountCountdown, showDiscountDialog]);

  // Format countdown time
  const formatCountdown = () => {
    const minutes = Math.floor(discountCountdown / 60);
    const seconds = discountCountdown % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Show special offer after 5 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowDiscountDialog(true);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  const handlePayment = async () => {
    if (!paymentMethod) {
      toast.error("Por favor seleccione un método de pago", {
        description: "Debe elegir un método de pago para continuar"
      });
      return;
    }
    
    if (paymentMethod === "transfer" && !receiptFile) {
      setShowReceiptUpload(true);
      return;
    }
    
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      
      if (paymentMethod === "card" || paymentMethod === "nequi" || paymentMethod === "pse") {
        // Para pagos electrónicos, simulamos pago inmediato
        setIsConfirmed(true);
        
        toast.success("¡Pago confirmado!", {
          description: "Tu pago ha sido procesado correctamente."
        });
        
        // Redirect to checkout after 2 seconds
        setTimeout(() => {
          navigate("/checkout", { 
            state: { 
              paymentSuccess: true,
              plan: selectedPlan,
              paymentMethod,
              paymentStatus: "verified", // Confirmado automáticamente para pagos electrónicos
              discountApplied: couponApplied
            } 
          });
        }, 2000);
      } else if (paymentMethod === "transfer") {
        // Para transferencias, pasa a estado pendiente de verificación
        toast.success("Comprobante recibido", {
          description: "Tu pago será verificado por un administrador en las próximas 24 horas."
        });
        
        // Redirect to checkout with pending status
        navigate("/checkout", { 
          state: { 
            paymentSuccess: true,
            plan: selectedPlan,
            paymentMethod,
            paymentStatus: "pending", // Pendiente de verificación
            receiptUploaded: true,
            discountApplied: couponApplied
          } 
        });
      }
    }, 1500);
  };

  const handleCouponApply = () => {
    if (!couponCode.trim()) {
      toast.error("Por favor ingresa un código de cupón");
      return;
    }
    
    // Simulate valid coupon check
    const validCoupons = ["ACADEMICO25", "NUEVO15", "DESCUENTO10"];
    
    if (validCoupons.includes(couponCode.toUpperCase())) {
      setCouponApplied(true);
      toast.success("¡Cupón aplicado correctamente!", {
        description: "Se ha aplicado un 15% de descuento a tu compra."
      });
      
      // Update price with discount
      const originalPrice = parseFloat(selectedPlan.price.replace(".", ""));
      const discountedPrice = (originalPrice * 0.85).toFixed(3);
      
      setSelectedPlan({
        ...selectedPlan,
        originalPrice: selectedPlan.price,
        price: discountedPrice.toString()
      });
    } else {
      toast.error("Código de cupón inválido", {
        description: "El código ingresado no es válido o ha expirado."
      });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setReceiptFile(file);
      
      // Create preview for image files
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setReceiptPreview(event.target?.result as string);
        };
        reader.readAsDataURL(file);
      } else {
        setReceiptPreview(null);
      }
    }
  };

  const handleReceiptUploadSubmit = () => {
    if (!receiptFile) {
      toast.error("Por favor sube el comprobante de pago");
      return;
    }
    
    setShowReceiptUpload(false);
    handlePayment();
  };

  const handleSpecialOfferAccept = () => {
    // Apply special offer discount
    const originalPrice = parseFloat(selectedPlan.price.replace(".", ""));
    const discountedPrice = (originalPrice * 0.8).toFixed(3); // 20% discount
    
    setSelectedPlan({
      ...selectedPlan,
      originalPrice: selectedPlan.price,
      price: discountedPrice.toString(),
      badge: "Oferta Especial"
    });
    
    setCouponApplied(true);
    setShowDiscountDialog(false);
    
    toast.success("¡Oferta especial aplicada!", {
      description: "Se ha aplicado un 20% de descuento a tu compra."
    });
  };

  // Calculate the discounted price if there's an original price
  const calculateSavings = () => {
    if (selectedPlan.originalPrice) {
      const original = parseFloat(selectedPlan.originalPrice.replace(".", ""));
      const current = parseFloat(selectedPlan.price.replace(".", ""));
      const savings = original - current;
      return savings.toLocaleString('es-CO');
    }
    return 0;
  };

  return (
    <div className="w-full max-w-5xl mx-auto">
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-2xl">Sistema de Pagos Académicos</CardTitle>
          <CardDescription>Selecciona un plan y método de pago para tu trabajo académico</CardDescription>
        </CardHeader>
        <CardContent>
          {isConfirmed ? (
            <div className="flex flex-col items-center justify-center py-10">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                <CheckCircle className="h-10 w-10 text-green-500" />
              </div>
              <h4 className="text-xl font-medium text-gray-900 mb-2">¡Pago confirmado!</h4>
              <p className="text-gray-600 text-center mb-4 max-w-md">
                Tu pago ha sido procesado correctamente. Estamos preparando tu trabajo académico.
              </p>
              <div className="animate-pulse mb-4">
                <div className="h-2 w-32 bg-green-300 rounded"></div>
              </div>
              <p className="text-sm text-gray-500">
                Redireccionando al siguiente paso...
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-7 gap-8">
              <div className="md:col-span-4 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Elige tu Plan Académico</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {paymentPlans.map((plan) => (
                      <div 
                        key={plan.id}
                        className={`border rounded-lg p-4 cursor-pointer transition-all relative
                          ${selectedPlan.id === plan.id 
                            ? 'border-green-500 bg-green-50 shadow-sm' 
                            : 'hover:border-gray-300 hover:shadow-sm'
                          }
                        `}
                        onClick={() => setSelectedPlan(plan)}
                      >
                        {plan.badge && (
                          <Badge className="absolute -top-2 -right-2 bg-green-500">
                            {plan.badge}
                          </Badge>
                        )}
                        <div className="flex justify-between items-start">
                          <h4 className="font-medium">{plan.title}</h4>
                          {selectedPlan.id === plan.id && (
                            <CheckCircle className="h-5 w-5 text-green-500" />
                          )}
                        </div>
                        
                        <div className="mt-2">
                          <p className="text-2xl font-bold">
                            ${plan.price}
                            <span className="text-sm font-normal text-gray-500"> COP</span>
                          </p>
                          {plan.originalPrice && (
                            <p className="text-sm text-gray-500 line-through">
                              ${plan.originalPrice} COP
                            </p>
                          )}
                        </div>
                        
                        <Separator className="my-3" />
                        
                        <ul className="space-y-2">
                          {plan.features.map((feature, index) => (
                            <li key={index} className="text-sm flex items-start">
                              <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-4">Método de Pago</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {paymentMethods.map((method) => (
                      <div
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id)}
                        className={`p-4 border rounded-lg flex flex-col items-center justify-center transition-all cursor-pointer ${
                          paymentMethod === method.id 
                            ? "border-green-500 bg-green-50" 
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div className={`mb-2 ${paymentMethod === method.id ? "text-green-500" : "text-gray-500"}`}>
                          {method.icon}
                        </div>
                        <h4 className="text-sm font-medium">{method.name}</h4>
                        <p className="text-xs text-gray-500 text-center mt-1">{method.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                {paymentMethod === "card" && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Detalles de la Tarjeta</h3>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="cardNumber">Número de tarjeta</Label>
                        <Input 
                          id="cardNumber" 
                          placeholder="0000 0000 0000 0000" 
                          className="mt-1"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="expiry">Fecha de expiración</Label>
                          <Input 
                            id="expiry" 
                            placeholder="MM/AA" 
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label htmlFor="cvv">CVV</Label>
                          <Input 
                            id="cvv" 
                            placeholder="123" 
                            className="mt-1"
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="cardName">Nombre en la tarjeta</Label>
                        <Input 
                          id="cardName" 
                          placeholder="Como aparece en la tarjeta" 
                          className="mt-1"
                        />
                      </div>
                    </div>
                  </div>
                )}
                
                {paymentMethod === "transfer" && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Datos para Transferencia</h3>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h4 className="font-medium mb-2 flex items-center text-blue-700">
                        <Building className="h-4 w-4 mr-2" />
                        Datos bancarios
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="grid grid-cols-3 gap-2">
                          <span className="text-gray-500">Banco:</span>
                          <span className="col-span-2 font-medium">Bancolombia</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <span className="text-gray-500">Tipo de cuenta:</span>
                          <span className="col-span-2 font-medium">Cuenta de Ahorros</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <span className="text-gray-500">Número:</span>
                          <span className="col-span-2 font-medium">123-456789-00</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <span className="text-gray-500">Titular:</span>
                          <span className="col-span-2 font-medium">Student Help S.A.S</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <span className="text-gray-500">NIT:</span>
                          <span className="col-span-2 font-medium">900.123.456-7</span>
                        </div>
                      </div>
                      <p className="mt-3 text-xs text-blue-600 flex items-start">
                        <AlertTriangle className="h-4 w-4 mr-1 flex-shrink-0" />
                        Deberás subir el comprobante de pago en el siguiente paso para verificar tu transferencia.
                      </p>
                    </div>
                  </div>
                )}
                
                {paymentMethod === "nequi" && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Pago con Nequi / Daviplata</h3>
                    <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                      <div className="flex justify-between items-center mb-4">
                        <div>
                          <h4 className="font-medium mb-1 text-purple-700">Datos para Billetera Móvil</h4>
                          <p className="text-sm text-purple-600">Realiza el pago a la siguiente cuenta:</p>
                        </div>
                        <Wallet className="h-8 w-8 text-purple-500" />
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="grid grid-cols-3 gap-2">
                          <span className="text-gray-500">Número:</span>
                          <span className="col-span-2 font-medium">314 213 5852</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <span className="text-gray-500">Nombre:</span>
                          <span className="col-span-2 font-medium">Student Help S.A.S</span>
                        </div>
                      </div>
                      <div className="mt-4">
                        <Button className="w-full">
                          Confirmar Pago con Nequi
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
                
                {paymentMethod === "pse" && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Pago con PSE</h3>
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <div className="flex justify-between items-center mb-4">
                        <div>
                          <h4 className="font-medium mb-1 text-green-700">Datos para PSE</h4>
                          <p className="text-sm text-green-600">Selecciona tu banco para continuar:</p>
                        </div>
                        <Building className="h-8 w-8 text-green-500" />
                      </div>
                      <div className="mb-4">
                        <Label htmlFor="bank">Banco</Label>
                        <select
                          id="bank"
                          className="w-full h-10 px-3 py-2 mt-1 border rounded-md"
                        >
                          <option value="">Seleccionar banco...</option>
                          <option value="bancolombia">Bancolombia</option>
                          <option value="davivienda">Davivienda</option>
                          <option value="bbva">BBVA</option>
                          <option value="bogota">Banco de Bogotá</option>
                          <option value="popular">Banco Popular</option>
                        </select>
                      </div>
                      <div className="mb-4">
                        <Label htmlFor="document">Tipo de Documento</Label>
                        <select
                          id="document"
                          className="w-full h-10 px-3 py-2 mt-1 border rounded-md"
                        >
                          <option value="cc">Cédula de Ciudadanía</option>
                          <option value="ce">Cédula de Extranjería</option>
                          <option value="nit">NIT</option>
                          <option value="passport">Pasaporte</option>
                        </select>
                      </div>
                      <div className="mb-4">
                        <Label htmlFor="documentNumber">Número de Documento</Label>
                        <Input
                          id="documentNumber"
                          className="mt-1"
                          placeholder="Ingresa tu número de documento"
                        />
                      </div>
                      <div className="mt-4">
                        <Button className="w-full">
                          Continuar al Banco
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="md:col-span-3">
                <Card>
                  <CardHeader>
                    <CardTitle>Resumen de Pago</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600">Plan:</span>
                        <span className="font-medium">{selectedPlan.title}</span>
                      </div>
                      
                      {selectedPlan.originalPrice && (
                        <div className="flex justify-between items-center text-sm text-gray-500 mb-1">
                          <span>Precio original:</span>
                          <span className="line-through">${selectedPlan.originalPrice} COP</span>
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-gray-600">Precio:</span>
                        <span className="font-medium">${selectedPlan.price} COP</span>
                      </div>
                      
                      {couponApplied && (
                        <div className="flex justify-between items-center mb-1 text-green-600">
                          <span>Descuento:</span>
                          <span>-${calculateSavings()} COP</span>
                        </div>
                      )}
                      
                      <Separator className="my-3" />
                      
                      <div className="flex justify-between text-lg font-bold">
                        <span>Total:</span>
                        <span>${selectedPlan.price} COP</span>
                      </div>
                      
                      {couponApplied && (
                        <div className="mt-3 bg-green-100 p-2 rounded-md">
                          <p className="text-xs text-green-800 flex items-center">
                            <CheckCircle className="h-3 w-3 mr-1 flex-shrink-0" />
                            ¡Descuento aplicado exitosamente!
                          </p>
                        </div>
                      )}
                    </div>
                    
                    {!couponApplied && (
                      <div>
                        <Label htmlFor="coupon" className="text-sm font-medium mb-1 block">
                          ¿Tienes un cupón de descuento?
                        </Label>
                        <div className="flex space-x-2">
                          <Input
                            id="coupon"
                            placeholder="Ingresa tu código"
                            value={couponCode}
                            onChange={(e) => setCouponCode(e.target.value)}
                          />
                          <Button 
                            variant="outline" 
                            onClick={handleCouponApply}
                          >
                            Aplicar
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    <div className="space-y-2">
                      <Button
                        onClick={handlePayment}
                        disabled={isProcessing || !paymentMethod}
                        className="w-full py-6"
                      >
                        {isProcessing ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Procesando...
                          </>
                        ) : (
                          <>
                            {paymentMethod === "transfer" ? "Continuar con el pago" : "Pagar ahora"}
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                      
                      <div className="flex items-center justify-center text-xs text-gray-500 mt-2">
                        <Lock className="h-3 w-3 mr-1" />
                        Pago seguro con encriptación SSL
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="text-sm space-y-2">
                      <div className="flex items-center text-gray-600">
                        <ShieldCheck className="h-4 w-4 text-green-600 mr-2" />
                        <span>Garantía de satisfacción de 7 días</span>
                      </div>
                      <div className="flex items-center text-gray-600">
                        <Lock className="h-4 w-4 text-green-600 mr-2" />
                        <span>Pago 100% seguro y confidencial</span>
                      </div>
                      <div className="flex items-center text-gray-600">
                        <ShieldAlert className="h-4 w-4 text-green-600 mr-2" />
                        <span>Políticas de reembolso claras</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Dialog para subir comprobante de transferencia */}
      <Dialog open={showReceiptUpload} onOpenChange={setShowReceiptUpload}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Subir comprobante de pago</DialogTitle>
            <DialogDescription>
              Por favor sube una captura o documento PDF de tu comprobante de transferencia
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <input
                type="file"
                id="receipt"
                className="hidden"
                accept="image/*,.pdf"
                onChange={handleFileChange}
              />
              
              {receiptPreview ? (
                <div className="mb-3">
                  <img 
                    src={receiptPreview} 
                    alt="Vista previa del comprobante" 
                    className="max-h-40 max-w-full mx-auto rounded-lg" 
                  />
                  <p className="text-sm text-gray-500 mt-2">
                    {receiptFile?.name} ({(receiptFile?.size || 0) / 1024 < 1000 
                      ? `${Math.round((receiptFile?.size || 0) / 1024)} KB` 
                      : `${Math.round((receiptFile?.size || 0) / 1024 / 1024 * 10) / 10} MB`})
                  </p>
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <FileImage className="h-10 w-10 text-gray-400 mb-2" />
                  <p className="text-sm text-gray-600 mb-2">
                    Arrastra y suelta o haz clic para seleccionar
                  </p>
                  <p className="text-xs text-gray-500">
                    Formatos aceptados: PNG, JPG, PDF (Máx. 5MB)
                  </p>
                </div>
              )}
              
              <Button 
                variant="outline" 
                className="mt-3"
                onClick={() => document.getElementById('receipt')?.click()}
              >
                {receiptFile ? "Cambiar archivo" : "Seleccionar archivo"}
              </Button>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReceiptUpload(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleReceiptUploadSubmit}
              disabled={!receiptFile}
            >
              <ReceiptText className="h-4 w-4 mr-2" />
              Subir y continuar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para oferta especial */}
      <Dialog open={showDiscountDialog} onOpenChange={setShowDiscountDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl font-bold text-red-600">
              ¡Oferta Especial!
            </DialogTitle>
            <DialogDescription className="text-center">
              Descuento exclusivo disponible solo para los próximos
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="text-center mb-4">
              <div className="text-3xl font-bold bg-red-100 text-red-600 p-3 rounded-md inline-block">
                {formatCountdown()}
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg text-center mb-4">
              <h3 className="font-bold text-lg mb-2">20% de DESCUENTO</h3>
              <p className="text-gray-600 mb-2">
                En cualquiera de nuestros planes académicos
              </p>
              <p className="text-sm text-gray-500">
                *Oferta por tiempo limitado
              </p>
            </div>
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 mb-4">
              <p className="text-sm text-yellow-800 flex items-start">
                <AlertTriangle className="h-4 w-4 mr-2 flex-shrink-0 mt-0.5" />
                Esta oferta especial expirará en breve. ¡Aprovecha ahora este descuento exclusivo!
              </p>
            </div>
          </div>
          
          <DialogFooter className="flex flex-col-reverse sm:flex-row gap-2">
            <Button 
              variant="outline" 
              onClick={() => setShowDiscountDialog(false)}
              className="w-full sm:w-auto"
            >
              No, gracias
            </Button>
            <Button 
              onClick={handleSpecialOfferAccept}
              className="w-full sm:w-auto bg-red-600 hover:bg-red-700"
            >
              ¡Obtener 20% de descuento!
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default EnhancedPaymentSystem;
