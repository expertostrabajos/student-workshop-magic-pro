import { useState, useMemo } from "react";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users,
  FileText,
  AlertTriangle,
  Clock,
  Award,
  CreditCard,
  RefreshCw,
  Plus,
  Trash2,
  Pencil
} from "lucide-react";
import { Button } from "@/components/ui/button";
import AdminPaymentVerification from "./AdminPaymentVerification";
import ReviewerFormDialog from "./ReviewerFormDialog";
import { useWorkOrders } from "@/hooks/useWorkOrders";
import { useReviewers, Reviewer } from "@/hooks/useReviewers";
import { STATUS_CONFIG } from "@/types/workOrder";

const AdminPanel = () => {
  const { orders, isLoading, error, refetch, updateOrder } = useWorkOrders();
  const { 
    reviewers, 
    isLoading: reviewersLoading, 
    error: reviewersError, 
    refetch: refetchReviewers,
    createReviewer,
    updateReviewer,
    deleteReviewer
  } = useReviewers();
  
  const [activeTab, setActiveTab] = useState<"requests" | "reviewers" | "payments">("requests");
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [selectedReviewer, setSelectedReviewer] = useState<Reviewer | null>(null);
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [assignmentDeadline, setAssignmentDeadline] = useState("");
  const [isReviewerFormOpen, setIsReviewerFormOpen] = useState(false);
  const [editingReviewer, setEditingReviewer] = useState<Reviewer | null>(null);
  const [deletingReviewerId, setDeletingReviewerId] = useState<string | null>(null);

  // Get the selected order from orders array
  const selectedOrder = useMemo(() => 
    orders.find(o => o.id === selectedOrderId) || null,
    [orders, selectedOrderId]
  );

  // Calculate statistics from real data
  const stats = useMemo(() => ({
    total: orders.length,
    pending: orders.filter(o => o.status === 'created' || o.status === 'pending_payment').length,
    inProgress: orders.filter(o => o.status === 'in_progress').length,
    avgQuality: 0 // Quality score could be added to orders in the future
  }), [orders]);

  // Function to get status badge style using real STATUS_CONFIG
  const getStatusBadge = (status: string) => {
    const config = STATUS_CONFIG[status as keyof typeof STATUS_CONFIG];
    if (!config) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
          {status}
        </span>
      );
    }
    return (
      <span 
        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium`}
        style={{ backgroundColor: config.bgColor, color: config.color }}
      >
        {config.label}
      </span>
    );
  };

  // Function to open assignment dialog
  const openAssignDialog = (orderId: string, deadline: Date) => {
    setSelectedOrderId(orderId);
    setAssignmentDeadline(deadline.toISOString().split('T')[0]);
    setIsAssignDialogOpen(true);
  };

  // Function to assign reviewer
  const assignReviewerToOrder = async () => {
    if (!selectedOrder || !selectedReviewer) return;

    try {
      await updateOrder(selectedOrder.id, {
        assignedExpertName: selectedReviewer.name,
        assignedExpertId: selectedReviewer.userId,
        status: 'assigned'
      });

      // Update reviewer workload in database
      await updateReviewer(selectedReviewer.id, {
        currentWorkload: selectedReviewer.currentWorkload + 1
      });

      toast.success("Revisor asignado con éxito", {
        description: `${selectedReviewer.name} ha sido asignado a ${selectedOrder.title}`,
      });

      // Close dialog and reset state
      setIsAssignDialogOpen(false);
      setSelectedOrderId(null);
      setSelectedReviewer(null);
      setAssignmentDeadline("");
    } catch (err) {
      toast.error("Error al asignar revisor");
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Panel de Administración</h2>
        <p className="text-muted-foreground">
          Gestiona solicitudes, asigna revisores y monitorea la calidad del trabajo
        </p>
      </div>

      {/* Navigation Tabs */}
      <Tabs defaultValue="requests" value={activeTab} onValueChange={(value) => setActiveTab(value as "requests" | "reviewers" | "payments")} className="space-y-6">
        <TabsList className="grid w-full sm:w-auto sm:inline-flex grid-cols-3 mb-6">
          <TabsTrigger value="requests" className="text-center flex items-center">
            <FileText className="w-4 h-4 mr-2" />
            Solicitudes
          </TabsTrigger>
          <TabsTrigger value="reviewers" className="text-center flex items-center">
            <Users className="w-4 h-4 mr-2" />
            Revisores
          </TabsTrigger>
          <TabsTrigger value="payments" className="text-center flex items-center">
            <CreditCard className="w-4 h-4 mr-2" />
            Pagos
          </TabsTrigger>
        </TabsList>

        {/* Stats Overview */}
        <TabsContent value="requests">
          {/* Loading and error states */}
          {isLoading && (
            <div className="flex items-center justify-center p-8">
              <RefreshCw className="w-6 h-6 animate-spin mr-2" />
              <span>Cargando solicitudes...</span>
            </div>
          )}
          
          {error && (
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 mb-4">
              <p className="text-destructive">{error}</p>
              <Button variant="outline" size="sm" onClick={refetch} className="mt-2">
                Reintentar
              </Button>
            </div>
          )}

          {!isLoading && !error && (
            <>
              <div className="flex justify-end mb-4">
                <Button variant="outline" size="sm" onClick={refetch}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Actualizar
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-card p-4 rounded-lg shadow border">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 mr-4">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-muted-foreground text-sm">Total Solicitudes</p>
                      <h4 className="text-2xl font-bold">{stats.total}</h4>
                    </div>
                  </div>
                </div>
                <div className="bg-card p-4 rounded-lg shadow border">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600 dark:text-yellow-400 mr-4">
                      <AlertTriangle className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-muted-foreground text-sm">Pendientes</p>
                      <h4 className="text-2xl font-bold">{stats.pending}</h4>
                    </div>
                  </div>
                </div>
                <div className="bg-card p-4 rounded-lg shadow border">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 mr-4">
                      <Clock className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-muted-foreground text-sm">En Progreso</p>
                      <h4 className="text-2xl font-bold">{stats.inProgress}</h4>
                    </div>
                  </div>
                </div>
                <div className="bg-card p-4 rounded-lg shadow border">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 mr-4">
                      <Award className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-muted-foreground text-sm">Calidad Promedio</p>
                      <h4 className="text-2xl font-bold">N/A</h4>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-card rounded-lg shadow overflow-hidden border">
                <div className="p-4 border-b border-border">
                  <h3 className="text-lg font-medium">Solicitudes de Trabajo</h3>
                </div>
                {orders.length === 0 ? (
                  <div className="p-8 text-center text-gray-500">
                    <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No hay solicitudes de trabajo registradas</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Orden</TableHead>
                          <TableHead>Título</TableHead>
                          <TableHead>Tipo</TableHead>
                          <TableHead>Nivel</TableHead>
                          <TableHead>Asignado a</TableHead>
                          <TableHead>Estado</TableHead>
                          <TableHead>Entrega</TableHead>
                          <TableHead>Acciones</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {orders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">{order.orderNumber}</TableCell>
                            <TableCell className="max-w-xs truncate">{order.title}</TableCell>
                            <TableCell className="capitalize">{order.workType}</TableCell>
                            <TableCell className="capitalize">{order.academicLevel}</TableCell>
                            <TableCell>
                              {order.assignedExpertName || (
                                <span className="text-gray-400">No asignado</span>
                              )}
                            </TableCell>
                            <TableCell>{getStatusBadge(order.status)}</TableCell>
                            <TableCell>
                              <span
                                className={`px-2 py-1 rounded text-xs ${
                                  new Date(order.deadline) < new Date()
                                    ? "bg-red-100 text-red-800"
                                    : "bg-gray-100 text-gray-800"
                                }`}
                              >
                                {new Date(order.deadline).toLocaleDateString()}
                              </span>
                            </TableCell>
                            <TableCell>
                              {order.status === "created" || order.status === "paid" ? (
                                <button
                                  onClick={() => openAssignDialog(order.id, order.deadline)}
                                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                                >
                                  Asignar
                                </button>
                              ) : (
                                <button
                                  className="text-gray-600 hover:text-gray-800 text-sm font-medium"
                                >
                                  Ver detalles
                                </button>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </>
          )}
        </TabsContent>
        
        <TabsContent value="reviewers">
          {/* Loading and error states for reviewers */}
          {reviewersLoading && (
            <div className="flex items-center justify-center p-8">
              <RefreshCw className="w-6 h-6 animate-spin mr-2" />
              <span>Cargando revisores...</span>
            </div>
          )}
          
          {reviewersError && (
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 mb-4">
              <p className="text-destructive">{reviewersError}</p>
              <Button variant="outline" size="sm" onClick={refetchReviewers} className="mt-2">
                Reintentar
              </Button>
            </div>
          )}

          {!reviewersLoading && !reviewersError && (
            <>
              <div className="flex justify-between items-center mb-4">
                <Button
                  size="sm"
                  onClick={() => {
                    setEditingReviewer(null);
                    setIsReviewerFormOpen(true);
                  }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Nuevo Revisor
                </Button>
                <Button variant="outline" size="sm" onClick={refetchReviewers}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Actualizar
                </Button>
              </div>

              <div className="bg-card rounded-lg shadow overflow-hidden">
                <div className="p-4 border-b">
                  <h3 className="text-lg font-medium">Revisores ({reviewers.length})</h3>
                </div>
                {reviewers.length === 0 ? (
                  <div className="p-8 text-center text-muted-foreground">
                    <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No hay revisores registrados</p>
                    <Button
                      size="sm"
                      className="mt-4"
                      onClick={() => {
                        setEditingReviewer(null);
                        setIsReviewerFormOpen(true);
                      }}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Crear primer revisor
                    </Button>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Nombre</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Especialidad</TableHead>
                          <TableHead>Carga Actual</TableHead>
                          <TableHead>Completados</TableHead>
                          <TableHead>Calidad</TableHead>
                          <TableHead>Estado</TableHead>
                          <TableHead>Acciones</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {reviewers.map((reviewer) => (
                          <TableRow key={reviewer.id}>
                            <TableCell className="font-medium">{reviewer.name}</TableCell>
                            <TableCell className="text-muted-foreground">{reviewer.email}</TableCell>
                            <TableCell>{reviewer.specialty}</TableCell>
                            <TableCell>
                              <span
                                className={`px-2 py-1 rounded text-xs ${
                                  reviewer.currentWorkload > 2
                                    ? "bg-destructive/10 text-destructive"
                                    : reviewer.currentWorkload > 0
                                    ? "bg-yellow-100 text-yellow-800"
                                    : "bg-green-100 text-green-800"
                                }`}
                              >
                                {reviewer.currentWorkload} trabajos
                              </span>
                            </TableCell>
                            <TableCell>{reviewer.completedWorks}</TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <span className="font-medium mr-1">{reviewer.averageQuality.toFixed(1)}</span>
                                <div className="flex">
                                  {Array.from({ length: Math.round(reviewer.averageQuality / 2) }).map(
                                    (_, i) => (
                                      <Award key={i} className="w-3 h-3 text-yellow-400" />
                                    )
                                  )}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <span className={`px-2 py-1 rounded text-xs ${
                                reviewer.isActive 
                                  ? "bg-green-100 text-green-800" 
                                  : "bg-muted text-muted-foreground"
                              }`}>
                                {reviewer.isActive ? 'Activo' : 'Inactivo'}
                              </span>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  title="Editar revisor"
                                  onClick={() => {
                                    setEditingReviewer(reviewer);
                                    setIsReviewerFormOpen(true);
                                  }}
                                >
                                  <Pencil className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-destructive hover:text-destructive"
                                  title="Eliminar revisor"
                                  onClick={() => setDeletingReviewerId(reviewer.id)}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </>
          )}
        </TabsContent>
        
        <TabsContent value="payments">
          <AdminPaymentVerification />
        </TabsContent>
      </Tabs>

      {/* Assignment Dialog */}
      <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Asignar Revisor</DialogTitle>
            <DialogDescription>
              {selectedOrder && (
                <div className="mt-2">
                  <p className="font-medium">{selectedOrder.title}</p>
                  <div className="text-sm text-gray-500 mt-1">
                    <span className="capitalize">{selectedOrder.workType}</span> •{" "}
                    <span className="capitalize">{selectedOrder.academicLevel}</span> •{" "}
                    <span>{selectedOrder.wordCount}</span>
                  </div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Seleccionar Revisor
              </label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                value={selectedReviewer?.id || ""}
                onChange={(e) => {
                  const reviewer = reviewers.find((r) => r.id === e.target.value);
                  setSelectedReviewer(reviewer || null);
                }}
              >
                <option value="">Selecciona un revisor</option>
                {reviewers.map((reviewer) => (
                  <option key={reviewer.id} value={reviewer.id}>
                    {reviewer.name} - {reviewer.specialty} (Carga: {reviewer.currentWorkload})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fecha estimada de entrega
              </label>
              <input
                type="date"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                value={assignmentDeadline}
                onChange={(e) => setAssignmentDeadline(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
              />
            </div>
          </div>

          <DialogFooter>
            <button
              onClick={() => setIsAssignDialogOpen(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
            >
              Cancelar
            </button>
            <button
              onClick={assignReviewerToOrder}
              disabled={!selectedReviewer || !assignmentDeadline}
              className={`px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 ml-3 ${
                !selectedReviewer || !assignmentDeadline
                  ? "opacity-50 cursor-not-allowed"
                  : ""
              }`}
            >
              Asignar Revisor
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reviewer Form Dialog */}
      <ReviewerFormDialog
        open={isReviewerFormOpen}
        onOpenChange={(open) => {
          setIsReviewerFormOpen(open);
          if (!open) setEditingReviewer(null);
        }}
        reviewer={editingReviewer}
        onSave={async (data) => {
          if (editingReviewer) {
            await updateReviewer(editingReviewer.id, data);
            toast.success("Revisor actualizado exitosamente");
          } else {
            await createReviewer(data);
          }
          await refetchReviewers();
        }}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={!!deletingReviewerId}
        onOpenChange={(open) => {
          if (!open) setDeletingReviewerId(null);
        }}
      >
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Eliminar Revisor</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar este revisor? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeletingReviewerId(null)}>
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={async () => {
                if (deletingReviewerId) {
                  await deleteReviewer(deletingReviewerId);
                  setDeletingReviewerId(null);
                }
              }}
            >
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminPanel;
