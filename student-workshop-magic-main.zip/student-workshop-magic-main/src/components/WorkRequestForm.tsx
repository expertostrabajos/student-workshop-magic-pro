
import { useState, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { toast } from "sonner";
import { Upload, File, X, AlertCircle, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { scheduleReminder } from "@/utils/reminderUtils";
import FileUploadComponent from "@/components/FileUploadComponent";
import { useNotificationContext } from "@/components/NotificationProvider";

const WorkRequestForm = () => {
  const { toast: shadowToast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    workType: "",
    subject: "",
    topic: "",
    wordCount: "",
    deadline: "",
    academicLevel: "",
    specificRequirements: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [reminderEnabled, setReminderEnabled] = useState(true);
  const [reminderDays, setReminderDays] = useState(3);
  const { addNotification } = useNotificationContext();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const submissionData = new FormData();
      
      Object.entries(formData).forEach(([key, value]) => {
        submissionData.append(key, value);
      });
      
      files.forEach((file, index) => {
        submissionData.append(`file-${index}`, file);
      });

      const requestId = `REQ-${Date.now()}`;
      submissionData.append("requestId", requestId);
      submissionData.append("requiresReview", "true");

      const response = await fetch("https://formspree.io/f/xqaevrbg", {
        method: "POST",
        body: submissionData,
      });

      if (response.ok) {
        if (reminderEnabled && formData.deadline && formData.email) {
          const reminderDate = scheduleReminder(
            requestId,
            formData.email,
            formData.deadline,
            reminderDays
          );
          
          toast.success(`Recordatorio programado para ${reminderDate.toLocaleDateString()}`, {
            description: `Te enviaremos un recordatorio ${reminderDays} días antes de la fecha de entrega.`
          });
        }
        
        shadowToast({
          title: "Solicitud enviada",
          description: `Tu solicitud con ID: ${requestId} ha sido recibida. Te hemos enviado un correo de confirmación.`,
        });
        
        toast.success(`Solicitud enviada correctamente. ID: ${requestId}`, {
          description: "Nos pondremos en contacto contigo pronto con una cotización detallada."
        });
        
        addNotification({
          title: "Solicitud registrada",
          message: `Tu solicitud de trabajo "${formData.topic}" ha sido recibida correctamente.`,
          type: "success"
        });
        
        setFormData({
          name: "",
          email: "",
          phone: "",
          workType: "",
          subject: "",
          topic: "",
          wordCount: "",
          deadline: "",
          academicLevel: "",
          specificRequirements: "",
        });
        setFiles([]);
        
        console.log("Sending email notification to user:", formData.email);
        console.log("Sending notification to review system about new files for requestId:", requestId);
      } else {
        shadowToast({
          title: "Error",
          description: "Hubo un problema al enviar la solicitud. Por favor, intenta nuevamente.",
          variant: "destructive",
        });
      }
    } catch (error) {
      shadowToast({
        title: "Error",
        description: "Hubo un problema al enviar la solicitud. Por favor, intenta nuevamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFilesUploaded = (uploadedFiles: File[]) => {
    setFiles(uploadedFiles);
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl mx-auto space-y-6">
      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg mb-6">
        <p className="text-sm text-blue-800">
          <strong>Importante:</strong> Al enviar tu solicitud, aceptas nuestra{" "}
          <Link to="/privacy-policy" className="text-blue-600 hover:underline">
            Política de Privacidad
          </Link>{" "}
          y{" "}
          <Link to="/terms-of-service" className="text-blue-600 hover:underline">
            Términos de Servicio
          </Link>
          .
        </p>
        <p className="text-sm text-blue-800 mt-2">
          <strong>Nota:</strong> Actualmente solo aceptamos pagos a través de Nequi para mayor simplicidad y rapidez.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
            Nombre Completo
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            placeholder="Tu nombre completo"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
            Correo Electrónico
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            placeholder="tu.correo@ejemplo.com"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
          />
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
            Teléfono / WhatsApp
          </label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            required
            placeholder="Tu número de contacto"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
          />
        </div>

        <div>
          <label htmlFor="workType" className="block text-sm font-medium text-gray-700 mb-1">
            Tipo de Trabajo
          </label>
          <select
            id="workType"
            name="workType"
            value={formData.workType}
            onChange={handleChange}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
          >
            <option value="">Selecciona un tipo</option>
            <option value="ensayo">Ensayo</option>
            <option value="investigacion">Trabajo de Investigación</option>
            <option value="tesis">Tesis</option>
            <option value="articulo">Artículo Académico</option>
            <option value="monografia">Monografía</option>
          </select>
        </div>

        <div>
          <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
            Materia/Asignatura
          </label>
          <input
            type="text"
            id="subject"
            name="subject"
            value={formData.subject}
            onChange={handleChange}
            required
            placeholder="Ej: Psicología, Economía, etc."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
          />
        </div>

        <div>
          <label htmlFor="academicLevel" className="block text-sm font-medium text-gray-700 mb-1">
            Nivel Académico
          </label>
          <select
            id="academicLevel"
            name="academicLevel"
            value={formData.academicLevel}
            onChange={handleChange}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
          >
            <option value="">Selecciona un nivel</option>
            <option value="primaria">Primaria (1° a 5° grado)</option>
            <option value="secundaria">Secundaria (6° a 11° grado)</option>
            <option value="universidad">Universidad</option>
            <option value="maestria">Maestría</option>
            <option value="doctorado">Doctorado</option>
          </select>
        </div>

        <div>
          <label htmlFor="deadline" className="block text-sm font-medium text-gray-700 mb-1">
            Fecha de Entrega
          </label>
          <input
            type="date"
            id="deadline"
            name="deadline"
            value={formData.deadline}
            onChange={handleChange}
            required
            min={new Date().toISOString().split('T')[0]}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
          />
        </div>
      </div>

      <div>
        <label htmlFor="topic" className="block text-sm font-medium text-gray-700 mb-1">
          Tema Específico
        </label>
        <input
          type="text"
          id="topic"
          name="topic"
          value={formData.topic}
          onChange={handleChange}
          required
          placeholder="Describe el tema específico de tu trabajo"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
        />
      </div>

      <div>
        <label htmlFor="wordCount" className="block text-sm font-medium text-gray-700 mb-1">
          Número de Palabras/Páginas
        </label>
        <input
          type="text"
          id="wordCount"
          name="wordCount"
          value={formData.wordCount}
          onChange={handleChange}
          required
          placeholder="Ej: 1000 palabras o 5 páginas"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
        />
      </div>

      <div>
        <label htmlFor="specificRequirements" className="block text-sm font-medium text-gray-700 mb-1">
          Requisitos Específicos
        </label>
        <textarea
          id="specificRequirements"
          name="specificRequirements"
          value={formData.specificRequirements}
          onChange={handleChange}
          rows={4}
          placeholder="Describe cualquier requisito específico, formato, estilo de citación, o instrucciones especiales"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none resize-none"
        />
      </div>

      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Archivos Adjuntos
        </label>
        <FileUploadComponent
          onFilesUploaded={handleFilesUploaded}
          showCard={false}
          title="Materiales de Apoyo"
          description="Sube cualquier material o instrucciones que nos ayuden a entender mejor tu solicitud"
        />
      </div>

      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-center mb-2">
          <input
            type="checkbox"
            id="reminderEnabled"
            checked={reminderEnabled}
            onChange={(e) => setReminderEnabled(e.target.checked)}
            className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
          />
          <label htmlFor="reminderEnabled" className="ml-2 text-sm font-medium text-gray-700">
            Enviarme un recordatorio antes de la fecha de entrega
          </label>
        </div>
        
        {reminderEnabled && (
          <div className="mt-2">
            <label htmlFor="reminderDays" className="block text-sm font-medium text-gray-700 mb-1">
              ¿Cuántos días antes?
            </label>
            <select
              id="reminderDays"
              value={reminderDays}
              onChange={(e) => setReminderDays(Number(e.target.value))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
            >
              <option value="1">1 día antes</option>
              <option value="2">2 días antes</option>
              <option value="3">3 días antes</option>
              <option value="5">5 días antes</option>
              <option value="7">1 semana antes</option>
            </select>
          </div>
        )}
        
        <p className="text-xs text-blue-600 mt-2">
          Te enviaremos un correo electrónico recordándote la fecha de entrega de tu trabajo.
        </p>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className={`w-full bg-green-500 text-white py-3 px-4 rounded-lg hover:bg-green-600 transition-colors duration-300 ${
          isSubmitting ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        {isSubmitting ? "Enviando..." : "Enviar Solicitud"}
      </button>
    </form>
  );
};

export default WorkRequestForm;
