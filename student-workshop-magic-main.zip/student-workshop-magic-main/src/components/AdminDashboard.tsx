import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  Users, Settings, FileText, BarChart, Shield, Mail, CreditCard,
  BookOpen, Award, Bell, HelpCircle, ClipboardList, Loader2, Download
} from "lucide-react";
import { WorkOrdersManagement } from "@/components/WorkOrderStateMachine";
import { supabase } from "@/integrations/supabase/client";
import { useWorkOrders } from "@/hooks/useWorkOrders";
import { exportOrdersToCSV, exportUsersToCSV } from "@/utils/exportUtils";
import {
  BarChart as ReBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Legend
} from "recharts";

// Componente de configuración del sistema
const SystemSettings = () => (
  <Card className="w-full">
    <CardHeader>
      <CardTitle className="text-xl">Configuración del Sistema</CardTitle>
      <CardDescription>Personaliza las opciones generales del sistema</CardDescription>
    </CardHeader>
    <CardContent className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 border rounded-lg hover:shadow-sm transition-all">
          <h3 className="font-medium flex items-center"><Mail className="h-4 w-4 mr-2" />Configuración de Notificaciones</h3>
          <p className="text-muted-foreground text-sm mt-1">Gestiona las plantillas de correo y notificaciones automáticas</p>
        </div>
        <div className="p-4 border rounded-lg hover:shadow-sm transition-all">
          <h3 className="font-medium flex items-center"><CreditCard className="h-4 w-4 mr-2" />Pasarelas de Pago</h3>
          <p className="text-muted-foreground text-sm mt-1">Configura los métodos de pago disponibles</p>
        </div>
        <div className="p-4 border rounded-lg hover:shadow-sm transition-all">
          <h3 className="font-medium flex items-center"><BookOpen className="h-4 w-4 mr-2" />Recursos Educativos</h3>
          <p className="text-muted-foreground text-sm mt-1">Gestiona las bibliotecas y recursos disponibles</p>
        </div>
        <div className="p-4 border rounded-lg hover:shadow-sm transition-all">
          <h3 className="font-medium flex items-center"><Shield className="h-4 w-4 mr-2" />Seguridad</h3>
          <p className="text-muted-foreground text-sm mt-1">Configura opciones de seguridad y permisos</p>
        </div>
      </div>
      <div className="mt-4"><Button>Guardar Configuración</Button></div>
    </CardContent>
  </Card>
);

// Componente de administración de usuarios con datos reales
const UserManagement = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      setIsLoading(true);
      try {
        const { data: orders, error } = await supabase
          .from('work_orders')
          .select('client_id, client_name, client_email, created_at')
          .order('created_at', { ascending: false });
        if (error) throw error;
        const uniqueUsers = new Map();
        orders?.forEach(order => {
          if (order.client_email && !uniqueUsers.has(order.client_email)) {
            uniqueUsers.set(order.client_email, {
              id: order.client_id, name: order.client_name,
              email: order.client_email, createdAt: order.created_at
            });
          }
        });
        setUsers(Array.from(uniqueUsers.values()));
      } catch (err) {
        console.error('Error fetching users:', err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUsers();
  }, []);

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="py-12 text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-muted-foreground" />
          <p className="mt-2 text-muted-foreground">Cargando usuarios...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-xl">Administración de Usuarios</CardTitle>
          <CardDescription>Usuarios registrados en el sistema</CardDescription>
        </div>
        {users.length > 0 && (
          <Button variant="outline" size="sm" onClick={() => exportUsersToCSV(users)}>
            <Download className="h-4 w-4 mr-2" />Exportar CSV
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {users.length === 0 ? (
          <div className="text-center py-8">
            <Users className="h-12 w-12 mx-auto text-muted-foreground" />
            <p className="mt-2 text-muted-foreground">No hay usuarios registrados aún</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-muted/50 text-left">
                  <th className="p-3 border-b border-border">Usuario</th>
                  <th className="p-3 border-b border-border">Correo</th>
                  <th className="p-3 border-b border-border">Estado</th>
                  <th className="p-3 border-b border-border">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user, index) => (
                  <tr key={index}>
                    <td className="p-3 border-b border-border">{user.name || 'Sin nombre'}</td>
                    <td className="p-3 border-b border-border text-muted-foreground">{user.email}</td>
                    <td className="p-3 border-b border-border">
                      <span className="bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 px-2 py-1 rounded text-xs">Activo</span>
                    </td>
                    <td className="p-3 border-b border-border">
                      <Button variant="ghost" size="sm">Ver órdenes</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const COLORS = ['hsl(221, 83%, 53%)', 'hsl(47, 96%, 53%)', 'hsl(262, 83%, 58%)', 'hsl(142, 71%, 45%)', 'hsl(0, 84%, 60%)', 'hsl(199, 89%, 48%)', 'hsl(25, 95%, 53%)'];

// Componente de estadísticas y análisis con gráficos reales
const Analytics = () => {
  const { orders, isLoading } = useWorkOrders();

  const stats = useMemo(() => ({
    totalOrders: orders.length,
    completedOrders: orders.filter(o => ['delivered', 'archived'].includes(o.status)).length,
    inProgressOrders: orders.filter(o => o.status === 'in_progress').length,
    pendingOrders: orders.filter(o => ['created', 'payment_pending', 'paid'].includes(o.status)).length,
    totalRevenue: orders.reduce((sum, o) => sum + (o.paidAmount || 0), 0),
    expectedRevenue: orders.reduce((sum, o) => sum + (o.price || 0), 0),
  }), [orders]);

  const statusData = useMemo(() => {
    const counts: Record<string, number> = {};
    orders.forEach(o => { counts[o.status] = (counts[o.status] || 0) + 1; });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [orders]);

  const monthlyData = useMemo(() => {
    const months: Record<string, { mes: string; ordenes: number; ingresos: number }> = {};
    orders.forEach(o => {
      const key = o.createdAt.toLocaleDateString('es-CO', { year: 'numeric', month: 'short' });
      if (!months[key]) months[key] = { mes: key, ordenes: 0, ingresos: 0 };
      months[key].ordenes += 1;
      months[key].ingresos += o.paidAmount || 0;
    });
    return Object.values(months).reverse().slice(-6);
  }, [orders]);

  const typeData = useMemo(() => {
    const types: Record<string, number> = {};
    orders.forEach(o => { types[o.workType] = (types[o.workType] || 0) + 1; });
    return Object.entries(types).map(([name, value]) => ({ name, value }));
  }, [orders]);

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="py-12 text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-muted-foreground" />
          <p className="mt-2 text-muted-foreground">Cargando estadísticas...</p>
        </CardContent>
      </Card>
    );
  }

  const conversionRate = stats.totalOrders > 0
    ? ((stats.completedOrders / stats.totalOrders) * 100).toFixed(1)
    : '0';

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="flex justify-end">
        <Button variant="outline" size="sm" onClick={() => exportOrdersToCSV(orders)}>
          <Download className="h-4 w-4 mr-2" />Exportar Órdenes CSV
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{stats.totalOrders}</div>
            <div className="text-sm text-muted-foreground">Total Órdenes</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{stats.pendingOrders}</div>
            <div className="text-sm text-muted-foreground">Pendientes</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{stats.inProgressOrders}</div>
            <div className="text-sm text-muted-foreground">En Proceso</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{stats.completedOrders}</div>
            <div className="text-sm text-muted-foreground">Completados</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-primary">{conversionRate}%</div>
            <div className="text-sm text-muted-foreground">Tasa Conversión</div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Card */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Ingresos cobrados</p>
              <p className="text-2xl font-bold text-primary">${stats.totalRevenue.toLocaleString()} COP</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Ingresos esperados</p>
              <p className="text-2xl font-bold">${stats.expectedRevenue.toLocaleString()} COP</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-lg">Órdenes por Mes</CardTitle></CardHeader>
          <CardContent>
            {monthlyData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <ReBarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="mes" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip />
                  <Bar dataKey="ordenes" fill="hsl(221, 83%, 53%)" radius={[4, 4, 0, 0]} />
                </ReBarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-center text-muted-foreground py-8">Sin datos aún</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-lg">Distribución por Estado</CardTitle></CardHeader>
          <CardContent>
            {statusData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={statusData} cx="50%" cy="50%" outerRadius={80} label={({ name, value }) => `${name}: ${value}`} dataKey="value">
                    {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-center text-muted-foreground py-8">Sin datos aún</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-lg">Ingresos Mensuales</CardTitle></CardHeader>
          <CardContent>
            {monthlyData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="mes" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip formatter={(v: number) => `$${v.toLocaleString()} COP`} />
                  <Line type="monotone" dataKey="ingresos" stroke="hsl(142, 71%, 45%)" strokeWidth={2} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-center text-muted-foreground py-8">Sin datos aún</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-lg">Tipos de Trabajo</CardTitle></CardHeader>
          <CardContent>
            {typeData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <ReBarChart data={typeData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis type="number" className="text-xs" />
                  <YAxis dataKey="name" type="category" className="text-xs" width={100} />
                  <Tooltip />
                  <Bar dataKey="value" fill="hsl(262, 83%, 58%)" radius={[0, 4, 4, 0]} />
                </ReBarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-center text-muted-foreground py-8">Sin datos aún</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Componente de gestión de contenidos
const ContentManagement = () => (
  <Card className="w-full">
    <CardHeader>
      <CardTitle className="text-xl">Gestión de Contenidos</CardTitle>
      <CardDescription>Administra el contenido educativo y recursos</CardDescription>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        <div className="p-4 border rounded-lg hover:shadow-sm transition-all">
          <h3 className="font-medium flex items-center"><BookOpen className="h-4 w-4 mr-2" />Biblioteca de Recursos</h3>
          <p className="text-muted-foreground text-sm mt-1">Gestiona libros, documentos y materiales educativos</p>
          <Button size="sm" variant="outline" className="mt-2">Administrar</Button>
        </div>
        <div className="p-4 border rounded-lg hover:shadow-sm transition-all">
          <h3 className="font-medium flex items-center"><HelpCircle className="h-4 w-4 mr-2" />Preguntas Frecuentes</h3>
          <p className="text-muted-foreground text-sm mt-1">Edita las preguntas y respuestas frecuentes</p>
          <Button size="sm" variant="outline" className="mt-2">Administrar</Button>
        </div>
        <div className="p-4 border rounded-lg hover:shadow-sm transition-all">
          <h3 className="font-medium flex items-center"><Bell className="h-4 w-4 mr-2" />Notificaciones</h3>
          <p className="text-muted-foreground text-sm mt-1">Administra notificaciones y anuncios del sistema</p>
          <Button size="sm" variant="outline" className="mt-2">Administrar</Button>
        </div>
      </div>
    </CardContent>
  </Card>
);

// Componente principal del panel de administración
const AdminDashboard = () => {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("home");
  
  if (!isAdmin) {
    toast.error("Acceso restringido", { description: "No tienes permisos para acceder a esta sección" });
    setTimeout(() => navigate("/login"), 1000);
    return null;
  }
  
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Panel de Administración Avanzado</h1>
          <p className="text-muted-foreground">Bienvenido, {user?.email || "Administrador"}</p>
        </div>
        <Button onClick={() => navigate("/")} variant="outline">Volver al sitio</Button>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-2 md:grid-cols-5 mb-6">
          <TabsTrigger value="home"><BarChart className="h-4 w-4 mr-2" /><span>Estadísticas</span></TabsTrigger>
          <TabsTrigger value="orders"><ClipboardList className="h-4 w-4 mr-2" /><span>Órdenes</span></TabsTrigger>
          <TabsTrigger value="users"><Users className="h-4 w-4 mr-2" /><span>Usuarios</span></TabsTrigger>
          <TabsTrigger value="content"><FileText className="h-4 w-4 mr-2" /><span>Contenidos</span></TabsTrigger>
          <TabsTrigger value="settings"><Settings className="h-4 w-4 mr-2" /><span>Configuración</span></TabsTrigger>
        </TabsList>
        
        <TabsContent value="home"><Analytics /></TabsContent>
        <TabsContent value="orders"><WorkOrdersManagement /></TabsContent>
        <TabsContent value="users"><UserManagement /></TabsContent>
        <TabsContent value="content"><ContentManagement /></TabsContent>
        <TabsContent value="settings"><SystemSettings /></TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
