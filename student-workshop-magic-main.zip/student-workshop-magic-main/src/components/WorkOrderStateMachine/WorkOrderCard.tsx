import { WorkOrder } from '@/types/workOrder';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { StatusBadge } from './StatusBadge';
import { WorkOrderPipeline } from './WorkOrderPipeline';
import { TransitionActions } from './TransitionActions';
import { WorkOrderHistory } from './WorkOrderHistory';
import { 
  Calendar, 
  Clock, 
  User, 
  FileText, 
  CreditCard,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useState } from 'react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface WorkOrderCardProps {
  order: WorkOrder;
  onTransition: (toStatus: any, notes?: string) => Promise<boolean>;
  isTransitioning?: boolean;
  onPaymentConfirm?: (amount: number, method: string) => void;
  onAssignExpert?: (expertId: string, expertName: string) => void;
  onReject?: (reason: string) => void;
  showActions?: boolean;
  compact?: boolean;
}

export const WorkOrderCard = ({
  order,
  onTransition,
  isTransitioning,
  onPaymentConfirm,
  onAssignExpert,
  onReject,
  showActions = true,
  compact = false
}: WorkOrderCardProps) => {
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  const daysUntilDeadline = Math.ceil(
    (new Date(order.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
  );

  const isOverdue = daysUntilDeadline < 0;
  const isUrgent = daysUntilDeadline <= 3 && daysUntilDeadline >= 0;

  return (
    <Card className="w-full overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs text-gray-500 font-mono">{order.id}</span>
              <StatusBadge status={order.status} size="sm" />
            </div>
            <CardTitle className="text-xl truncate">{order.title}</CardTitle>
            <CardDescription className="mt-1">
              {order.workType} • {order.subject} • {order.academicLevel}
            </CardDescription>
          </div>
          
          {/* Indicador de fecha límite */}
          <div className={`text-right px-3 py-2 rounded-lg ${
            isOverdue ? 'bg-red-100 text-red-700' :
            isUrgent ? 'bg-yellow-100 text-yellow-700' :
            'bg-gray-100 text-gray-700'
          }`}>
            <div className="text-xs font-medium">
              {isOverdue ? 'Vencido' : isUrgent ? 'Urgente' : 'Fecha límite'}
            </div>
            <div className="text-sm font-bold">
              {format(new Date(order.deadline), 'd MMM', { locale: es })}
            </div>
            {!isOverdue && (
              <div className="text-xs">
                {daysUntilDeadline} día{daysUntilDeadline !== 1 ? 's' : ''}
              </div>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Pipeline visual */}
        <div className="overflow-x-auto pb-2">
          <WorkOrderPipeline 
            currentStatus={order.status} 
            showLabels={!compact}
            size={compact ? 'sm' : 'md'}
          />
        </div>

        {/* Información del trabajo */}
        {!compact && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-2 text-sm">
              <User className="h-4 w-4 text-gray-400" />
              <div>
                <div className="text-xs text-gray-500">Cliente</div>
                <div className="font-medium truncate">{order.clientName}</div>
              </div>
            </div>

            {order.assignedExpertName && (
              <div className="flex items-center gap-2 text-sm">
                <User className="h-4 w-4 text-primary" />
                <div>
                  <div className="text-xs text-gray-500">Experto</div>
                  <div className="font-medium truncate">{order.assignedExpertName}</div>
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 text-sm">
              <FileText className="h-4 w-4 text-gray-400" />
              <div>
                <div className="text-xs text-gray-500">Extensión</div>
                <div className="font-medium">{order.wordCount}</div>
              </div>
            </div>

            {order.price && (
              <div className="flex items-center gap-2 text-sm">
                <CreditCard className="h-4 w-4 text-gray-400" />
                <div>
                  <div className="text-xs text-gray-500">Precio</div>
                  <div className="font-medium">
                    ${order.price.toLocaleString()} COP
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Motivo de rechazo si aplica */}
        {order.status === 'rejected' && order.rejectionReason && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <div className="text-sm font-medium text-red-700 mb-1">
              Motivo del rechazo:
            </div>
            <p className="text-sm text-red-600">{order.rejectionReason}</p>
          </div>
        )}

        {/* Acciones de transición */}
        {showActions && (
          <TransitionActions
            currentStatus={order.status}
            onTransition={onTransition}
            isTransitioning={isTransitioning}
            onPaymentConfirm={onPaymentConfirm}
            onAssignExpert={onAssignExpert}
            onReject={onReject}
          />
        )}

        {/* Historial colapsable */}
        {order.history.length > 0 && (
          <Collapsible open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" className="w-full flex items-center justify-center gap-2">
                <Clock className="h-4 w-4" />
                Ver historial ({order.history.length} cambios)
                {isHistoryOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-4">
              <WorkOrderHistory history={order.history} maxHeight="300px" />
            </CollapsibleContent>
          </Collapsible>
        )}
      </CardContent>

      <CardFooter className="bg-gray-50 text-xs text-gray-500">
        <div className="flex justify-between w-full">
          <span>
            Creado: {format(new Date(order.createdAt), "d MMM yyyy, HH:mm", { locale: es })}
          </span>
          <span>
            Actualizado: {format(new Date(order.updatedAt), "d MMM yyyy, HH:mm", { locale: es })}
          </span>
        </div>
      </CardFooter>
    </Card>
  );
};
