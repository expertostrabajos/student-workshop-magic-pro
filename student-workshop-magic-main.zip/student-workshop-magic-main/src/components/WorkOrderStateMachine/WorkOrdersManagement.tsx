import { useState, useMemo } from 'react';
import { WorkOrder, WorkOrderStatus, STATUS_ORDER, STATUS_CONFIG } from '@/types/workOrder';
import { WorkOrderCard, StatusBadge } from '@/components/WorkOrderStateMachine';
import { useWorkOrders } from '@/hooks/useWorkOrders';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Search, Filter, Plus, FileText, Clock, CheckCircle, XCircle, RefreshCw, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { isValidTransition } from '@/types/workOrder';

export const WorkOrdersManagement = () => {
  const { orders, isLoading, error, refetch, createOrder, updateOrderStatus, updateOrder } = useWorkOrders();
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  
  // Form state para nueva orden
  const [newOrder, setNewOrder] = useState({
    title: '',
    subject: '',
    workType: 'ensayo',
    academicLevel: 'universidad',
    wordCount: '',
    deadline: '',
    clientName: '',
    clientEmail: '',
    description: '',
    price: ''
  });

  // Filtrar órdenes por estado y búsqueda
  const filteredOrders = useMemo(() => {
    let result = orders;

    if (activeTab !== 'all') {
      result = result.filter(o => o.status === activeTab);
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(o => 
        o.title.toLowerCase().includes(term) ||
        o.clientName.toLowerCase().includes(term) ||
        o.id.toLowerCase().includes(term) ||
        o.subject.toLowerCase().includes(term)
      );
    }

    return result;
  }, [orders, activeTab, searchTerm]);

  // Contadores por estado
  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = { all: orders.length };
    orders.forEach(o => {
      counts[o.status] = (counts[o.status] || 0) + 1;
    });
    return counts;
  }, [orders]);

  const selectedOrder = useMemo(() => 
    orders.find(o => o.id === selectedOrderId), 
    [orders, selectedOrderId]
  );

  const handleTransition = async (toStatus: WorkOrderStatus, notes?: string): Promise<boolean> => {
    if (!selectedOrder) return false;
    
    if (!isValidTransition(selectedOrder.status, toStatus)) {
      toast.error('Transición no válida');
      return false;
    }

    setIsTransitioning(true);
    const success = await updateOrderStatus(selectedOrder.id, toStatus, notes);
    setIsTransitioning(false);

    if (success) {
      toast.success('Estado actualizado correctamente');
    }
    
    return success;
  };

  const handlePaymentConfirm = async (amount: number, method: string) => {
    if (!selectedOrder) return;
    await updateOrder(selectedOrder.id, {
      paidAmount: amount,
      paymentMethod: method,
      paymentDate: new Date()
    });
  };

  const handleAssignExpert = async (expertId: string, expertName: string) => {
    if (!selectedOrder) return;
    await updateOrder(selectedOrder.id, {
      assignedExpertId: expertId,
      assignedExpertName: expertName
    });
  };

  const handleReject = async (reason: string) => {
    if (!selectedOrder) return;
    await updateOrder(selectedOrder.id, {
      rejectionReason: reason
    });
  };

  const handleCreateOrder = async () => {
    if (!newOrder.title || !newOrder.clientName || !newOrder.clientEmail || !newOrder.deadline) {
      toast.error('Por favor completa los campos requeridos');
      return;
    }

    const result = await createOrder({
      title: newOrder.title,
      subject: newOrder.subject,
      workType: newOrder.workType,
      academicLevel: newOrder.academicLevel,
      wordCount: newOrder.wordCount,
      deadline: new Date(newOrder.deadline),
      clientName: newOrder.clientName,
      clientEmail: newOrder.clientEmail,
      description: newOrder.description,
      price: newOrder.price ? parseFloat(newOrder.price) : undefined
    });

    if (result) {
      setIsCreateDialogOpen(false);
      setNewOrder({
        title: '',
        subject: '',
        workType: 'ensayo',
        academicLevel: 'universidad',
        wordCount: '',
        deadline: '',
        clientName: '',
        clientEmail: '',
        description: '',
        price: ''
      });
    }
  };

  if (error) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <XCircle className="h-12 w-12 text-red-400 mx-auto mb-4" />
          <p className="text-red-600 mb-4">{error}</p>
          <Button onClick={refetch}>Reintentar</Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Gestión de Órdenes de Trabajo</h2>
          <p className="text-gray-600">
            Administra el flujo completo de las órdenes de trabajo
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={refetch} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Actualizar
          </Button>
          <Button onClick={() => setIsCreateDialogOpen(true)} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Nueva Orden
          </Button>
        </div>
      </div>

      {/* Estadísticas rápidas */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <FileText className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">{orders.length}</div>
                <div className="text-xs text-gray-500">Total órdenes</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-100 rounded-lg">
                <Clock className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {orders.filter(o => o.status === 'in_progress').length}
                </div>
                <div className="text-xs text-gray-500">En proceso</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {orders.filter(o => ['delivered', 'archived'].includes(o.status)).length}
                </div>
                <div className="text-xs text-gray-500">Completados</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <XCircle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {orders.filter(o => o.status === 'rejected').length}
                </div>
                <div className="text-xs text-gray-500">Rechazados</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Barra de búsqueda */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Buscar por título, cliente, ID o materia..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Filter className="h-4 w-4" />
          Filtros
        </Button>
      </div>

      {/* Tabs por estado */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="flex flex-wrap">
          <TabsTrigger value="all" className="flex items-center gap-2">
            Todos
            <span className="bg-gray-200 px-2 py-0.5 rounded-full text-xs">
              {statusCounts.all || 0}
            </span>
          </TabsTrigger>
          {STATUS_ORDER.slice(0, 7).map(status => (
            <TabsTrigger 
              key={status} 
              value={status}
              className="flex items-center gap-2"
            >
              {STATUS_CONFIG[status].label}
              {statusCounts[status] > 0 && (
                <span className={`${STATUS_CONFIG[status].bgColor} px-2 py-0.5 rounded-full text-xs`}>
                  {statusCounts[status]}
                </span>
              )}
            </TabsTrigger>
          ))}
          <TabsTrigger value="rejected" className="flex items-center gap-2">
            {STATUS_CONFIG.rejected.label}
            {statusCounts.rejected > 0 && (
              <span className="bg-red-100 px-2 py-0.5 rounded-full text-xs">
                {statusCounts.rejected}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          {isLoading ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Loader2 className="h-12 w-12 text-gray-300 mx-auto mb-4 animate-spin" />
                <p className="text-gray-500">Cargando órdenes...</p>
              </CardContent>
            </Card>
          ) : filteredOrders.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No se encontraron órdenes</p>
                <Button className="mt-4" onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Crear primera orden
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6">
              {filteredOrders.map(orderItem => (
                <div 
                  key={orderItem.id}
                  onClick={() => setSelectedOrderId(orderItem.id)}
                  className={`cursor-pointer transition-all ${
                    selectedOrderId === orderItem.id 
                      ? 'ring-2 ring-primary ring-offset-2 rounded-lg' 
                      : ''
                  }`}
                >
                  <WorkOrderCard
                    order={orderItem}
                    onTransition={handleTransition}
                    isTransitioning={isTransitioning}
                    onPaymentConfirm={handlePaymentConfirm}
                    onAssignExpert={handleAssignExpert}
                    onReject={handleReject}
                    showActions={selectedOrderId === orderItem.id}
                    compact={selectedOrderId !== orderItem.id}
                  />
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Dialog para crear nueva orden */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nueva Orden de Trabajo</DialogTitle>
            <DialogDescription>
              Crea una nueva orden de trabajo para un cliente
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título del trabajo *</Label>
              <Input
                id="title"
                placeholder="Ej: Ensayo sobre economía circular"
                value={newOrder.title}
                onChange={(e) => setNewOrder({ ...newOrder, title: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="clientName">Nombre del cliente *</Label>
                <Input
                  id="clientName"
                  placeholder="Nombre completo"
                  value={newOrder.clientName}
                  onChange={(e) => setNewOrder({ ...newOrder, clientName: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="clientEmail">Email del cliente *</Label>
                <Input
                  id="clientEmail"
                  type="email"
                  placeholder="email@ejemplo.com"
                  value={newOrder.clientEmail}
                  onChange={(e) => setNewOrder({ ...newOrder, clientEmail: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="workType">Tipo de trabajo</Label>
                <select
                  id="workType"
                  value={newOrder.workType}
                  onChange={(e) => setNewOrder({ ...newOrder, workType: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md"
                >
                  <option value="ensayo">Ensayo</option>
                  <option value="investigacion">Investigación</option>
                  <option value="tesis">Tesis</option>
                  <option value="articulo">Artículo</option>
                  <option value="monografia">Monografía</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="academicLevel">Nivel académico</Label>
                <select
                  id="academicLevel"
                  value={newOrder.academicLevel}
                  onChange={(e) => setNewOrder({ ...newOrder, academicLevel: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md"
                >
                  <option value="primaria">Primaria</option>
                  <option value="secundaria">Secundaria</option>
                  <option value="universidad">Universidad</option>
                  <option value="maestria">Maestría</option>
                  <option value="doctorado">Doctorado</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="subject">Materia/Asignatura</Label>
                <Input
                  id="subject"
                  placeholder="Ej: Economía"
                  value={newOrder.subject}
                  onChange={(e) => setNewOrder({ ...newOrder, subject: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="wordCount">Extensión</Label>
                <Input
                  id="wordCount"
                  placeholder="Ej: 3000 palabras"
                  value={newOrder.wordCount}
                  onChange={(e) => setNewOrder({ ...newOrder, wordCount: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="deadline">Fecha límite *</Label>
                <Input
                  id="deadline"
                  type="date"
                  value={newOrder.deadline}
                  onChange={(e) => setNewOrder({ ...newOrder, deadline: e.target.value })}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">Precio (COP)</Label>
                <Input
                  id="price"
                  type="number"
                  placeholder="50000"
                  value={newOrder.price}
                  onChange={(e) => setNewOrder({ ...newOrder, price: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción / Requisitos</Label>
              <Textarea
                id="description"
                placeholder="Describe los requisitos específicos del trabajo..."
                value={newOrder.description}
                onChange={(e) => setNewOrder({ ...newOrder, description: e.target.value })}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreateOrder}>
              Crear Orden
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WorkOrdersManagement;
