import { useState } from 'react';
import { WorkOrderStatus, WorkOrderTransition, STATUS_CONFIG, getValidTransitions } from '@/types/workOrder';
import { Button } from '@/components/ui/button';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  ArrowRight, 
  CreditCard, 
  UserCheck, 
  Play, 
  Send, 
  ThumbsUp, 
  ThumbsDown, 
  Package, 
  Archive,
  RotateCcw
} from 'lucide-react';

interface TransitionActionsProps {
  currentStatus: WorkOrderStatus;
  onTransition: (toStatus: WorkOrderStatus, notes?: string) => Promise<boolean>;
  isTransitioning?: boolean;
  onPaymentConfirm?: (amount: number, method: string) => void;
  onAssignExpert?: (expertId: string, expertName: string) => void;
  onReject?: (reason: string) => void;
}

const transitionIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  'Enviar a pago': CreditCard,
  'Confirmar pago': CreditCard,
  'Asignar experto': UserCheck,
  'Iniciar trabajo': Play,
  'Enviar a revisión': Send,
  'Aprobar trabajo': ThumbsUp,
  'Solicitar correcciones': ThumbsDown,
  'Marcar como entregado': Package,
  'Archivar trabajo': Archive,
  'Reanudar correcciones': RotateCcw,
  'Volver a creación': RotateCcw
};

export const TransitionActions = ({
  currentStatus,
  onTransition,
  isTransitioning = false,
  onPaymentConfirm,
  onAssignExpert,
  onReject
}: TransitionActionsProps) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedTransition, setSelectedTransition] = useState<WorkOrderTransition | null>(null);
  const [notes, setNotes] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('nequi');
  const [expertName, setExpertName] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');

  const transitions = getValidTransitions(currentStatus);

  const handleTransitionClick = (transition: WorkOrderTransition) => {
    setSelectedTransition(transition);
    setNotes('');
    setPaymentAmount('');
    setExpertName('');
    setRejectionReason('');
    setIsDialogOpen(true);
  };

  const handleConfirm = async () => {
    if (!selectedTransition) return;

    // Manejar casos especiales
    if (selectedTransition.requiresPayment && onPaymentConfirm) {
      onPaymentConfirm(parseFloat(paymentAmount) || 0, paymentMethod);
    }

    if (selectedTransition.to === 'assigned' && onAssignExpert) {
      onAssignExpert(`exp-${Date.now()}`, expertName);
    }

    if (selectedTransition.to === 'rejected' && onReject) {
      onReject(rejectionReason);
    }

    const success = await onTransition(
      selectedTransition.to, 
      notes || rejectionReason || undefined
    );

    if (success) {
      setIsDialogOpen(false);
    }
  };

  const getButtonVariant = (transition: WorkOrderTransition) => {
    if (transition.to === 'rejected') return 'destructive';
    if (transition.to === 'approved' || transition.to === 'delivered') return 'default';
    return 'outline';
  };

  return (
    <div className="space-y-4">
      <h4 className="font-medium text-sm text-gray-700">Acciones disponibles</h4>
      
      <div className="flex flex-wrap gap-2">
        {transitions.map((transition) => {
          const IconComponent = transitionIcons[transition.label] || ArrowRight;
          
          return (
            <Button
              key={`${transition.from}-${transition.to}`}
              variant={getButtonVariant(transition)}
              size="sm"
              onClick={() => handleTransitionClick(transition)}
              disabled={isTransitioning}
              className="flex items-center gap-2"
            >
              <IconComponent className="h-4 w-4" />
              {transition.label}
            </Button>
          );
        })}
      </div>

      {transitions.length === 0 && (
        <p className="text-sm text-gray-500">
          No hay acciones disponibles para este estado.
        </p>
      )}

      {/* Dialog de confirmación */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {selectedTransition?.label}
            </DialogTitle>
            <DialogDescription>
              {selectedTransition && STATUS_CONFIG[selectedTransition.to].description}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* Campos especiales según el tipo de transición */}
            {selectedTransition?.requiresPayment && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="amount">Monto pagado (COP)</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="50000"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="method">Método de pago</Label>
                  <select
                    id="method"
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="nequi">Nequi</option>
                    <option value="daviplata">Daviplata</option>
                    <option value="transferencia">Transferencia bancaria</option>
                    <option value="efectivo">Efectivo</option>
                  </select>
                </div>
              </>
            )}

            {selectedTransition?.to === 'assigned' && (
              <div className="space-y-2">
                <Label htmlFor="expert">Nombre del experto</Label>
                <Input
                  id="expert"
                  placeholder="Nombre del experto asignado"
                  value={expertName}
                  onChange={(e) => setExpertName(e.target.value)}
                />
              </div>
            )}

            {selectedTransition?.to === 'rejected' && (
              <div className="space-y-2">
                <Label htmlFor="reason">Motivo del rechazo</Label>
                <Textarea
                  id="reason"
                  placeholder="Describe qué correcciones se necesitan..."
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
            )}

            {/* Notas opcionales */}
            {!selectedTransition?.to.includes('rejected') && (
              <div className="space-y-2">
                <Label htmlFor="notes">Notas adicionales (opcional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Agrega notas sobre esta acción..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleConfirm}
              disabled={isTransitioning || (selectedTransition?.to === 'rejected' && !rejectionReason)}
              variant={selectedTransition?.to === 'rejected' ? 'destructive' : 'default'}
            >
              {isTransitioning ? 'Procesando...' : 'Confirmar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
