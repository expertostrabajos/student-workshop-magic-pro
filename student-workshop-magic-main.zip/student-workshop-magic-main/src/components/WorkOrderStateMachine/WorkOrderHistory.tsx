import { WorkOrderHistoryEntry, STATUS_CONFIG } from '@/types/workOrder';
import { ScrollArea } from '@/components/ui/scroll-area';
import { StatusBadge } from './StatusBadge';
import { ArrowRight, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface WorkOrderHistoryProps {
  history: WorkOrderHistoryEntry[];
  maxHeight?: string;
}

export const WorkOrderHistory = ({ history, maxHeight = '400px' }: WorkOrderHistoryProps) => {
  const sortedHistory = [...history].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  return (
    <div className="border rounded-lg">
      <div className="p-4 border-b bg-gray-50">
        <h4 className="font-medium flex items-center gap-2">
          <Clock className="h-4 w-4" />
          Historial de cambios
        </h4>
      </div>
      
      <ScrollArea style={{ maxHeight }}>
        <div className="p-4 space-y-4">
          {sortedHistory.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">
              No hay historial disponible
            </p>
          ) : (
            sortedHistory.map((entry, index) => (
              <div 
                key={entry.id} 
                className="flex items-start gap-3 pb-4 border-b last:border-b-0"
              >
                {/* Timeline indicator */}
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 rounded-full bg-primary" />
                  {index < sortedHistory.length - 1 && (
                    <div className="w-0.5 h-full bg-gray-200 mt-1" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  {/* Fecha y hora */}
                  <div className="text-xs text-gray-500 mb-2">
                    {format(new Date(entry.timestamp), "d 'de' MMMM, yyyy 'a las' HH:mm", { locale: es })}
                  </div>

                  {/* Transición */}
                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    <StatusBadge status={entry.fromStatus} size="sm" />
                    <ArrowRight className="h-4 w-4 text-gray-400" />
                    <StatusBadge status={entry.toStatus} size="sm" />
                  </div>

                  {/* Realizado por */}
                  <p className="text-sm text-gray-600">
                    Por: <span className="font-medium">{entry.performedBy}</span>
                  </p>

                  {/* Notas */}
                  {entry.notes && (
                    <div className="mt-2 p-2 bg-gray-50 rounded text-sm text-gray-600">
                      {entry.notes}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
};
