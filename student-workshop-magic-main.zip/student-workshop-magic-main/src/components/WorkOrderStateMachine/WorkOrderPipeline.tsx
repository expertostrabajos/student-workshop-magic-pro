import { WorkOrderStatus, STATUS_ORDER, STATUS_CONFIG, ALTERNATIVE_STATUSES } from '@/types/workOrder';
import { 
  FileText, 
  CreditCard, 
  CheckCircle, 
  UserCheck, 
  Clock, 
  Eye, 
  XCircle, 
  ThumbsUp, 
  Package, 
  Archive,
  ArrowRight,
  CornerDownLeft
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface WorkOrderPipelineProps {
  currentStatus: WorkOrderStatus;
  showLabels?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const iconMap = {
  FileText,
  CreditCard,
  CheckCircle,
  UserCheck,
  Clock,
  Eye,
  XCircle,
  ThumbsUp,
  Package,
  Archive
};

export const WorkOrderPipeline = ({ 
  currentStatus, 
  showLabels = true,
  size = 'md' 
}: WorkOrderPipelineProps) => {
  const currentIndex = STATUS_ORDER.indexOf(currentStatus);
  const isRejected = currentStatus === 'rejected';

  const sizeClasses = {
    sm: {
      container: 'gap-1',
      step: 'w-8 h-8',
      icon: 'h-4 w-4',
      label: 'text-xs',
      arrow: 'h-3 w-3'
    },
    md: {
      container: 'gap-2',
      step: 'w-10 h-10',
      icon: 'h-5 w-5',
      label: 'text-sm',
      arrow: 'h-4 w-4'
    },
    lg: {
      container: 'gap-3',
      step: 'w-12 h-12',
      icon: 'h-6 w-6',
      label: 'text-base',
      arrow: 'h-5 w-5'
    }
  };

  const sizes = sizeClasses[size];

  return (
    <div className="w-full">
      {/* Pipeline principal */}
      <div className={cn("flex items-center justify-between flex-wrap", sizes.container)}>
        {STATUS_ORDER.map((status, index) => {
          const config = STATUS_CONFIG[status];
          const IconComponent = iconMap[config.icon as keyof typeof iconMap] || FileText;
          
          const isPast = index < currentIndex;
          const isCurrent = status === currentStatus && !isRejected;
          const isFuture = index > currentIndex;

          return (
            <div key={status} className="flex items-center">
              <div className="flex flex-col items-center">
                {/* Círculo del estado */}
                <div
                  className={cn(
                    "rounded-full flex items-center justify-center transition-all duration-300",
                    sizes.step,
                    isPast && "bg-green-500 text-white shadow-md",
                    isCurrent && `${config.bgColor} ${config.color} ring-2 ring-offset-2 ring-current shadow-lg scale-110`,
                    isFuture && "bg-gray-200 text-gray-400",
                    isRejected && status === 'review' && "bg-red-100 text-red-600 ring-2 ring-red-400"
                  )}
                >
                  {isPast ? (
                    <CheckCircle className={sizes.icon} />
                  ) : (
                    <IconComponent className={sizes.icon} />
                  )}
                </div>
                
                {/* Etiqueta */}
                {showLabels && (
                  <span 
                    className={cn(
                      "mt-2 text-center max-w-[80px] leading-tight",
                      sizes.label,
                      isPast && "text-green-600 font-medium",
                      isCurrent && `${config.color} font-bold`,
                      isFuture && "text-gray-400"
                    )}
                  >
                    {config.label}
                  </span>
                )}
              </div>

              {/* Flecha conectora */}
              {index < STATUS_ORDER.length - 1 && (
                <div className="flex-shrink-0 mx-1">
                  <ArrowRight 
                    className={cn(
                      sizes.arrow,
                      index < currentIndex ? "text-green-500" : "text-gray-300"
                    )} 
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Estado de rechazo (cuando aplica) */}
      {isRejected && (
        <div className="mt-4 flex items-center justify-center">
          <div className="flex items-center bg-red-50 border border-red-200 rounded-lg px-4 py-2">
            <CornerDownLeft className="h-4 w-4 text-red-500 mr-2" />
            <div className="flex items-center gap-2">
              <div className={cn(
                "rounded-full flex items-center justify-center",
                sizes.step,
                "bg-red-100 text-red-600 ring-2 ring-red-400"
              )}>
                <XCircle className={sizes.icon} />
              </div>
              {showLabels && (
                <span className="text-red-600 font-bold">
                  Rechazado - Requiere Correcciones
                </span>
              )}
            </div>
            <ArrowRight className="h-4 w-4 text-red-500 mx-2" />
            <span className="text-sm text-red-600">Volver a "En Proceso"</span>
          </div>
        </div>
      )}
    </div>
  );
};
