import { WorkOrderStatus, STATUS_CONFIG } from '@/types/workOrder';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  CreditCard, 
  CheckCircle, 
  UserCheck, 
  Clock, 
  Eye, 
  XCircle, 
  ThumbsUp, 
  Package, 
  Archive 
} from 'lucide-react';

interface StatusBadgeProps {
  status: WorkOrderStatus;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

const iconMap = {
  FileText,
  CreditCard,
  CheckCircle,
  UserCheck,
  Clock,
  Eye,
  XCircle,
  ThumbsUp,
  Package,
  Archive
};

export const StatusBadge = ({ status, size = 'md', showIcon = true }: StatusBadgeProps) => {
  const config = STATUS_CONFIG[status];
  const IconComponent = iconMap[config.icon as keyof typeof iconMap] || FileText;

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-3 py-1',
    lg: 'text-base px-4 py-1.5'
  };

  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-4 w-4',
    lg: 'h-5 w-5'
  };

  return (
    <Badge 
      variant="outline" 
      className={`${config.bgColor} ${config.color} ${sizeClasses[size]} inline-flex items-center gap-1.5 font-medium`}
    >
      {showIcon && <IconComponent className={iconSizes[size]} />}
      {config.label}
    </Badge>
  );
};
