
import { useState, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { toast } from "sonner";
import { Upload, File, X, CheckCircle, AlertCircle } from "lucide-react";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useNotificationContext } from "@/components/NotificationProvider";

interface FileUploadComponentProps {
  onFilesUploaded?: (files: File[]) => void;
  maxFiles?: number;
  maxSizeMB?: number;
  allowedTypes?: string[];
  title?: string;
  description?: string;
  showCard?: boolean;
}

const FileUploadComponent = ({
  onFilesUploaded,
  maxFiles = 5,
  maxSizeMB = 10,
  allowedTypes = [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".jpg", ".jpeg", ".png", ".txt", ".zip"],
  title = "Subir Archivos",
  description = "Arrastra y suelta tus archivos aquí o haz clic para seleccionarlos",
  showCard = true
}: FileUploadComponentProps) => {
  const { toast: shadowToast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [dragActive, setDragActive] = useState(false);
  const { addNotification } = useNotificationContext();

  const formatFileSize = (size: number) => {
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  };

  const validateFile = (file: File): boolean => {
    // Check file size
    if (file.size > maxSizeMB * 1024 * 1024) {
      toast.error(`El archivo ${file.name} excede el tamaño máximo de ${maxSizeMB}MB`, {
        icon: <AlertCircle className="w-4 h-4 text-red-500" />
      });
      return false;
    }

    // Check file type
    if (allowedTypes.length > 0) {
      const extension = `.${file.name.split('.').pop()?.toLowerCase()}`;
      if (!allowedTypes.includes(extension)) {
        toast.error(`El tipo de archivo ${extension} no está permitido`, {
          icon: <AlertCircle className="w-4 h-4 text-red-500" />
        });
        return false;
      }
    }

    return true;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      addNewFiles(Array.from(e.target.files));
    }
  };

  const addNewFiles = (newFiles: File[]) => {
    if (files.length + newFiles.length > maxFiles) {
      toast.error(`No puedes subir más de ${maxFiles} archivos a la vez`, {
        icon: <AlertCircle className="w-4 h-4 text-red-500" />
      });
      return;
    }

    const validFiles = newFiles.filter(validateFile);
    
    if (validFiles.length > 0) {
      validFiles.forEach(file => {
        const fileId = `${file.name}-${Date.now()}`;
        setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));
        
        // Simulate upload progress
        const interval = setInterval(() => {
          setUploadProgress(prev => {
            const currentProgress = prev[fileId] || 0;
            if (currentProgress >= 100) {
              clearInterval(interval);
              
              toast.success(`Archivo "${file.name}" subido correctamente`, {
                icon: <CheckCircle className="w-4 h-4 text-green-500" />
              });
              
              addNotification({
                title: "Archivo subido",
                message: `Tu archivo "${file.name}" se ha subido correctamente.`,
                type: "success"
              });
              
              return prev;
            }
            return { ...prev, [fileId]: Math.min(currentProgress + 10, 100) };
          });
        }, 200);
      });
      
      const updatedFiles = [...files, ...validFiles];
      setFiles(updatedFiles);
      
      if (onFilesUploaded) {
        onFilesUploaded(updatedFiles);
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!dragActive) setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      addNewFiles(Array.from(e.dataTransfer.files));
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
    if (onFilesUploaded) {
      onFilesUploaded(files.filter((_, i) => i !== index));
    }
  };

  const openFileDialog = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const renderFilesList = () => {
    if (files.length === 0) return null;
    
    return (
      <div className="mt-4 space-y-3">
        <h4 className="text-sm font-medium text-gray-700">Archivos ({files.length}/{maxFiles}):</h4>
        {files.map((file, index) => {
          const fileId = `${file.name}-${file.lastModified}`;
          const progress = uploadProgress[fileId] || 100;
          
          return (
            <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
              <div className="flex items-center flex-1 pr-3">
                <File className="w-5 h-5 text-gray-500 mr-2 flex-shrink-0" />
                <div className="overflow-hidden">
                  <p className="text-sm font-medium text-gray-700 truncate">{file.name}</p>
                  <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                </div>
              </div>
              
              <div className="w-24 mr-3">
                <Progress value={progress} className="h-2" />
              </div>
              
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  removeFile(index);
                }}
                className="text-red-500 hover:text-red-700 flex-shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    );
  };

  const upload = (
    <div>
      <div 
        className={`border-2 border-dashed ${dragActive ? 'border-green-500 bg-green-50' : 'border-gray-300'} rounded-lg p-6 text-center hover:bg-gray-50 transition-colors cursor-pointer`}
        onClick={openFileDialog}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <input
          type="file"
          id="fileUpload"
          ref={fileInputRef}
          multiple
          onChange={handleFileChange}
          className="hidden"
          accept={allowedTypes.join(',')}
        />
        <label htmlFor="fileUpload" className="cursor-pointer">
          <Upload className={`w-8 h-8 ${dragActive ? 'text-green-500' : 'text-gray-400'} mx-auto mb-2`} />
          <p className="text-sm text-gray-500">
            <span className="text-green-500 font-medium">Haz clic para subir archivos</span> o arrastra y suelta
          </p>
          <p className="text-xs text-gray-400 mt-1">
            Máximo {maxFiles} archivos • Tamaño máximo {maxSizeMB}MB
          </p>
          <p className="text-xs text-gray-400 mt-1">
            Formatos permitidos: {allowedTypes.join(', ')}
          </p>
        </label>
      </div>
      
      {renderFilesList()}
    </div>
  );

  if (!showCard) {
    return upload;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {upload}
      </CardContent>
    </Card>
  );
};

export default FileUploadComponent;
