
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Phone, MapPin, Globe, Award, Users, Home } from "lucide-react";
import { Link } from "react-router-dom";

const AboutSection = () => {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-3xl mx-auto text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Acerca de Nosotros</h1>
        <p className="text-gray-600 text-lg">
          Somos expertos en brindar soporte académico profesional para estudiantes en Colombia
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Award className="mr-2 h-5 w-5 text-green-500" />
              Nuestra Misión
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              Ayudar a estudiantes a alcanzar su máximo potencial académico proporcionando servicios
              de soporte educativo de alta calidad, personalizados y éticos que les permitan superar
              desafíos académicos y desarrollar habilidades para el éxito a largo plazo.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Globe className="mr-2 h-5 w-5 text-green-500" />
              Nuestra Visión
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              Ser reconocidos como el mejor soporte académico en Colombia, transformando la manera
              en que los estudiantes abordan sus desafíos educativos y contribuyendo al desarrollo
              académico y profesional de la comunidad estudiantil colombiana.
            </p>
          </CardContent>
        </Card>
      </div>
      
      <div className="max-w-xl mx-auto bg-white shadow-md rounded-lg overflow-hidden border border-gray-200">
        <div className="p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <Users className="mr-2 h-5 w-5 text-green-500" />
            Contacto
          </h2>
          
          <div className="space-y-4">
            <div className="flex items-center">
              <Mail className="h-5 w-5 text-green-600 mr-3" />
              <span>contacto@experto-trabajos.com</span>
            </div>
            
            <div className="flex items-center">
              <Phone className="h-5 w-5 text-green-600 mr-3" />
              <span>+57 3142135852</span>
            </div>
            
            <div className="flex items-center">
              <MapPin className="h-5 w-5 text-green-600 mr-3" />
              <span>Bogotá, Colombia</span>
            </div>
          </div>
          
          <div className="mt-6">
            <Link to="/">
              <Button variant="outline" className="w-full flex items-center justify-center">
                <Home className="mr-2 h-4 w-4" />
                Volver al Inicio
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutSection;
