
import { useState, useEffect, useCallback, memo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Search, Menu, X, LogIn } from "lucide-react";
import TranslationButton from "./TranslationButton";
import ThemeToggle from "./ThemeToggle";
import { useThrottledCallback } from "@/hooks/useThrottle";

const Navbar = memo(() => {
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const handleResize = useThrottledCallback(() => {
    if (window.innerWidth >= 768) {
      setMobileMenuOpen(false);
    }
  }, 150);

  useEffect(() => {
    window.addEventListener("resize", handleResize);
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, [handleResize]);

  const toggleMenu = useCallback(() => {
    setMobileMenuOpen(prev => !prev);
  }, []);

  const toggleSearch = useCallback(() => {
    setSearchOpen(prev => !prev);
  }, []);

  const goToLogin = useCallback(() => {
    navigate('/login');
  }, [navigate]);

  return (
    <header className="sticky top-0 z-50 w-full bg-background shadow-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <span className="text-xl font-bold text-foreground">StudentHelp</span>
            </Link>
          </div>
          
          <div className="hidden md:block">
            <nav className="ml-10 flex items-center space-x-4">
              <Link to="/" className="text-muted-foreground hover:bg-muted px-3 py-2 rounded-md text-sm font-medium">
                Inicio
              </Link>
              <a href="#servicios" className="text-muted-foreground hover:bg-muted px-3 py-2 rounded-md text-sm font-medium">
                Servicios
              </a>
              <a href="#precios" className="text-muted-foreground hover:bg-muted px-3 py-2 rounded-md text-sm font-medium">
                Precios
              </a>
              <a href="#solicitar" className="text-muted-foreground hover:bg-muted px-3 py-2 rounded-md text-sm font-medium">
                Solicitar
              </a>
              <Link to="/how-it-works" className="text-muted-foreground hover:bg-muted px-3 py-2 rounded-md text-sm font-medium">
                Cómo Funciona
              </Link>
              <Link to="/acerca-de" className="text-muted-foreground hover:bg-muted px-3 py-2 rounded-md text-sm font-medium">
                Acerca de
              </Link>
            </nav>
          </div>
          
          <div className="flex items-center space-x-2">
            <ThemeToggle />
            <TranslationButton />
            
            <Button variant="ghost" size="icon" onClick={toggleSearch} aria-label="Buscar">
              <Search className="h-5 w-5" />
            </Button>

            <Button 
              variant="outline" 
              size="sm" 
              className="hidden md:flex items-center text-primary border-primary hover:bg-muted"
              onClick={goToLogin}
            >
              <LogIn className="mr-2 h-4 w-4" />
              Iniciar Sesión
            </Button>

            <div className="md:hidden">
              <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Menú principal">
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-background shadow-md z-50">
          <nav className="p-4">
            <Link to="/" className="block py-2 text-muted-foreground hover:bg-muted rounded-md">
              Inicio
            </Link>
            <a href="#servicios" className="block py-2 text-muted-foreground hover:bg-muted rounded-md">
              Servicios
            </a>
            <a href="#precios" className="block py-2 text-muted-foreground hover:bg-muted rounded-md">
              Precios
            </a>
            <a href="#solicitar" className="block py-2 text-muted-foreground hover:bg-muted rounded-md">
              Solicitar
            </a>
            <Link to="/how-it-works" className="block py-2 text-muted-foreground hover:bg-muted rounded-md">
              Cómo Funciona
            </Link>
            <Link to="/acerca-de" className="block py-2 text-muted-foreground hover:bg-muted rounded-md">
              Acerca de
            </Link>
            <Link to="/login" className="block py-2 text-primary hover:bg-muted rounded-md flex items-center">
              <LogIn className="mr-2 h-4 w-4" />
              Iniciar Sesión
            </Link>
          </nav>
        </div>
      )}

      {searchOpen && (
        <div className="fixed top-0 left-0 w-full h-full bg-background/95 z-50 flex items-center justify-center">
          <div className="relative w-full max-w-md">
            <input
              type="text"
              placeholder="Buscar..."
              className="w-full px-4 py-2 border border-input rounded-md shadow-sm focus:ring-ring focus:border-ring"
            />
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleSearch}
              className="absolute top-1/2 right-3 -translate-y-1/2"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
      )}
    </header>
  );
});

Navbar.displayName = 'Navbar';

export default Navbar;
