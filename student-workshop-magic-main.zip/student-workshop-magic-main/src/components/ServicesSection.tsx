
import { motion } from "framer-motion";
import ServiceCard from "./ServiceCard";
import SocialShare from "./SocialShare";
import { FileText, Book, Clock, Award } from "lucide-react";
import { ReactNode } from "react";

interface Service {
  title: string;
  description: string;
  icon: ReactNode;
}

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, delay: i * 0.12, ease: "easeOut" as const },
  }),
};

const ServicesSection = () => {
  const services: Service[] = [
    {
      title: "Ensayos y Trabajos Escritos",
      description: "Desarrollo de ensayos académicos con investigación profunda y argumentación sólida.",
      icon: <FileText className="w-6 h-6 text-primary" />,
    },
    {
      title: "Proyectos de Investigación",
      description: "Asistencia en proyectos de investigación con metodología rigurosa.",
      icon: <Book className="w-6 h-6 text-primary" />,
    },
    {
      title: "Entregas Urgentes",
      description: "Servicio express para trabajos con plazos ajustados.",
      icon: <Clock className="w-6 h-6 text-primary" />,
    },
    {
      title: "Revisión y Corrección",
      description: "Revisión detallada y corrección de trabajos existentes.",
      icon: <Award className="w-6 h-6 text-primary" />,
    },
  ];

  return (
    <section id="servicios" className="py-12 md:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-foreground mb-4">Nuestros Servicios</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Ofrecemos una amplia gama de servicios académicos para ayudarte a alcanzar tus objetivos.
          </p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={index}
              custom={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-60px" }}
              variants={cardVariants}
              whileHover={{ y: -8, transition: { duration: 0.25 } }}
            >
              <ServiceCard {...service} />
            </motion.div>
          ))}
        </div>
        <SocialShare section="servicios" />
      </div>
    </section>
  );
};

export default ServicesSection;
