import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { 
  Search, 
  BookOpen, 
  FileText,
  ArrowRight, 
  BookMarked, 
  Library, 
  Video, 
  GraduationCap, 
  Share2,
  Star,
  ExternalLink,
  Download,
  Clock,
  Book,
  Sparkles,
  Lightbulb,
  Trophy,
  Pin,
  PinOff,
  Bookmark,
  BookmarkCheck,
  LinkIcon,
  Plus
} from "lucide-react";

interface Resource {
  id: string;
  title: string;
  type: "article" | "book" | "video" | "course" | "tool";
  source: string;
  url: string;
  thumbnail?: string;
  description: string;
  relevance: number; // 0-100
  tags: string[];
  pinned?: boolean;
  saved?: boolean;
}

interface SkillProgress {
  id: string;
  name: string;
  progress: number;
  resources: number;
  level: "beginner" | "intermediate" | "advanced";
}

const RecommendationSystem = () => {
  const [resources, setResources] = useState<Resource[]>([
    {
      id: "1",
      title: "Guía completa de análisis literario",
      type: "article",
      source: "Academia Literaria",
      url: "https://example.com/guia-analisis",
      description: "Aprende las técnicas fundamentales para analizar obras literarias con profundidad y precisión académica.",
      relevance: 95,
      tags: ["literatura", "análisis crítico", "ensayo"],
      pinned: true,
      saved: true
    },
    {
      id: "2",
      title: "Métodos de Investigación Cualitativa",
      type: "book",
      source: "Editorial Académica",
      url: "https://example.com/metodos-investigacion",
      description: "Manual completo sobre metodologías de investigación cualitativa para trabajos académicos.",
      relevance: 88,
      tags: ["investigación", "metodología", "cualitativa"]
    },
    {
      id: "3",
      title: "Técnicas avanzadas de redacción académica",
      type: "video",
      source: "AcademyTube",
      url: "https://example.com/redaccion-academica",
      thumbnail: "https://i.pravatar.cc/150?img=3",
      description: "Aprende a mejorar tu redacción académica con consejos de expertos en lingüística.",
      relevance: 92,
      tags: ["redacción", "escritura", "ensayo"]
    },
    {
      id: "4",
      title: "Curso de Estadística para Ciencias Sociales",
      type: "course",
      source: "Universidad Virtual",
      url: "https://example.com/estadistica-ciencias-sociales",
      description: "Curso introductorio a la estadística aplicada a investigaciones en ciencias sociales.",
      relevance: 78,
      tags: ["estadística", "ciencias sociales", "análisis cuantitativo"]
    },
    {
      id: "5",
      title: "Herramientas para organización de bibliografía",
      type: "tool",
      source: "Research Tools",
      url: "https://example.com/zotero-guide",
      description: "Aprende a usar Zotero y otras herramientas para organizar tus referencias bibliográficas.",
      relevance: 85,
      tags: ["bibliografía", "zotero", "organización"]
    },
    {
      id: "6",
      title: "Fundamentos del pensamiento crítico",
      type: "article",
      source: "Revista de Filosofía",
      url: "https://example.com/pensamiento-critico",
      description: "Artículo académico sobre los fundamentos y aplicaciones del pensamiento cr��tico.",
      relevance: 90,
      tags: ["pensamiento crítico", "filosofía", "lógica"]
    },
    {
      id: "7",
      title: "Realismo Mágico en Gabriel García Márquez",
      type: "book",
      source: "Editorial Latinoamericana",
      url: "https://example.com/realismo-magico",
      description: "Análisis profundo del realismo mágico en la obra de Gabriel García Márquez.",
      relevance: 94,
      tags: ["literatura", "realismo mágico", "García Márquez"]
    },
    {
      id: "8",
      title: "Cómo estructurar una tesis doctoral",
      type: "video",
      source: "PhD Success",
      url: "https://example.com/estructurar-tesis",
      thumbnail: "https://i.pravatar.cc/150?img=4",
      description: "Tutorial detallado sobre la estructura y organización de una tesis doctoral.",
      relevance: 82,
      tags: ["tesis", "doctorado", "estructura"]
    }
  ]);
  
  const [userInterests, setUserInterests] = useState<string[]>(["literatura", "ensayo", "análisis crítico"]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredResources, setFilteredResources] = useState<Resource[]>([]);
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("recommended");
  const [suggestedTopics, setSuggestedTopics] = useState<{id: string, name: string}[]>([
    { id: "t1", name: "Realismo mágico" },
    { id: "t2", name: "Análisis de discurso" },
    { id: "t3", name: "Metodología cualitativa" },
    { id: "t4", name: "Estructura de ensayos" }
  ]);
  
  const [skillProgress, setSkillProgress] = useState<SkillProgress[]>([
    {
      id: "s1",
      name: "Análisis Literario",
      progress: 65,
      resources: 12,
      level: "intermediate"
    },
    {
      id: "s2",
      name: "Redacción Académica",
      progress: 78,
      resources: 18,
      level: "advanced"
    },
    {
      id: "s3",
      name: "Metodología de Investigación",
      progress: 42,
      resources: 8,
      level: "beginner"
    },
    {
      id: "s4",
      name: "Gestión Bibliográfica",
      progress: 30,
      resources: 5,
      level: "beginner"
    }
  ]);
  
  useEffect(() => {
    let filtered = [...resources];
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(resource => 
        resource.title.toLowerCase().includes(query) || 
        resource.description.toLowerCase().includes(query) ||
        resource.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }
    
    if (activeTag) {
      filtered = filtered.filter(resource => 
        resource.tags.includes(activeTag)
      );
    }
    
    filtered.sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return b.relevance - a.relevance;
    });
    
    setFilteredResources(filtered);
  }, [resources, searchQuery, activeTag]);
  
  useEffect(() => {
    let filtered = [...resources];
    
    if (activeTab === "recommended") {
      filtered = filtered.filter(resource => 
        resource.relevance > 80 || 
        resource.tags.some(tag => userInterests.includes(tag))
      );
    } else if (activeTab === "saved") {
      filtered = filtered.filter(resource => resource.saved);
    } else if (activeTab === "recent") {
      filtered = filtered.slice(0, 4);
    }
    
    setFilteredResources(filtered);
  }, [activeTab, resources, userInterests]);
  
  const handleTogglePin = (id: string) => {
    setResources(prev => prev.map(resource => 
      resource.id === id 
        ? { ...resource, pinned: !resource.pinned }
        : resource
    ));
    
    const resource = resources.find(r => r.id === id);
    toast.success(
      resource?.pinned
        ? "Recurso desanclado"
        : "Recurso anclado para fácil acceso"
    );
  };
  
  const handleToggleSave = (id: string) => {
    setResources(prev => prev.map(resource => 
      resource.id === id 
        ? { ...resource, saved: !resource.saved }
        : resource
    ));
    
    const resource = resources.find(r => r.id === id);
    toast.success(
      resource?.saved
        ? "Recurso eliminado de guardados"
        : "Recurso guardado en tu biblioteca"
    );
  };
  
  const handleAddInterest = (topic: string) => {
    if (!userInterests.includes(topic)) {
      setUserInterests([...userInterests, topic]);
      
      toast.success("Interés añadido", {
        description: `Ahora recibirás recomendaciones sobre "${topic}"`
      });
      
      setSuggestedTopics(prev => prev.filter(t => t.name.toLowerCase() !== topic.toLowerCase()));
    }
  };
  
  const handleRemoveInterest = (topic: string) => {
    setUserInterests(userInterests.filter(interest => interest !== topic));
    
    toast.success("Interés eliminado", {
      description: `Ya no recibirás recomendaciones sobre "${topic}"`
    });
  };
  
  const getResourceIcon = (type: string) => {
    switch (type) {
      case "article":
        return <FileText className="h-5 w-5 text-blue-500" />;
      case "book":
        return <BookOpen className="h-5 w-5 text-purple-500" />;
      case "video":
        return <Video className="h-5 w-5 text-red-500" />;
      case "course":
        return <GraduationCap className="h-5 w-5 text-green-500" />;
      case "tool":
        return <Sparkles className="h-5 w-5 text-amber-500" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };
  
  const getResourceLabel = (type: string) => {
    switch (type) {
      case "article": return "Artículo";
      case "book": return "Libro";
      case "video": return "Video";
      case "course": return "Curso";
      case "tool": return "Herramienta";
      default: return type;
    }
  };
  
  const getSkillLevelBadge = (level: string) => {
    switch (level) {
      case "beginner":
        return <Badge variant="outline" className="bg-green-100 text-green-800">Principiante</Badge>;
      case "intermediate":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Intermedio</Badge>;
      case "advanced":
        return <Badge variant="outline" className="bg-purple-100 text-purple-800">Avanzado</Badge>;
      default:
        return null;
    }
  };
  
  const allTags = Array.from(new Set(resources.flatMap(resource => resource.tags)));
  
  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2">Sistema de Recomendaciones Académicas</h2>
        <p className="text-gray-600">
          Recursos personalizados para mejorar tus habilidades académicas y apoyar tus trabajos
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-3 space-y-6">
          <div className="bg-white rounded-lg shadow-sm p-4 border">
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar recursos académicos..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="flex flex-wrap gap-2 mb-2">
              {allTags.slice(0, 8).map(tag => (
                <Badge
                  key={tag}
                  variant={activeTag === tag ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => setActiveTag(activeTag === tag ? null : tag)}
                >
                  {tag}
                </Badge>
              ))}
              
              {activeTag && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-xs h-6 px-2" 
                  onClick={() => setActiveTag(null)}
                >
                  Limpiar filtro
                </Button>
              )}
            </div>
          </div>
          
          <Tabs defaultValue="recommended" value={activeTab} onValueChange={setActiveTab} className="bg-white rounded-lg shadow-sm border">
            <TabsList className="p-1 m-4 w-auto">
              <TabsTrigger value="recommended" className="rounded-md">
                <Lightbulb className="h-4 w-4 mr-2" />
                Recomendados
              </TabsTrigger>
              <TabsTrigger value="saved" className="rounded-md">
                <BookmarkCheck className="h-4 w-4 mr-2" />
                Guardados
              </TabsTrigger>
              <TabsTrigger value="recent" className="rounded-md">
                <Clock className="h-4 w-4 mr-2" />
                Recientes
              </TabsTrigger>
            </TabsList>
            
            <Separator />
            
            <TabsContent value="recommended" className="m-0 p-4">
              <div className="mb-4">
                <h3 className="font-medium text-gray-800 mb-2">Recomendados para ti</h3>
                <p className="text-sm text-gray-600">
                  Basado en tus intereses: {userInterests.map((interest, i) => (
                    <span key={i} className="font-medium">
                      {interest}{i < userInterests.length - 1 ? ', ' : ''}
                    </span>
                  ))}
                </p>
              </div>
              
              {filteredResources.length > 0 ? (
                <div className="grid grid-cols-1 gap-4">
                  {filteredResources.map((resource) => (
                    <ResourceCard 
                      key={resource.id}
                      resource={resource}
                      onTogglePin={() => handleTogglePin(resource.id)}
                      onToggleSave={() => handleToggleSave(resource.id)}
                      onTagClick={(tag) => setActiveTag(tag)}
                    />
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center">
                  <Book className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-800 mb-1">No se encontraron recursos</h3>
                  <p className="text-gray-500">
                    Intenta ampliar tus filtros o añadir nuevos intereses académicos
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="saved" className="m-0 p-4">
              {filteredResources.length > 0 ? (
                <div className="grid grid-cols-1 gap-4">
                  {filteredResources.map((resource) => (
                    <ResourceCard 
                      key={resource.id}
                      resource={resource}
                      onTogglePin={() => handleTogglePin(resource.id)}
                      onToggleSave={() => handleToggleSave(resource.id)}
                      onTagClick={(tag) => setActiveTag(tag)}
                    />
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center">
                  <Bookmark className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-800 mb-1">No tienes recursos guardados</h3>
                  <p className="text-gray-500">
                    Guarda recursos para acceder a ellos fácilmente más tarde
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="recent" className="m-0 p-4">
              {filteredResources.length > 0 ? (
                <div className="grid grid-cols-1 gap-4">
                  {filteredResources.map((resource) => (
                    <ResourceCard 
                      key={resource.id}
                      resource={resource}
                      onTogglePin={() => handleTogglePin(resource.id)}
                      onToggleSave={() => handleToggleSave(resource.id)}
                      onTagClick={(tag) => setActiveTag(tag)}
                    />
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center">
                  <Clock className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-800 mb-1">No hay recursos recientes</h3>
                  <p className="text-gray-500">
                    Los recursos que veas aparecerán aquí
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tus Intereses</CardTitle>
              <CardDescription>Temas académicos que te interesan</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2 mb-4">
                {userInterests.map((interest, index) => (
                  <div key={index} className="bg-blue-50 px-3 py-1 rounded-full text-sm flex items-center">
                    <span className="text-blue-700">{interest}</span>
                    <button
                      className="ml-2 text-blue-400 hover:text-blue-700"
                      onClick={() => handleRemoveInterest(interest)}
                    >
                      &times;
                    </button>
                  </div>
                ))}
              </div>
              
              <Separator className="my-4" />
              
              <div>
                <h4 className="text-sm font-medium mb-2">Temas sugeridos para ti</h4>
                <div className="space-y-2">
                  {suggestedTopics.map(topic => (
                    <div 
                      key={topic.id} 
                      className="flex items-center justify-between p-2 bg-gray-50 rounded-md hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleAddInterest(topic.name)}
                    >
                      <div className="flex items-center">
                        <Lightbulb className="h-4 w-4 text-amber-500 mr-2" />
                        <span className="text-sm">{topic.name}</span>
                      </div>
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Progreso Académico</CardTitle>
              <CardDescription>Tus habilidades y áreas de mejora</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {skillProgress.map(skill => (
                <div key={skill.id}>
                  <div className="flex justify-between items-center mb-1">
                    <div className="flex items-center">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <div className="ml-2">
                        {getSkillLevelBadge(skill.level)}
                      </div>
                    </div>
                    <span className="text-sm">{skill.progress}%</span>
                  </div>
                  <Progress value={skill.progress} className={`h-2 ${
                    skill.level === "beginner" ? "bg-green-500" :
                    skill.level === "intermediate" ? "bg-blue-500" : "bg-purple-500"
                  }`} />
                  <p className="text-xs text-gray-500 mt-1">
                    {skill.resources} recursos disponibles
                  </p>
                </div>
              ))}
              
              <Button variant="outline" className="w-full">
                <Trophy className="h-4 w-4 mr-2" />
                Ver plan de mejora
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Recursos Destacados</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <div className="flex items-start">
                  <div className="shrink-0 mr-3 mt-0.5">
                    <Star className="h-5 w-5 text-amber-500" />
                  </div>
                  <div>
                    <h4 className="font-medium text-amber-800 text-sm">Curso recomendado</h4>
                    <p className="text-xs text-amber-700 mb-1">
                      Técnicas avanzadas de redacción académica
                    </p>
                    <Button variant="outline" size="sm" className="w-full h-7 text-xs">
                      <ExternalLink className="h-3 w-3 mr-1" />
                      Ver curso
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <div className="flex items-start">
                  <div className="shrink-0 mr-3 mt-0.5">
                    <BookMarked className="h-5 w-5 text-blue-500" />
                  </div>
                  <div>
                    <h4 className="font-medium text-blue-800 text-sm">Colección</h4>
                    <p className="text-xs text-blue-700 mb-1">
                      Recursos esenciales para análisis literario
                    </p>
                    <Button variant="outline" size="sm" className="w-full h-7 text-xs">
                      <Library className="h-3 w-3 mr-1" />
                      Explorar colección
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

const ResourceCard = ({ 
  resource, 
  onTogglePin, 
  onToggleSave, 
  onTagClick 
}: { 
  resource: Resource, 
  onTogglePin: () => void, 
  onToggleSave: () => void,
  onTagClick: (tag: string) => void
}) => {
  const getResourceIcon = (type: string) => {
    switch (type) {
      case "article":
        return <FileText className="h-5 w-5 text-blue-500" />;
      case "book":
        return <BookOpen className="h-5 w-5 text-purple-500" />;
      case "video":
        return <Video className="h-5 w-5 text-red-500" />;
      case "course":
        return <GraduationCap className="h-5 w-5 text-green-500" />;
      case "tool":
        return <Sparkles className="h-5 w-5 text-amber-500" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };
  
  const getResourceLabel = (type: string) => {
    switch (type) {
      case "article": return "Artículo";
      case "book": return "Libro";
      case "video": return "Video";
      case "course": return "Curso";
      case "tool": return "Herramienta";
      default: return type;
    }
  };
  
  return (
    <div className={`rounded-lg border p-4 transition-all ${resource.pinned ? 'border-amber-300 bg-amber-50' : ''}`}>
      <div className="flex items-start justify-between">
        <div className="flex items-start">
          <div className="shrink-0 mr-3 mt-0.5">
            {getResourceIcon(resource.type)}
          </div>
          <div>
            <div className="flex items-center">
              <h3 className="font-medium text-gray-900">{resource.title}</h3>
              {resource.pinned && (
                <span className="ml-2 text-amber-500">
                  <Pin className="h-3 w-3" />
                </span>
              )}
            </div>
            <div className="flex items-center text-xs text-gray-500 mt-1">
              <Badge variant="secondary" className="rounded-sm text-xs mr-2">
                {getResourceLabel(resource.type)}
              </Badge>
              <span>{resource.source}</span>
            </div>
          </div>
        </div>
        <div className="flex space-x-1">
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-7 w-7 p-0"
            onClick={onTogglePin}
            title={resource.pinned ? "Desanclar" : "Anclar"}
          >
            {resource.pinned ? (
              <PinOff className="h-4 w-4 text-amber-500" />
            ) : (
              <Pin className="h-4 w-4" />
            )}
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-7 w-7 p-0"
            onClick={onToggleSave}
            title={resource.saved ? "Quitar de guardados" : "Guardar"}
          >
            {resource.saved ? (
              <BookmarkCheck className="h-4 w-4 text-blue-500" />
            ) : (
              <Bookmark className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
      
      <p className="text-sm text-gray-600 mt-2">
        {resource.description}
      </p>
      
      <div className="mt-3 flex flex-wrap gap-1">
        {resource.tags.map((tag, index) => (
          <Badge 
            key={index} 
            variant="outline" 
            className="text-xs cursor-pointer"
            onClick={() => onTagClick(tag)}
          >
            {tag}
          </Badge>
        ))}
      </div>
      
      <div className="mt-3 flex justify-between items-center">
        <div className="flex items-center text-xs text-gray-500">
          <div className="flex items-center">
            <Star className="h-3 w-3 text-amber-400 mr-1" />
            <span>Relevancia: {resource.relevance}%</span>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="h-7 text-xs">
            <Share2 className="h-3 w-3 mr-1" />
            Compartir
          </Button>
          <Button size="sm" className="h-7 text-xs" asChild>
            <a href={resource.url} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-3 w-3 mr-1" />
              Acceder
            </a>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RecommendationSystem;
