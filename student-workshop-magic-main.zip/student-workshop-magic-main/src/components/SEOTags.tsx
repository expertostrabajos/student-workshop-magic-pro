interface SEOTagsProps {
  seoKeywords: string[];
}

const SEOTags = ({ seoKeywords }: SEOTagsProps) => {
  // In a real implementation, you would use react-helmet-async:
  // 
  // import { Helmet } from "react-helmet-async";
  // 
  // return (
  //   <Helmet>
  //     <title>Ayuda con trabajos académicos en Colombia</title>
  //     <meta name="description" content="Servicio profesional de ayuda con trabajos académicos en Colombia" />
  //     <meta name="keywords" content={seoKeywords.join(", ")} />
  //   </Helmet>
  // );
  
  // For now, we'll keep the div with hidden content for SEO
  return (
    <div className="hidden">
      <h2>Ayuda con trabajos académicos en Colombia</h2>
      <p>{seoKeywords.join(", ")}</p>
    </div>
  );
};

export default SEOTags;
