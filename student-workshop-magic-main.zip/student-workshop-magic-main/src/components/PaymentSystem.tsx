
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useNavigate, useLocation } from "react-router-dom";
import { 
  Loader2, 
  CheckCircle, 
  CreditCard, 
  Lock, 
  ShieldCheck, 
  ArrowRight,
  CreditCard as CardIcon,
  Banknote,
  DollarSign,
  Upload,
  FileText,
  AlertTriangle
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const PaymentSystem = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"card" | "transfer" | null>(null);
  const [selectedPlan, setSelectedPlan] = useState({
    title: "Plan Premium",
    price: "199.000"
  });
  const [showReceiptUpload, setShowReceiptUpload] = useState(false);
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  // Check if a plan was selected from another component
  useEffect(() => {
    if (location.state?.plan) {
      setSelectedPlan(location.state.plan);
    }
  }, [location.state]);

  const handlePayment = async () => {
    if (!paymentMethod) {
      toast.error("Por favor seleccione un método de pago", {
        description: "Debe elegir un método de pago para continuar"
      });
      return;
    }
    
    if (paymentMethod === "transfer" && !receiptFile) {
      setShowReceiptUpload(true);
      return;
    }
    
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      
      if (paymentMethod === "card") {
        // Para tarjetas, simulamos pago inmediato
        setIsConfirmed(true);
        
        toast.success("¡Pago confirmado!", {
          description: "Tu pago ha sido procesado correctamente."
        });
        
        // Redirect to checkout after 2 seconds
        setTimeout(() => {
          navigate("/checkout", { 
            state: { 
              paymentSuccess: true,
              plan: selectedPlan,
              title: selectedPlan.title,
              price: selectedPlan.price,
              paymentMethod,
              paymentStatus: "verified" // Confirmado automáticamente para tarjetas
            } 
          });
        }, 2000);
      } else if (paymentMethod === "transfer") {
        // Para transferencias, pasa a estado pendiente de verificación
        toast.success("Comprobante recibido", {
          description: "Tu pago será verificado por un administrador en las próximas 24 horas."
        });
        
        // Redirect to checkout with pending status
        navigate("/checkout", { 
          state: { 
            paymentSuccess: true,
            plan: selectedPlan,
            title: selectedPlan.title,
            price: selectedPlan.price,
            paymentMethod,
            paymentStatus: "pending", // Pendiente de verificación
            receiptUploaded: true
          } 
        });
      }
    }, 1500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setReceiptFile(file);
      
      // Create preview for image files
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setReceiptPreview(event.target?.result as string);
        };
        reader.readAsDataURL(file);
      } else {
        setReceiptPreview(null);
      }
    }
  };

  const handleReceiptUploadSubmit = () => {
    if (!receiptFile) {
      toast.error("Por favor sube el comprobante de pago");
      return;
    }
    
    setShowReceiptUpload(false);
    handlePayment();
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white rounded-lg shadow-md p-6 border border-gray-200">
      <h3 className="text-xl font-bold text-gray-900 mb-4">Finalizar tu pedido</h3>
      
      {isConfirmed ? (
        <div className="flex flex-col items-center justify-center py-6">
          <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">¡Pago confirmado!</h4>
          <p className="text-gray-600 text-center mb-4">
            Estamos redireccionándote a la selección de trabajo...
          </p>
          <div className="animate-pulse">
            <div className="h-2 w-24 bg-green-300 rounded"></div>
          </div>
        </div>
      ) : (
        <>
          <div className="mb-6">
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">Plan:</span>
                <span className="font-medium">{selectedPlan.title}</span>
              </div>
              <div className="flex justify-between items-center mb-4">
                <span className="text-gray-600">Precio:</span>
                <span className="font-medium">${selectedPlan.price} COP</span>
              </div>
              <div className="border-t pt-3">
                <div className="flex justify-between text-lg font-bold">
                  <span>Total:</span>
                  <span>${selectedPlan.price} COP</span>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <h4 className="text-md font-semibold mb-3">Método de pago</h4>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => setPaymentMethod("card")}
                  className={`p-4 border rounded-lg flex flex-col items-center justify-center transition-all ${
                    paymentMethod === "card" 
                      ? "border-green-500 bg-green-50" 
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <CardIcon className={`h-6 w-6 mb-2 ${paymentMethod === "card" ? "text-green-500" : "text-gray-500"}`} />
                  <span className="text-sm font-medium">Tarjeta de Crédito</span>
                </button>
                
                <button 
                  onClick={() => setPaymentMethod("transfer")}
                  className={`p-4 border rounded-lg flex flex-col items-center justify-center transition-all ${
                    paymentMethod === "transfer" 
                      ? "border-green-500 bg-green-50" 
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <Banknote className={`h-6 w-6 mb-2 ${paymentMethod === "transfer" ? "text-green-500" : "text-gray-500"}`} />
                  <span className="text-sm font-medium">Transferencia Bancaria</span>
                </button>
              </div>
            </div>
            
            {paymentMethod === "card" && (
              <div className="mb-4 p-4 border border-gray-200 rounded-lg">
                <div className="mb-3">
                  <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700 mb-1">
                    Número de tarjeta
                  </label>
                  <input
                    type="text"
                    id="cardNumber"
                    placeholder="0000 0000 0000 0000"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="expiry" className="block text-sm font-medium text-gray-700 mb-1">
                      Fecha de expiración
                    </label>
                    <input
                      type="text"
                      id="expiry"
                      placeholder="MM/AA"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    />
                  </div>
                  <div>
                    <label htmlFor="cvv" className="block text-sm font-medium text-gray-700 mb-1">
                      CVV
                    </label>
                    <input
                      type="text"
                      id="cvv"
                      placeholder="123"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    />
                  </div>
                </div>
              </div>
            )}
            
            {paymentMethod === "transfer" && (
              <div className="mb-4 p-4 border border-gray-200 rounded-lg">
                <h5 className="font-medium mb-2 flex items-center">
                  <DollarSign className="h-4 w-4 mr-1 text-green-600" />
                  Datos bancarios
                </h5>
                <ul className="space-y-2 text-sm">
                  <li><strong>Banco:</strong> Bancolombia</li>
                  <li><strong>Cuenta:</strong> 123-456789-00</li>
                  <li><strong>Titular:</strong> Student Help S.A.S</li>
                  <li><strong>NIT:</strong> 900.123.456-7</li>
                </ul>
                <p className="mt-3 text-xs text-gray-500">
                  Por favor realiza la transferencia y sube el comprobante en el siguiente paso.
                </p>
                <div className="bg-yellow-50 border border-yellow-200 rounded p-3 mt-3">
                  <div className="flex items-start">
                    <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2 mt-0.5" />
                    <p className="text-xs text-yellow-800">
                      <strong>Importante:</strong> Los pagos por transferencia deberán ser verificados 
                      por un administrador antes de iniciar el trabajo. Este proceso puede tardar hasta 24 horas hábiles.
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="flex items-center text-sm text-gray-600 mb-4">
              <ShieldCheck className="h-4 w-4 text-green-600 mr-2" />
              <span>Pago seguro con encriptación SSL</span>
            </div>
            
            <div className="flex flex-wrap justify-center gap-3 mb-4">
              <CreditCard className="h-6 w-6 text-gray-400" />
              <Lock className="h-6 w-6 text-gray-400" />
            </div>
          </div>
          
          <Button
            onClick={handlePayment}
            disabled={isProcessing || !paymentMethod}
            className={`w-full py-2 px-4 rounded-lg transition-colors duration-300 ${
              !paymentMethod 
                ? "bg-gray-300 text-gray-600" 
                : "bg-green-600 hover:bg-green-700 text-white"
            }`}
          >
            {isProcessing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Procesando...
              </>
            ) : (
              <>
                {paymentMethod === "transfer" ? "Continuar con el pago" : "Pagar ahora"}
                <ArrowRight className="ml-2 h-4 w-4" />
              </>
            )}
          </Button>
        </>
      )}

      {/* Dialog para subir comprobante de transferencia */}
      <Dialog open={showReceiptUpload} onOpenChange={setShowReceiptUpload}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Subir comprobante de pago</DialogTitle>
            <DialogDescription>
              Por favor sube una captura o documento PDF de tu comprobante de transferencia
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <input
                type="file"
                id="receipt"
                className="hidden"
                accept="image/*,.pdf"
                onChange={handleFileChange}
              />
              
              {receiptPreview ? (
                <div className="mb-3">
                  <img 
                    src={receiptPreview} 
                    alt="Vista previa del comprobante" 
                    className="max-h-40 max-w-full mx-auto rounded-lg" 
                  />
                  <p className="text-sm text-gray-500 mt-2">
                    {receiptFile?.name} ({(receiptFile?.size || 0) / 1024 < 1000 
                      ? `${Math.round((receiptFile?.size || 0) / 1024)} KB` 
                      : `${Math.round((receiptFile?.size || 0) / 1024 / 1024 * 10) / 10} MB`})
                  </p>
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <Upload className="h-10 w-10 text-gray-400 mb-2" />
                  <p className="text-sm text-gray-600 mb-2">
                    Arrastra y suelta o haz clic para seleccionar
                  </p>
                  <p className="text-xs text-gray-500">
                    Formatos aceptados: PNG, JPG, PDF (Máx. 5MB)
                  </p>
                </div>
              )}
              
              <Button 
                variant="outline" 
                className="mt-3"
                onClick={() => document.getElementById('receipt')?.click()}
              >
                {receiptFile ? "Cambiar archivo" : "Seleccionar archivo"}
              </Button>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReceiptUpload(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleReceiptUploadSubmit}
              disabled={!receiptFile}
            >
              <FileText className="h-4 w-4 mr-2" />
              Subir y continuar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PaymentSystem;
