
import { motion } from "framer-motion";
import { ChevronDown, BookOpen, Shield, Globe } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import heroIllustration from "@/assets/hero-illustration.png";

interface HeroSectionProps {
  isVisible?: boolean;
}

const HeroSection = ({ isVisible = false }: HeroSectionProps) => {
  const { currentLanguage, isTranslating } = useLanguage();

  return (
    <section id="inicio" className="relative pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden">
      {/* Gradient background decoration */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-accent/10 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text content */}
          <div className="text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={isVisible ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-1.5 rounded-full text-sm font-medium mb-6"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
              </span>
              Ayuda académica profesional en Colombia
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, ease: "easeOut" }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight"
            >
              Expertos en Trabajos{" "}
              <span className="text-primary">Académicos</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.15, ease: "easeOut" }}
              className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto lg:mx-0"
            >
              Obtén ayuda profesional para tus trabajos académicos. Calidad garantizada y entregas puntuales.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.3, ease: "easeOut" }}
              className="flex flex-wrap justify-center lg:justify-start items-center gap-4 mb-8"
            >
              <motion.a
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                href="#solicitar"
                className="w-full sm:w-auto inline-flex items-center justify-center bg-primary text-primary-foreground px-8 py-3.5 rounded-xl font-medium transition-shadow duration-300 hover:shadow-lg hover:shadow-primary/25"
              >
                <BookOpen className="mr-2 h-5 w-5" />
                Solicitar Trabajo
              </motion.a>
              <motion.a
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                href="#garantias"
                className="w-full sm:w-auto inline-flex items-center justify-center bg-secondary text-secondary-foreground border border-border px-8 py-3.5 rounded-xl font-medium transition-shadow duration-300 hover:shadow-md"
              >
                <Shield className="mr-2 h-5 w-5" />
                Nuestras Garantías
              </motion.a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={isVisible ? { opacity: 1 } : {}}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="inline-flex items-center justify-center bg-muted text-muted-foreground px-4 py-2 rounded-full text-sm"
            >
              <Globe className="mr-2 h-4 w-4 text-primary" />
              <span className="notranslate">
                {isTranslating
                  ? "Traduciendo..."
                  : currentLanguage === "es"
                    ? "Disponible en múltiples idiomas"
                    : "Available in multiple languages"}
              </span>
              <span className="ml-1 px-1.5 py-0.5 bg-primary/10 text-primary text-xs rounded-full notranslate">20+</span>
              {isTranslating && (
                <div className="ml-2 h-3 w-3 animate-spin rounded-full border-2 border-current border-t-transparent" />
              )}
            </motion.div>
          </div>

          {/* Hero illustration */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, x: 40 }}
            animate={isVisible ? { opacity: 1, scale: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="hidden lg:flex justify-center items-center"
          >
            <img
              src={heroIllustration}
              alt="Ilustración de servicios académicos profesionales"
              className="w-full max-w-lg drop-shadow-2xl"
              loading="eager"
            />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isVisible ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="mt-10 animate-bounce text-center hidden md:block"
        >
          <a href="#servicios" className="inline-block text-muted-foreground hover:text-primary transition-colors">
            <ChevronDown className="h-8 w-8" />
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
