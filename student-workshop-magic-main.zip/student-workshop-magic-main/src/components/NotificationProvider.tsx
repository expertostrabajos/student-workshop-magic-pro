
import React, { createContext, useContext, ReactNode, useMemo, useCallback } from 'react';
import { toast } from "sonner";
import { Notification, useNotifications } from '@/hooks/useNotifications';

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  addNotification: (notification: Omit<Notification, 'id' | 'date' | 'isRead'>) => string;
  removeNotification: (id: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotificationContext = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotificationContext must be used within a NotificationProvider');
  }
  return context;
};

interface NotificationProviderProps {
  children: ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children }) => {
  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    addNotification,
    removeNotification
  } = useNotifications();

  // Memoize notification toast function
  const showNotificationToast = useCallback((notification: Omit<Notification, 'id' | 'date' | 'isRead'>) => {
    const id = addNotification(notification);
    
    toast(notification.title, {
      description: notification.message,
      action: {
        label: "Ver",
        onClick: () => markAsRead(id)
      },
    });
    
    return id;
  }, [addNotification, markAsRead]);

  // Memoize context value
  const contextValue = useMemo(() => ({
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    addNotification: showNotificationToast,
    removeNotification
  }), [
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    showNotificationToast,
    removeNotification
  ]);

  return (
    <NotificationContext.Provider value={contextValue}>
      {children}
    </NotificationContext.Provider>
  );
};
