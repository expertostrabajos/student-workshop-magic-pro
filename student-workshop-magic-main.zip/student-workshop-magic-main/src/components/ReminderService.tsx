
import { useEffect, useState } from 'react';
import { checkReminders } from '@/utils/reminderUtils';
import { toast } from "sonner";

const ReminderService = () => {
  const [lastCheck, setLastCheck] = useState<Date | null>(null);

  useEffect(() => {
    // Check reminders immediately on mount
    const remindersSent = checkReminders();
    if (remindersSent > 0) {
      toast.info(`Se enviaron ${remindersSent} recordatorio(s) de trabajos pendientes`);
    }
    
    // Set up interval to check reminders every hour
    // In a real app, this would be handled by a server-side scheduler
    const intervalId = setInterval(() => {
      const sent = checkReminders();
      if (sent > 0) {
        toast.info(`Se enviaron ${sent} recordatorio(s) de trabajos pendientes`);
      }
      setLastCheck(new Date());
    }, 60 * 60 * 1000); // Every hour
    
    return () => clearInterval(intervalId);
  }, []);
  
  // This component doesn't render anything visible
  return null;
};

export default ReminderService;
