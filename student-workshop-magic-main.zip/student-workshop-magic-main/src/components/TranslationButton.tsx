
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Globe } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuGroup,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { useLanguage } from "@/contexts/LanguageContext";

// Language list with popular and common languages
const POPULAR_LANGUAGES = [
  { code: "es", name: "Español" },
  { code: "en", name: "English" },
  { code: "pt", name: "Português" },
  { code: "fr", name: "Français" },
  { code: "de", name: "Deutsch" },
];

const OTHER_LANGUAGES = [
  { code: "ar", name: "العربية" },
  { code: "bn", name: "বাংলা" },
  { code: "zh-CN", name: "简体中文" },
  { code: "hi", name: "हिन्दी" },
  { code: "ja", name: "日本語" },
  { code: "ko", name: "한국어" },
  { code: "ru", name: "Русский" },
  { code: "it", name: "Italiano" },
  { code: "nl", name: "Nederlands" },
  { code: "tr", name: "Türkçe" },
  { code: "pl", name: "Polski" },
  { code: "th", name: "ไทย" },
  { code: "vi", name: "Tiếng Việt" },
  { code: "id", name: "Bahasa Indonesia" },
  { code: "uk", name: "Українська" },
];

const TranslationButton = () => {
  const { currentLanguage, setLanguage, isTranslating } = useLanguage();
  const [showAllLanguages, setShowAllLanguages] = useState(false);

  const changeLang = (langCode: string) => {
    if (langCode === currentLanguage) return;
    
    toast.info(`Cambiando a ${getLangName(langCode)}...`, {
      description: "Esto puede tomar unos segundos",
    });
    
    setLanguage(langCode);
  };

  // Find language name by code
  const getLangName = (code: string) => {
    const allLanguages = [...POPULAR_LANGUAGES, ...OTHER_LANGUAGES];
    const lang = allLanguages.find(l => l.code === code);
    return lang ? lang.name : "Idioma";
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2" disabled={isTranslating}>
          <Globe className="h-4 w-4" />
          <span className="hidden sm:inline-block">
            {isTranslating ? "Traduciendo..." : getLangName(currentLanguage)}
          </span>
          {isTranslating && (
            <div className="ml-2 h-3 w-3 animate-spin rounded-full border-2 border-current border-t-transparent" />
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel>Idiomas populares</DropdownMenuLabel>
        <DropdownMenuGroup>
          {POPULAR_LANGUAGES.map((lang) => (
            <DropdownMenuItem 
              key={lang.code}
              onClick={() => changeLang(lang.code)}
              className={currentLanguage === lang.code ? "bg-muted" : ""}
              disabled={isTranslating}
            >
              {lang.name}
              {currentLanguage === lang.code && <span className="ml-auto">✓</span>}
            </DropdownMenuItem>
          ))}
        </DropdownMenuGroup>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuLabel>Más idiomas</DropdownMenuLabel>
        <DropdownMenuGroup className={showAllLanguages ? "" : "max-h-40 overflow-y-auto"}>
          {(showAllLanguages ? OTHER_LANGUAGES : OTHER_LANGUAGES.slice(0, 5)).map((lang) => (
            <DropdownMenuItem 
              key={lang.code}
              onClick={() => changeLang(lang.code)}
              className={currentLanguage === lang.code ? "bg-muted" : ""}
              disabled={isTranslating}
            >
              {lang.name}
              {currentLanguage === lang.code && <span className="ml-auto">✓</span>}
            </DropdownMenuItem>
          ))}
        </DropdownMenuGroup>
        
        {!showAllLanguages && OTHER_LANGUAGES.length > 5 && (
          <DropdownMenuItem 
            onClick={() => setShowAllLanguages(true)}
            disabled={isTranslating}
          >
            Ver todos los idiomas
          </DropdownMenuItem>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default TranslationButton;
