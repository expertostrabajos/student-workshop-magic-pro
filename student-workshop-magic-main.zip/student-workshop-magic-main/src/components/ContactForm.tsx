
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Loader2, Send, Phone, User, Mail, FileText, MapPin, Check } from "lucide-react";

const ContactForm = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "", email: "", subject: "", message: "", phone: "",
  });
  const [touched, setTouched] = useState({
    name: false, email: false, subject: false, message: false, phone: false,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setIsSuccess(false);
    try {
      const response = await fetch("https://formspree.io/f/xqaevrbg", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      if (response.ok) {
        setIsSuccess(true);
        toast({ title: "Mensaje enviado", description: "Nos pondremos en contacto contigo pronto." });
        setFormData({ name: "", email: "", subject: "", message: "", phone: "" });
        setTouched({ name: false, email: false, subject: false, message: false, phone: false });
        setTimeout(() => setIsSuccess(false), 3000);
      } else {
        toast({ title: "Error", description: "Hubo un problema al enviar el mensaje.", variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", description: "Hubo un problema al enviar el mensaje.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setTouched({ ...touched, [e.target.name]: true });
  };
  const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const getInputClasses = (fieldName: keyof typeof formData, isRequired = true) => {
    const base = "w-full transition-all duration-300 focus:ring-2 focus:ring-ring focus:border-transparent outline-none";
    if (!touched[fieldName]) return `${base} border border-input rounded-lg`;
    if (isRequired && !formData[fieldName]) return `${base} border-2 border-destructive rounded-lg bg-destructive/5`;
    if (fieldName === "email" && formData.email && !isValidEmail(formData.email)) return `${base} border-2 border-destructive rounded-lg bg-destructive/5`;
    return `${base} border border-primary rounded-lg`;
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-lg mx-auto space-y-6 bg-card p-6 rounded-lg shadow-md transition-all duration-300 hover:shadow-lg border border-border">
      <h2 className="text-2xl font-bold text-center text-foreground mb-6">Contáctanos</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-1">
          <label htmlFor="name" className="block text-sm font-medium text-foreground flex items-center gap-1">
            <User className="h-4 w-4 text-primary" /><span>Nombre</span><span className="text-destructive">*</span>
          </label>
          <div className="relative">
            <Input type="text" id="name" name="name" value={formData.name} onChange={handleChange} onBlur={handleBlur} required className={getInputClasses("name")} placeholder="Tu nombre" />
            {touched.name && formData.name && <Check className="absolute right-3 top-3 h-4 w-4 text-primary" />}
          </div>
          {touched.name && !formData.name && <p className="text-xs text-destructive mt-1">Este campo es obligatorio</p>}
        </div>
        
        <div className="space-y-1">
          <label htmlFor="email" className="block text-sm font-medium text-foreground flex items-center gap-1">
            <Mail className="h-4 w-4 text-primary" /><span>Email</span><span className="text-destructive">*</span>
          </label>
          <div className="relative">
            <Input type="email" id="email" name="email" value={formData.email} onChange={handleChange} onBlur={handleBlur} required className={getInputClasses("email")} placeholder="tu@email.com" />
            {touched.email && formData.email && isValidEmail(formData.email) && <Check className="absolute right-3 top-3 h-4 w-4 text-primary" />}
          </div>
          {touched.email && formData.email && !isValidEmail(formData.email) && <p className="text-xs text-destructive mt-1">Email inválido</p>}
          {touched.email && !formData.email && <p className="text-xs text-destructive mt-1">Este campo es obligatorio</p>}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-1">
          <label htmlFor="subject" className="block text-sm font-medium text-foreground flex items-center gap-1">
            <FileText className="h-4 w-4 text-primary" /><span>Asunto</span><span className="text-destructive">*</span>
          </label>
          <div className="relative">
            <Input type="text" id="subject" name="subject" value={formData.subject} onChange={handleChange} onBlur={handleBlur} required className={getInputClasses("subject")} placeholder="Asunto del mensaje" />
            {touched.subject && formData.subject && <Check className="absolute right-3 top-3 h-4 w-4 text-primary" />}
          </div>
          {touched.subject && !formData.subject && <p className="text-xs text-destructive mt-1">Este campo es obligatorio</p>}
        </div>
        
        <div className="space-y-1">
          <label htmlFor="phone" className="block text-sm font-medium text-foreground flex items-center gap-1">
            <Phone className="h-4 w-4 text-primary" /><span>Teléfono</span>
          </label>
          <div className="relative">
            <Input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange} onBlur={handleBlur} className={getInputClasses("phone", false)} placeholder="+57 000 000 0000" />
            {touched.phone && formData.phone && <Check className="absolute right-3 top-3 h-4 w-4 text-primary" />}
          </div>
        </div>
      </div>

      <div className="space-y-1">
        <label htmlFor="message" className="block text-sm font-medium text-foreground flex items-center gap-1">
          <FileText className="h-4 w-4 text-primary" /><span>Mensaje</span><span className="text-destructive">*</span>
        </label>
        <Textarea id="message" name="message" value={formData.message} onChange={handleChange} onBlur={handleBlur} required rows={4} className={getInputClasses("message")} placeholder="¿En qué podemos ayudarte?" />
        {touched.message && !formData.message && <p className="text-xs text-destructive mt-1">Este campo es obligatorio</p>}
      </div>

      <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-sm">
        <div className="w-full md:w-auto bg-muted p-3 rounded-lg flex items-center gap-3 border border-border">
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-primary" />
            <p className="text-muted-foreground">WhatsApp:</p>
          </div>
          <a href="https://wa.me/573142135852" className="font-medium text-primary hover:opacity-80 transition-colors">+57 3142135852</a>
        </div>
        <div className="w-full md:w-auto bg-muted p-3 rounded-lg flex items-center gap-3 border border-border">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-primary" />
            <p className="text-muted-foreground">Ubicación:</p>
          </div>
          <a href="https://maps.google.com/?q=Bogotá,Colombia" target="_blank" rel="noopener noreferrer" className="font-medium text-primary hover:opacity-80 transition-colors">Bogotá, Colombia</a>
        </div>
      </div>

      <Button type="submit" disabled={isSubmitting} className="w-full">
        {isSubmitting ? (
          <><Loader2 className="mr-2 h-5 w-5 animate-spin" />Enviando...</>
        ) : isSuccess ? (
          <><Check className="mr-2 h-5 w-5" />¡Mensaje Enviado!</>
        ) : (
          <><Send className="mr-2 h-5 w-5" />Enviar Mensaje</>
        )}
      </Button>
      
      <div className="text-center text-xs text-muted-foreground">
        <p>Los campos marcados con <span className="text-destructive">*</span> son obligatorios</p>
      </div>
    </form>
  );
};

export default ContactForm;
