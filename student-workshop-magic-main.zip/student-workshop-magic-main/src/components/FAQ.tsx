
import { useState } from "react";
import { ChevronDown, ChevronUp, HelpCircle } from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

const faqItems: FAQItem[] = [
  {
    question: "¿Cuánto tiempo tarda en entregarse un trabajo?",
    answer: "El tiempo de entrega depende del tipo y la complejidad del trabajo. Para ensayos cortos, podemos entregarlos en 3-5 días. Para trabajos más extensos como tesis o investigaciones, el plazo puede ser de 1-2 semanas. Siempre establecemos plazos realistas y nos aseguramos de cumplirlos. Si necesitas un trabajo urgente, contamos con servicio express con un costo adicional.",
    category: "Plazos"
  },
  {
    question: "¿Es confidencial mi información?",
    answer: "Absolutamente. Tratamos toda la información de nuestros clientes con la más estricta confidencialidad. Nunca compartimos tus datos personales, detalles del trabajo o cualquier otra información con terceros. Además, todos nuestros colaboradores firman acuerdos de confidencialidad.",
    category: "Privacidad"
  },
  {
    question: "¿Qué formatos de archivo aceptan?",
    answer: "Aceptamos una amplia variedad de formatos: PDF, Word (.doc, .docx), PowerPoint (.ppt, .pptx), Excel (.xls, .xlsx), imágenes (.jpg, .png), archivos de texto (.txt) y más. Si tienes algún otro formato específico, contáctanos y haremos lo posible por acomodarlo.",
    category: "Técnico"
  },
  {
    question: "¿Cómo garantizan la originalidad del trabajo?",
    answer: "Todos nuestros trabajos son 100% originales y escritos desde cero. Utilizamos herramientas profesionales de detección de plagio para asegurarnos de que el contenido sea único. Además, nuestro sistema de control de calidad revisa cada trabajo antes de ser entregado para garantizar su originalidad.",
    category: "Calidad"
  },
  {
    question: "¿Puedo solicitar correcciones después de recibir el trabajo?",
    answer: "Sí, ofrecemos revisiones gratuitas dentro de los 7 días posteriores a la entrega. Si necesitas ajustes o modificaciones, simplemente envíanos tus comentarios y realizaremos los cambios necesarios hasta que estés completamente satisfecho con el resultado.",
    category: "Servicio"
  },
  {
    question: "¿Qué métodos de pago aceptan?",
    answer: "Aceptamos transferencias bancarias, pagos con tarjeta de crédito/débito a través de pasarelas seguras, y diversos medios de pago electrónicos populares en Colombia. Todos los pagos se procesan de manera segura y confidencial.",
    category: "Pagos"
  },
  {
    question: "¿Cómo se determina el precio de un trabajo?",
    answer: "El precio se calcula en base a varios factores: tipo de trabajo, nivel académico, extensión (número de palabras o páginas), plazo de entrega y complejidad del tema. Siempre proporcionamos un presupuesto detallado antes de comenzar y no hay costos ocultos.",
    category: "Pagos"
  },
  {
    question: "¿Son expertos en mi área de estudio?",
    answer: "Contamos con un equipo diverso de profesionales y académicos especializados en distintas disciplinas, desde humanidades hasta ciencias exactas. Asignamos cada trabajo a un experto en el área específica para garantizar un resultado de alta calidad y precisión académica.",
    category: "Calidad"
  }
];

const FAQ = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const categories = Array.from(new Set(faqItems.map(item => item.category)));

  const filteredFAQs = activeCategory 
    ? faqItems.filter(item => item.category === activeCategory) 
    : faqItems;

  return (
    <section className="py-12 md:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Preguntas Frecuentes</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Encuentra respuestas a las preguntas más comunes sobre nuestros servicios académicos.
          </p>
        </div>

        <div className="flex flex-wrap justify-center mb-8">
          <button
            onClick={() => setActiveCategory(null)}
            className={`m-1 px-4 py-2 text-sm font-medium rounded-full ${
              activeCategory === null
                ? "bg-green-500 text-white"
                : "bg-gray-100 text-gray-800 hover:bg-gray-200"
            }`}
          >
            Todas
          </button>
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`m-1 px-4 py-2 text-sm font-medium rounded-full ${
                activeCategory === category
                  ? "bg-green-500 text-white"
                  : "bg-gray-100 text-gray-800 hover:bg-gray-200"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="max-w-3xl mx-auto divide-y divide-gray-200 rounded-lg shadow-sm overflow-hidden">
          {filteredFAQs.map((item, index) => (
            <div key={index} className="bg-white">
              <button
                onClick={() => setActiveIndex(activeIndex === index ? null : index)}
                className="w-full px-6 py-4 text-left focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <HelpCircle className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-gray-900 font-medium">{item.question}</span>
                  </div>
                  {activeIndex === index ? (
                    <ChevronUp className="w-5 h-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-500" />
                  )}
                </div>
              </button>
              {activeIndex === index && (
                <div className="px-6 pb-4">
                  <div className="text-gray-600">
                    <div className="pl-7">{item.answer}</div>
                    <div className="mt-2 pl-7">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                        {item.category}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <p className="text-gray-600 mb-4">
            ¿No encuentras la respuesta que buscas?
          </p>
          <a
            href="#contacto"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700"
          >
            Contáctanos
          </a>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
