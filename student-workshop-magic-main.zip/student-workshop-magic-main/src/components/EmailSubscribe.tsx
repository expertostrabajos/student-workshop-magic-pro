
import { useState } from "react";
import { toast } from "sonner";
import { Send } from "lucide-react";

const EmailSubscribe = () => {
  const [emailSubscribe, setEmailSubscribe] = useState("");
  const [isSubscribing, setIsSubscribing] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (emailSubscribe.trim() && /^\S+@\S+\.\S+$/.test(emailSubscribe)) {
      setIsSubscribing(true);
      
      try {
        // This would be a real API call in production
        // Simulating API call for now
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // In a real implementation, you'd do something like:
        // const response = await fetch("/api/subscribe", {
        //   method: "POST",
        //   headers: { "Content-Type": "application/json" },
        //   body: JSON.stringify({ email: emailSubscribe }),
        // });
        
        // if (response.ok) {
        toast.success("¡Te has suscrito correctamente! Recibirás nuestras actualizaciones y consejos académicos.", {
          description: "Te hemos enviado un correo de confirmación."
        });
        setEmailSubscribe("");
        // } else {
        //   throw new Error("Error en la respuesta del servidor");
        // }
      } catch (error) {
        console.error("Error during subscription:", error);
        toast.error("Ha ocurrido un error al procesar tu suscripción. Por favor, intenta de nuevo.");
      } finally {
        setIsSubscribing(false);
      }
    } else {
      toast.error("Por favor, introduce un email válido");
    }
  };

  return (
    <div className="bg-green-50 p-6 rounded-lg">
      <h3 className="text-xl font-semibold mb-3 text-center">¿Quieres recibir consejos académicos?</h3>
      <p className="text-gray-600 mb-4 text-center">Suscríbete a nuestro boletín y recibe consejos para mejorar tus trabajos.</p>
      
      <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2">
        <input
          type="email"
          placeholder="Tu correo electrónico"
          value={emailSubscribe}
          onChange={(e) => setEmailSubscribe(e.target.value)}
          className="flex-grow px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
          required
        />
        <button
          type="submit"
          disabled={isSubscribing}
          className={`px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors flex items-center justify-center ${
            isSubscribing ? "opacity-70 cursor-not-allowed" : ""
          }`}
        >
          {isSubscribing ? (
            "Suscribiendo..."
          ) : (
            <>
              Suscribirse <Send className="w-4 h-4 ml-2" />
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default EmailSubscribe;
