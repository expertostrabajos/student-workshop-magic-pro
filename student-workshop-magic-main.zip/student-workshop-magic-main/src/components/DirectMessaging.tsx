import React, { useState, useEffect, useRef } from "react";
import { 
  Send, 
  Paperclip, 
  Smile, 
  ChevronDown, 
  User, 
  Clock, 
  CheckCheck, 
  Bookmark,
  MoreVertical,
  Search,
  Phone,
  Video,
  Info,
  Download
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardFooter,
  CardHeader
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

interface User {
  id: string;
  name: string;
  role: "writer" | "student";
  avatar?: string;
  status: "online" | "offline" | "busy";
  lastSeen?: string;
}

interface Message {
  id: string;
  sender: string;
  receiver: string;
  text: string;
  timestamp: Date;
  read: boolean;
  attachments?: { name: string; url: string; type: string }[];
}

interface Conversation {
  id: string;
  participants: string[];
  lastMessage?: Message;
  unreadCount: number;
}

const DirectMessaging = () => {
  const [contacts, setContacts] = useState<User[]>([
    {
      id: "w1",
      name: "Ana María González",
      role: "writer",
      avatar: "https://i.pravatar.cc/150?img=1",
      status: "online"
    },
    {
      id: "w2",
      name: "Carlos Martínez",
      role: "writer",
      avatar: "https://i.pravatar.cc/150?img=2",
      status: "busy"
    },
    {
      id: "w3",
      name: "Laura Rodríguez",
      role: "writer",
      avatar: "https://i.pravatar.cc/150?img=3",
      status: "offline",
      lastSeen: "Hace 2 horas"
    },
    {
      id: "s1",
      name: "Juan Pérez",
      role: "student",
      avatar: "https://i.pravatar.cc/150?img=4",
      status: "online"
    }
  ]);
  
  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: "conv1",
      participants: ["current_user", "w1"],
      unreadCount: 0
    },
    {
      id: "conv2",
      participants: ["current_user", "w2"],
      unreadCount: 2
    },
    {
      id: "conv3",
      participants: ["current_user", "w3"],
      unreadCount: 0
    }
  ]);
  
  const [messages, setMessages] = useState<{ [key: string]: Message[] }>({
    "conv1": [
      {
        id: "msg1",
        sender: "w1",
        receiver: "current_user",
        text: "Hola, he revisado tu trabajo sobre el análisis literario. Tengo algunas sugerencias que podrían mejorar tu enfoque.",
        timestamp: new Date(Date.now() - 3600000 * 3),
        read: true
      },
      {
        id: "msg2",
        sender: "current_user",
        receiver: "w1",
        text: "Perfecto, me encantaría escuchar tus sugerencias. ¿Cuáles son los puntos principales que debería revisar?",
        timestamp: new Date(Date.now() - 3600000 * 2),
        read: true
      },
      {
        id: "msg3",
        sender: "w1",
        receiver: "current_user",
        text: "En primer lugar, recomendaría profundizar más en el análisis del contexto histórico. Además, la sección de metodología podría beneficiarse de una estructura más clara.",
        timestamp: new Date(Date.now() - 3600000),
        read: true
      }
    ],
    "conv2": [
      {
        id: "msg4",
        sender: "w2",
        receiver: "current_user",
        text: "Te envío el primer borrador de tu ensayo. Por favor, revísalo y dime si necesitas algún cambio.",
        timestamp: new Date(Date.now() - 86400000),
        read: true,
        attachments: [
          {
            name: "Ensayo_Borrador.docx",
            url: "#",
            type: "document"
          }
        ]
      },
      {
        id: "msg5",
        sender: "w2",
        receiver: "current_user",
        text: "También adjunto algunas referencias adicionales que podrían serte útiles.",
        timestamp: new Date(Date.now() - 43200000),
        read: false,
        attachments: [
          {
            name: "Referencias_Adicionales.pdf",
            url: "#",
            type: "document"
          }
        ]
      },
      {
        id: "msg6",
        sender: "w2",
        receiver: "current_user",
        text: "¿Has tenido oportunidad de revisar el material? Necesitaría tu feedback para continuar con la versión final.",
        timestamp: new Date(Date.now() - 3600000),
        read: false
      }
    ],
    "conv3": [
      {
        id: "msg7",
        sender: "current_user",
        receiver: "w3",
        text: "Hola Laura, tengo interés en contratar tus servicios para un proyecto de investigación en psicología. ¿Podrías darme más información sobre tu experiencia en este campo?",
        timestamp: new Date(Date.now() - 259200000),
        read: true
      },
      {
        id: "msg8",
        sender: "w3",
        receiver: "current_user",
        text: "¡Hola! Claro, tengo un doctorado en Psicología Clínica y he trabajado en más de 50 proyectos de investigación en esta área. Me especializo en metodología cualitativa y análisis de datos. Puedo enviarte mi portafolio si te interesa.",
        timestamp: new Date(Date.now() - 172800000),
        read: true
      }
    ]
  });
  
  const [activeConversation, setActiveConversation] = useState<string>("conv1");
  const [newMessage, setNewMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    scrollToBottom();
  }, [activeConversation, messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  const handleSendMessage = () => {
    if (newMessage.trim() === "") return;
    
    const newMsg: Message = {
      id: `msg_${Date.now()}`,
      sender: "current_user",
      receiver: getOtherParticipant(activeConversation),
      text: newMessage,
      timestamp: new Date(),
      read: false
    };
    
    setMessages(prev => ({
      ...prev,
      [activeConversation]: [...(prev[activeConversation] || []), newMsg]
    }));
    
    setNewMessage("");
    
    // Simular respuesta después de 3 segundos
    setTimeout(() => {
      const autoReply: Message = {
        id: `msg_${Date.now() + 1}`,
        sender: getOtherParticipant(activeConversation),
        receiver: "current_user",
        text: "Gracias por tu mensaje. Te responderé detalladamente en breve.",
        timestamp: new Date(),
        read: false
      };
      
      setMessages(prev => ({
        ...prev,
        [activeConversation]: [...(prev[activeConversation] || []), autoReply]
      }));
      
      toast.success("Nuevo mensaje recibido");
    }, 3000);
  };
  
  const getOtherParticipant = (conversationId: string) => {
    const conversation = conversations.find(c => c.id === conversationId);
    if (!conversation) return "";
    return conversation.participants.find(p => p !== "current_user") || "";
  };
  
  const getContact = (userId: string) => {
    return contacts.find(c => c.id === userId);
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "online": return "bg-green-500";
      case "busy": return "bg-yellow-500";
      case "offline": return "bg-gray-400";
      default: return "bg-gray-400";
    }
  };
  
  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('es', { 
      hour: '2-digit', 
      minute: '2-digit' 
    }).format(date);
  };
  
  const filteredContacts = contacts.filter(contact => 
    contact.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-[calc(100vh-10rem)] max-h-[800px] bg-white border rounded-lg shadow-sm overflow-hidden">
      <div className="grid grid-cols-1 md:grid-cols-3 h-full">
        {/* Sidebar - Contacts and Conversations */}
        <div className="border-r">
          <div className="p-3 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar conversaciones..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          <Tabs defaultValue="chats" className="w-full">
            <TabsList className="w-full grid grid-cols-2">
              <TabsTrigger value="chats">Chats</TabsTrigger>
              <TabsTrigger value="contacts">Contactos</TabsTrigger>
            </TabsList>
            
            <TabsContent value="chats" className="p-0 m-0">
              <div className="overflow-auto h-[calc(100vh-14rem)]">
                {conversations.map(conversation => {
                  const otherUserId = getOtherParticipant(conversation.id);
                  const otherUser = getContact(otherUserId);
                  const lastMsg = messages[conversation.id]?.[messages[conversation.id]?.length - 1];
                  
                  if (!otherUser) return null;
                  
                  return (
                    <div
                      key={conversation.id}
                      className={`flex items-center gap-3 p-3 hover:bg-gray-100 cursor-pointer ${
                        activeConversation === conversation.id ? "bg-gray-100" : ""
                      }`}
                      onClick={() => setActiveConversation(conversation.id)}
                    >
                      <div className="relative">
                        <Avatar>
                          <AvatarImage src={otherUser.avatar} alt={otherUser.name} />
                          <AvatarFallback>{otherUser.name.substring(0, 2)}</AvatarFallback>
                        </Avatar>
                        <span 
                          className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                            getStatusColor(otherUser.status)
                          }`}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <h3 className="font-medium text-sm truncate">{otherUser.name}</h3>
                          {lastMsg && (
                            <span className="text-xs text-gray-500">
                              {formatTime(lastMsg.timestamp)}
                            </span>
                          )}
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-500 truncate">
                            {lastMsg ? lastMsg.text : "No hay mensajes"}
                          </p>
                          {conversation.unreadCount > 0 && (
                            <Badge variant="destructive" className="text-xs h-5 min-w-5 flex items-center justify-center">
                              {conversation.unreadCount}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </TabsContent>
            
            <TabsContent value="contacts" className="p-0 m-0">
              <div className="overflow-auto h-[calc(100vh-14rem)]">
                {filteredContacts.map(contact => (
                  <div
                    key={contact.id}
                    className="flex items-center gap-3 p-3 hover:bg-gray-100 cursor-pointer"
                    onClick={() => {
                      // Buscar o crear conversación con este contacto
                      let convId = conversations.find(c => 
                        c.participants.includes("current_user") && c.participants.includes(contact.id)
                      )?.id;
                      
                      if (!convId) {
                        convId = `conv_${Date.now()}`;
                        setConversations(prev => [
                          ...prev,
                          {
                            id: convId,
                            participants: ["current_user", contact.id],
                            unreadCount: 0
                          }
                        ]);
                        setMessages(prev => ({
                          ...prev,
                          [convId]: []
                        }));
                      }
                      
                      setActiveConversation(convId);
                    }}
                  >
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src={contact.avatar} alt={contact.name} />
                        <AvatarFallback>{contact.name.substring(0, 2)}</AvatarFallback>
                      </Avatar>
                      <span 
                        className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                          getStatusColor(contact.status)
                        }`}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center">
                        <h3 className="font-medium text-sm truncate">{contact.name}</h3>
                        <Badge variant={contact.role === "writer" ? "outline" : "default"} className="text-xs">
                          {contact.role === "writer" ? "Escritor" : "Estudiante"}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-500">
                        {contact.status === "online" ? "En línea" : 
                         contact.status === "busy" ? "Ocupado" : 
                         contact.lastSeen ? contact.lastSeen : "Desconectado"}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Main Chat Area */}
        <div className="col-span-2 flex flex-col h-full">
          {activeConversation && (
            <>
              {/* Chat Header */}
              <div className="p-3 border-b flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    {(() => {
                      const otherUserId = getOtherParticipant(activeConversation);
                      const otherUser = getContact(otherUserId);
                      
                      if (!otherUser) return null;
                      
                      return (
                        <>
                          <Avatar>
                            <AvatarImage src={otherUser.avatar} alt={otherUser.name} />
                            <AvatarFallback>{otherUser.name.substring(0, 2)}</AvatarFallback>
                          </Avatar>
                          <span 
                            className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                              getStatusColor(otherUser.status)
                            }`}
                          />
                        </>
                      );
                    })()}
                  </div>
                  <div>
                    <h3 className="font-medium">
                      {getContact(getOtherParticipant(activeConversation))?.name}
                    </h3>
                    <p className="text-xs text-gray-500">
                      {(() => {
                        const otherUserId = getOtherParticipant(activeConversation);
                        const otherUser = getContact(otherUserId);
                        
                        if (!otherUser) return null;
                        
                        return otherUser.status === "online" ? "En línea" : 
                               otherUser.status === "busy" ? "Ocupado" : 
                               otherUser.lastSeen ? otherUser.lastSeen : "Desconectado";
                      })()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon">
                    <Phone className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Info className="h-5 w-5" />
                  </Button>
                </div>
              </div>
              
              {/* Messages Area */}
              <div className="flex-1 overflow-auto p-4 bg-gray-50">
                <div className="space-y-4">
                  {messages[activeConversation]?.map((msg, index) => {
                    const isCurrentUser = msg.sender === "current_user";
                    const showAvatar = index === 0 || 
                      messages[activeConversation][index - 1]?.sender !== msg.sender;
                    
                    return (
                      <div 
                        key={msg.id} 
                        className={`flex ${isCurrentUser ? "justify-end" : "justify-start"}`}
                      >
                        {!isCurrentUser && showAvatar && (
                          <div className="mr-2 flex-shrink-0">
                            <Avatar className="h-8 w-8">
                              <AvatarImage 
                                src={getContact(msg.sender)?.avatar} 
                                alt={getContact(msg.sender)?.name || ""} 
                              />
                              <AvatarFallback>
                                {getContact(msg.sender)?.name.substring(0, 2) || ""}
                              </AvatarFallback>
                            </Avatar>
                          </div>
                        )}
                        
                        <div className={`max-w-[70%] space-y-1`}>
                          <div 
                            className={`p-3 rounded-lg ${
                              isCurrentUser 
                                ? "bg-blue-500 text-white rounded-br-none" 
                                : "bg-white text-gray-800 rounded-bl-none border"
                            }`}
                          >
                            <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                            
                            {msg.attachments && msg.attachments.length > 0 && (
                              <div className="mt-2 space-y-2">
                                {msg.attachments.map((attachment, i) => (
                                  <div
                                    key={i}
                                    className={`flex items-center p-2 rounded ${
                                      isCurrentUser ? "bg-blue-600" : "bg-gray-100"
                                    }`}
                                  >
                                    <Paperclip className="h-4 w-4 mr-2 shrink-0" />
                                    <span className="text-xs truncate">{attachment.name}</span>
                                    <Button 
                                      variant="ghost" 
                                      size="icon" 
                                      className="h-6 w-6 ml-auto shrink-0"
                                    >
                                      <Download className="h-3 w-3" />
                                    </Button>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                          
                          <div className={`flex items-center text-xs text-gray-500 ${
                            isCurrentUser ? "justify-end" : "justify-start"
                          }`}>
                            <span>{formatTime(msg.timestamp)}</span>
                            {isCurrentUser && (
                              <CheckCheck className={`h-3 w-3 ml-1 ${
                                msg.read ? "text-blue-500" : "text-gray-400"
                              }`} />
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </div>
              </div>
              
              {/* Input Area */}
              <div className="p-3 border-t">
                <div className="flex items-end gap-2">
                  <Button variant="ghost" size="icon" className="shrink-0">
                    <Paperclip className="h-5 w-5" />
                  </Button>
                  <Textarea
                    placeholder="Escribe un mensaje..."
                    className="min-h-[60px] resize-none"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                  />
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="shrink-0"
                  >
                    <Smile className="h-5 w-5" />
                  </Button>
                  <Button 
                    className="shrink-0"
                    disabled={!newMessage.trim()}
                    onClick={handleSendMessage}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Enviar
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default DirectMessaging;
