
import { ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  url?: string;
}

const ServiceCard = ({ title, description, icon, url = "#solicitar" }: ServiceCardProps) => {
  return (
    <div className="bg-card p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 border border-border group">
      <Link to={url} className="block">
        <div className="flex flex-col items-center text-center">
          <div className="p-3 bg-muted rounded-full mb-4 group-hover:bg-primary/10 transition-colors duration-300">
            {icon}
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center">
            {title}
            <ExternalLink className="ml-1 h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
          </h3>
          <p className="text-muted-foreground">{description}</p>
        </div>
      </Link>
    </div>
  );
};

export default ServiceCard;
