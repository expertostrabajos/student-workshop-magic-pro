
import { useState, useEffect } from "react";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  CreditCard,
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  ThumbsUp,
  ThumbsDown,
  FileText,
  Calendar,
  ArrowRight,
} from "lucide-react";

interface Payment {
  id: string;
  studentId: string;
  studentName: string;
  method: "card" | "transfer";
  amount: string;
  date: string;
  status: "pending" | "verified" | "rejected";
  receiptUrl?: string;
  verifiedDate?: string;
  verifiedBy?: string;
  notes?: string;
  workAssigned: boolean;
}

const AdminPaymentVerification = () => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);
  const [isVerifyDialogOpen, setIsVerifyDialogOpen] = useState(false);
  const [verificationNotes, setVerificationNotes] = useState("");
  const [isViewReceiptOpen, setIsViewReceiptOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulamos la carga de datos
    const loadPayments = () => {
      setIsLoading(true);
      setTimeout(() => {
        // Datos de ejemplo
        setPayments([
          {
            id: "PAY-001",
            studentId: "ST-101",
            studentName: "María Rodríguez",
            method: "transfer",
            amount: "199.000",
            date: "2023-07-22",
            status: "pending",
            receiptUrl: "https://via.placeholder.com/600x400?text=Comprobante+de+Pago",
            workAssigned: false
          },
          {
            id: "PAY-002",
            studentId: "ST-102",
            studentName: "Carlos Gómez",
            method: "card",
            amount: "279.000",
            date: "2023-07-21",
            status: "verified",
            verifiedDate: "2023-07-21",
            verifiedBy: "Admin",
            workAssigned: true
          },
          {
            id: "PAY-003",
            studentId: "ST-103",
            studentName: "Laura Sánchez",
            method: "transfer",
            amount: "199.000",
            date: "2023-07-20",
            status: "rejected",
            verifiedDate: "2023-07-21",
            verifiedBy: "Admin",
            notes: "No se encontró el pago en la cuenta bancaria",
            workAssigned: false
          }
        ]);
        setIsLoading(false);
      }, 1000);
    };

    loadPayments();
  }, []);

  const handleVerifyPayment = (verified: boolean) => {
    if (!selectedPayment) return;

    const now = new Date().toISOString();
    const newStatus = verified ? "verified" : "rejected";

    setPayments(prevPayments =>
      prevPayments.map(payment =>
        payment.id === selectedPayment.id
          ? {
              ...payment,
              status: newStatus,
              verifiedDate: now.split("T")[0],
              verifiedBy: "Admin",
              notes: verificationNotes || undefined,
              workAssigned: verified ? true : false
            }
          : payment
      )
    );

    toast.success(
      verified
        ? "Pago verificado y trabajo iniciado"
        : "Pago rechazado correctamente",
      {
        description: verified
          ? "El pago ha sido confirmado y el trabajo ha sido activado"
          : "El pago ha sido rechazado y se ha notificado al estudiante"
      }
    );

    setIsVerifyDialogOpen(false);
    setSelectedPayment(null);
    setVerificationNotes("");
  };

  const openVerifyDialog = (payment: Payment) => {
    setSelectedPayment(payment);
    setIsVerifyDialogOpen(true);
  };

  const openReceiptDialog = (payment: Payment) => {
    setSelectedPayment(payment);
    setIsViewReceiptOpen(true);
  };

  const getStatusBadge = (status: Payment["status"]) => {
    const statusConfig = {
      pending: {
        bg: "bg-yellow-100",
        text: "text-yellow-800",
        icon: <Clock className="w-4 h-4 mr-1" />,
        label: "Pendiente"
      },
      verified: {
        bg: "bg-green-100",
        text: "text-green-800",
        icon: <CheckCircle className="w-4 h-4 mr-1" />,
        label: "Verificado"
      },
      rejected: {
        bg: "bg-red-100",
        text: "text-red-800",
        icon: <XCircle className="w-4 h-4 mr-1" />,
        label: "Rechazado"
      }
    };

    const config = statusConfig[status];
    return (
      <span
        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bg} ${config.text}`}
      >
        {config.icon}
        {config.label}
      </span>
    );
  };

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-2">Verificación de Pagos</h2>
        <p className="text-gray-600">
          Confirma pagos por transferencia y activa los trabajos académicos
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pagos Pendientes de Verificación</CardTitle>
          <CardDescription>
            Revisa los comprobantes y confirma los pagos para activar los trabajos
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          ) : payments.length === 0 ? (
            <div className="text-center py-8">
              <CreditCard className="h-12 w-12 mx-auto text-gray-400" />
              <p className="mt-2 text-gray-500">No hay pagos por verificar.</p>
            </div>
          ) : (
            <div className="overflow-hidden rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Estudiante</TableHead>
                    <TableHead>Método</TableHead>
                    <TableHead>Monto</TableHead>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Trabajo Asignado</TableHead>
                    <TableHead className="text-right">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payments.map(payment => (
                    <TableRow key={payment.id}>
                      <TableCell className="font-medium">{payment.id}</TableCell>
                      <TableCell>{payment.studentName}</TableCell>
                      <TableCell>
                        {payment.method === "card" ? (
                          <span className="flex items-center">
                            <CreditCard className="w-4 h-4 mr-1 text-gray-500" />
                            Tarjeta
                          </span>
                        ) : (
                          <span className="flex items-center">
                            <FileText className="w-4 h-4 mr-1 text-gray-500" />
                            Transferencia
                          </span>
                        )}
                      </TableCell>
                      <TableCell>${payment.amount} COP</TableCell>
                      <TableCell>
                        <span className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1 text-gray-500" />
                          {new Date(payment.date).toLocaleDateString()}
                        </span>
                      </TableCell>
                      <TableCell>{getStatusBadge(payment.status)}</TableCell>
                      <TableCell>
                        {payment.workAssigned ? (
                          <span className="text-green-600 flex items-center">
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Sí
                          </span>
                        ) : (
                          <span className="text-gray-500 flex items-center">
                            <XCircle className="w-4 h-4 mr-1" />
                            No
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end items-center space-x-2">
                          {payment.method === "transfer" && payment.receiptUrl && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openReceiptDialog(payment)}
                              className="h-8 px-2 text-blue-600"
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              <span className="sr-only sm:not-sr-only sm:text-xs">
                                Ver comprobante
                              </span>
                            </Button>
                          )}
                          {payment.status === "pending" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openVerifyDialog(payment)}
                              className="h-8 px-2 text-green-600 border-green-200"
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              <span className="sr-only sm:not-sr-only sm:text-xs">
                                Verificar
                              </span>
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter className="bg-gray-50 py-3 px-6 flex justify-between text-sm text-gray-600">
          <div>Total pagos pendientes: {payments.filter(p => p.status === "pending").length}</div>
          <div>Último actualizado: {new Date().toLocaleDateString()}</div>
        </CardFooter>
      </Card>

      {/* Dialog de verificación de pago */}
      <Dialog open={isVerifyDialogOpen} onOpenChange={setIsVerifyDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Verificar Pago</DialogTitle>
            <DialogDescription>
              {selectedPayment && (
                <div className="text-sm text-gray-500">
                  {selectedPayment.studentName} • {selectedPayment.id} •{" "}
                  ${selectedPayment.amount} COP
                </div>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 mb-4">
              <p className="text-sm text-yellow-800">
                <strong>Importante:</strong> Al verificar este pago, automáticamente se iniciará el trabajo académico
                asociado. Asegúrate de que el pago ha sido recibido correctamente.
              </p>
            </div>
            
            <div className="mb-4">
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
                Notas adicionales (opcional)
              </label>
              <textarea
                id="notes"
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md resize-none"
                placeholder="Agregar comentarios sobre la verificación..."
                value={verificationNotes}
                onChange={(e) => setVerificationNotes(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter className="flex space-x-2">
            <Button
              variant="outline"
              onClick={() => setIsVerifyDialogOpen(false)}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => handleVerifyPayment(false)}
              className="flex-1"
            >
              <ThumbsDown className="h-4 w-4 mr-2" />
              Rechazar
            </Button>
            <Button
              onClick={() => handleVerifyPayment(true)}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              <ThumbsUp className="h-4 w-4 mr-2" />
              Verificar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog para ver comprobante */}
      <Dialog open={isViewReceiptOpen} onOpenChange={setIsViewReceiptOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Comprobante de Pago</DialogTitle>
            <DialogDescription>
              {selectedPayment && (
                <p>
                  Referencia: {selectedPayment.id} • Fecha:{" "}
                  {new Date(selectedPayment.date).toLocaleDateString()}
                </p>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            {selectedPayment && selectedPayment.receiptUrl && (
              <div className="bg-gray-100 p-2 rounded-md">
                <img
                  src={selectedPayment.receiptUrl}
                  alt="Comprobante de pago"
                  className="w-full h-auto rounded-md"
                />
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsViewReceiptOpen(false)}
              className="mr-2"
            >
              Cerrar
            </Button>
            {selectedPayment && selectedPayment.status === "pending" && (
              <Button
                onClick={() => {
                  setIsViewReceiptOpen(false);
                  openVerifyDialog(selectedPayment);
                }}
              >
                <ArrowRight className="h-4 w-4 mr-2" />
                Ir a verificar
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminPaymentVerification;
