
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

interface PricingCardProps {
  title: string;
  price: string;
  features: string[];
  isPopular?: boolean;
}

const PricingCard = ({ title, price, features, isPopular = false }: PricingCardProps) => {
  const [showPaymentInfo, setShowPaymentInfo] = useState(false);
  const navigate = useNavigate();
  
  const handleSelectPlan = () => {
    setShowPaymentInfo(true);
    toast({
      title: "Plan seleccionado",
      description: "Se mostrará la información de pago",
    });
  };

  const handleProceedToCheckout = () => {
    setShowPaymentInfo(false);
    
    // Navegamos a la página de checkout con la información del plan
    navigate("/checkout", { 
      state: { 
        plan: {
          title,
          price,
          features
        }
      }
    });
  };

  return (
    <div className={`relative bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 border ${isPopular ? 'border-green-500' : 'border-gray-100'}`}>
      {isPopular && (
        <div className="absolute top-0 right-0 bg-green-500 text-white px-3 py-1 text-sm rounded-tr-xl rounded-bl-xl">
          Popular
        </div>
      )}
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-4">{title}</h3>
        <div className="mb-6">
          <span className="text-4xl font-bold">{price}</span>
          <span className="text-gray-600">/trabajo</span>
        </div>
        <ul className="space-y-3 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-gray-600">
              <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
              {feature}
            </li>
          ))}
        </ul>
        <button 
          onClick={handleSelectPlan}
          className={`w-full py-2 px-4 rounded-lg transition-colors duration-300 ${
            isPopular
              ? 'bg-green-500 text-white hover:bg-green-600'
              : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
          }`}
        >
          Seleccionar Plan
        </button>
      </div>

      <Dialog open={showPaymentInfo} onOpenChange={setShowPaymentInfo}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Información de Pago - {title}</DialogTitle>
            <DialogDescription className="space-y-4">
              <p className="text-lg font-medium">Valor a pagar: {price} COP</p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="font-semibold mb-2">¿Cómo quieres proceder?</p>
                <p className="text-sm text-gray-600 mb-4">
                  Puedes ir directamente a nuestra página de checkout para completar el pago de manera segura.
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={handleProceedToCheckout}
                    className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                  >
                    Ir al Checkout
                  </button>
                  <button
                    onClick={() => setShowPaymentInfo(false)}
                    className="px-4 py-2 bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200 transition-colors"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PricingCard;
