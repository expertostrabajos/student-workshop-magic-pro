
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';
import { User, LogOut, UserCircle, FileText, Settings, Bell, AlertCircle, Shield } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';

const NavbarAuth = () => {
  const navigate = useNavigate();
  const { user, loading, signOut, isAdmin } = useAuth();
  
  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };
  
  // Extraer la primera letra para el avatar
  const getInitials = () => {
    if (!user?.email) return 'U';
    return user.email.charAt(0).toUpperCase();
  };
  
  // Si está cargando, mostramos un indicador de carga
  if (loading) {
    return (
      <div className="flex items-center">
        <div className="h-8 w-8 rounded-full bg-gray-200 animate-pulse"></div>
      </div>
    );
  }
  
  // Si el usuario está autenticado, mostramos su perfil
  if (user) {
    return (
      <div className="flex items-center gap-2">
        {isAdmin && (
          <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full flex items-center mr-2">
            <Shield className="h-3 w-3 mr-1" />
            Admin
          </span>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-10 w-10 rounded-full p-0 hover:bg-gray-100">
              <Avatar>
                <AvatarImage src={user.user_metadata?.avatar_url} alt={user.email || 'Usuario'} />
                <AvatarFallback>{getInitials()}</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Mi cuenta</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate('/dashboard')} className="cursor-pointer">
              <UserCircle className="mr-2 h-4 w-4" />
              <span>Dashboard</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('/document-library')} className="cursor-pointer">
              <FileText className="mr-2 h-4 w-4" />
              <span>Mis documentos</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('/academic-tools')} className="cursor-pointer">
              <Settings className="mr-2 h-4 w-4" />
              <span>Herramientas</span>
            </DropdownMenuItem>
            
            {isAdmin && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate('/admin')} className="cursor-pointer">
                  <Shield className="mr-2 h-4 w-4" />
                  <span>Panel de Admin</span>
                </DropdownMenuItem>
              </>
            )}
            
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer text-red-600">
              <LogOut className="mr-2 h-4 w-4" />
              <span>Cerrar sesión</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    );
  }
  
  // Si no está autenticado, mostramos botones de inicio de sesión y registro
  return (
    <div className="flex items-center gap-2">
      <Button variant="ghost" onClick={() => navigate('/login')}>
        Iniciar sesión
      </Button>
      <Button className="bg-green-500 hover:bg-green-600" onClick={() => navigate('/register')}>
        Registrarse
      </Button>
    </div>
  );
};

export default NavbarAuth;
