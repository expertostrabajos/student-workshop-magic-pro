
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

const CookieConsent = () => {
  const [showCookiesNotice, setShowCookiesNotice] = useState(true);

  useEffect(() => {
    const cookiesAccepted = localStorage.getItem("cookiesAccepted");
    const cookiesRejected = localStorage.getItem("cookiesRejected");
    
    if (cookiesAccepted || cookiesRejected) {
      setShowCookiesNotice(false);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("cookiesAccepted", "true");
    localStorage.removeItem("cookiesRejected");
    setShowCookiesNotice(false);
  };
  
  const rejectCookies = () => {
    localStorage.setItem("cookiesRejected", "true");
    localStorage.removeItem("cookiesAccepted");
    setShowCookiesNotice(false);
  };

  if (!showCookiesNotice) return null;

  return (
    <div className="fixed bottom-0 inset-x-0 bg-card border-t border-border text-foreground p-4 z-50">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between">
        <div className="mb-4 sm:mb-0 text-center sm:text-left">
          <p className="text-sm text-muted-foreground">
            Este sitio utiliza cookies para mejorar tu experiencia. Al continuar navegando, aceptas nuestro uso de cookies.
          </p>
        </div>
        <div className="flex space-x-4">
          <Button variant="outline" size="sm" onClick={rejectCookies}>
            Rechazar
          </Button>
          <Button size="sm" onClick={acceptCookies}>
            Aceptar
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CookieConsent;
