
import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { CalendarIcon, PlusCircle, Clock, AlertCircle, CheckCircle, XCircle } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { toast } from "sonner";

interface DeadlineEvent {
  id: string;
  title: string;
  date: Date;
  description?: string;
  type: "assignment" | "exam" | "project" | "other";
  priority: "low" | "medium" | "high";
}

const CalendarScheduler = () => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [events, setEvents] = useState<DeadlineEvent[]>([
    {
      id: "1",
      title: "Entrega de Ensayo",
      date: new Date(2025, 3, 20),
      description: "Ensayo sobre literatura colombiana contemporánea",
      type: "assignment",
      priority: "high"
    },
    {
      id: "2",
      title: "Examen Parcial",
      date: new Date(2025, 3, 15),
      description: "Examen de matemáticas",
      type: "exam",
      priority: "high"
    },
    {
      id: "3",
      title: "Presentación Grupal",
      date: new Date(2025, 3, 22),
      description: "Presentación sobre impacto ambiental",
      type: "project",
      priority: "medium"
    }
  ]);
  
  const [showNewEventDialog, setShowNewEventDialog] = useState(false);
  const [newEvent, setNewEvent] = useState<Partial<DeadlineEvent>>({
    title: "",
    date: new Date(),
    description: "",
    type: "assignment",
    priority: "medium"
  });
  
  const [selectedDateEvents, setSelectedDateEvents] = useState<DeadlineEvent[]>([]);
  
  // Update the filtered events when date changes
  const updateSelectedEvents = (selectedDate: Date | undefined) => {
    if (!selectedDate) return;
    
    const filtered = events.filter(event => 
      event.date.getDate() === selectedDate.getDate() &&
      event.date.getMonth() === selectedDate.getMonth() &&
      event.date.getFullYear() === selectedDate.getFullYear()
    );
    
    setSelectedDateEvents(filtered);
  };
  
  // Update selected events when date or events change
  useState(() => {
    updateSelectedEvents(date);
  });
  
  const handleDateSelect = (selectedDate: Date | undefined) => {
    setDate(selectedDate);
    updateSelectedEvents(selectedDate);
  };
  
  const handleAddEvent = () => {
    if (!newEvent.title || !newEvent.date) {
      toast.error("Por favor completa al menos el título y la fecha");
      return;
    }
    
    const event: DeadlineEvent = {
      id: `event-${Date.now()}`,
      title: newEvent.title || "",
      date: newEvent.date || new Date(),
      description: newEvent.description,
      type: newEvent.type as "assignment" | "exam" | "project" | "other",
      priority: newEvent.priority as "low" | "medium" | "high"
    };
    
    setEvents([...events, event]);
    setShowNewEventDialog(false);
    toast.success("Evento agregado al calendario");
    
    // Reset form
    setNewEvent({
      title: "",
      date: date || new Date(),
      description: "",
      type: "assignment",
      priority: "medium"
    });
    
    // Update selected date events
    updateSelectedEvents(date);
  };
  
  const handleDeleteEvent = (id: string) => {
    setEvents(events.filter(event => event.id !== id));
    toast.success("Evento eliminado");
    updateSelectedEvents(date);
  };
  
  // Function to get highlighted dates for the calendar
  const getHighlightedDates = () => {
    const dates: Record<string, {
      backgroundColor?: string;
      textColor?: string;
      border?: string;
    }> = {};
    
    events.forEach(event => {
      const dateStr = format(event.date, "yyyy-MM-dd");
      
      let backgroundColor;
      switch (event.priority) {
        case "high":
          backgroundColor = "bg-red-100";
          break;
        case "medium":
          backgroundColor = "bg-yellow-100";
          break;
        case "low":
          backgroundColor = "bg-green-100";
          break;
      }
      
      dates[dateStr] = { backgroundColor };
    });
    
    return dates;
  };
  
  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">Alta</span>;
      case "medium":
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">Media</span>;
      case "low":
        return <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Baja</span>;
      default:
        return null;
    }
  };
  
  const getTypeBadge = (type: string) => {
    switch (type) {
      case "assignment":
        return <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">Tarea</span>;
      case "exam":
        return <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">Examen</span>;
      case "project":
        return <span className="px-2 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full">Proyecto</span>;
      case "other":
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded-full">Otro</span>;
      default:
        return null;
    }
  };
  
  // Get days with events for highlighting in the calendar
  const daysWithEvents = events.map(event => event.date);
  
  // Custom calendar rendering to highlight dates with events
  const renderDay = (day: Date) => {
    const hasEvents = daysWithEvents.some(eventDate => 
      eventDate.getDate() === day.getDate() &&
      eventDate.getMonth() === day.getMonth() &&
      eventDate.getFullYear() === day.getFullYear()
    );
    
    const eventsForDay = events.filter(event => 
      event.date.getDate() === day.getDate() &&
      event.date.getMonth() === day.getMonth() &&
      event.date.getFullYear() === day.getFullYear()
    );
    
    const highPriority = eventsForDay.some(e => e.priority === "high");
    const mediumPriority = eventsForDay.some(e => e.priority === "medium");
    const lowPriority = eventsForDay.some(e => e.priority === "low");
    
    let dotColor = "";
    if (highPriority) dotColor = "bg-red-500";
    else if (mediumPriority) dotColor = "bg-yellow-500";
    else if (lowPriority) dotColor = "bg-green-500";
    
    return (
      <div className="relative">
        {day.getDate()}
        {hasEvents && (
          <div className={`absolute w-1.5 h-1.5 rounded-full ${dotColor} bottom-0 left-1/2 transform -translate-x-1/2`}></div>
        )}
      </div>
    );
  };
  
  return (
    <div className="w-full max-w-6xl mx-auto">
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Calendario Académico</CardTitle>
          <CardDescription>Gestiona tus fechas de entrega y compromisos académicos</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-7 gap-6">
            <div className="md:col-span-3 lg:col-span-2">
              <div className="flex flex-col space-y-4">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={handleDateSelect}
                  className="rounded-md border pointer-events-auto"
                  locale={es}
                />
                
                <Button 
                  onClick={() => {
                    setNewEvent({
                      ...newEvent,
                      date: date || new Date()
                    });
                    setShowNewEventDialog(true);
                  }} 
                  className="w-full"
                >
                  <PlusCircle className="w-4 h-4 mr-2" />
                  Agregar Evento
                </Button>
              </div>
            </div>
            
            <div className="md:col-span-4 lg:col-span-5">
              <div className="rounded-lg border p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium">
                    {date ? format(date, "EEEE, d 'de' MMMM yyyy", { locale: es }) : "Sin fecha seleccionada"}
                  </h3>
                </div>
                
                {selectedDateEvents.length > 0 ? (
                  <div className="space-y-4">
                    {selectedDateEvents.map(event => (
                      <div key={event.id} className="border rounded-lg p-3 hover:bg-gray-50">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium text-gray-900">{event.title}</h4>
                            {event.description && (
                              <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                            )}
                            <div className="flex flex-wrap gap-2 mt-2">
                              {getTypeBadge(event.type)}
                              {getPriorityBadge(event.priority)}
                            </div>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleDeleteEvent(event.id)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          >
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <CalendarIcon className="h-12 w-12 text-gray-300 mx-auto" />
                    <p className="mt-2 text-gray-500">No hay eventos para esta fecha</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-3"
                      onClick={() => {
                        setNewEvent({
                          ...newEvent,
                          date: date || new Date()
                        });
                        setShowNewEventDialog(true);
                      }}
                    >
                      <PlusCircle className="w-4 h-4 mr-2" /> 
                      Crear Evento
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="rounded-lg border p-4 bg-blue-50 hover:bg-blue-100 transition-colors">
                  <div className="flex items-center space-x-2 mb-1 text-blue-800">
                    <AlertCircle className="h-5 w-5" />
                    <h4 className="font-medium">Próxima Entrega</h4>
                  </div>
                  <p className="text-sm text-blue-700">
                    {events.length > 0 ? (
                      <>
                        {events[0].title} - {format(events[0].date, "d MMM", { locale: es })}
                      </>
                    ) : "No hay entregas próximas"}
                  </p>
                </div>
                
                <div className="rounded-lg border p-4 bg-purple-50 hover:bg-purple-100 transition-colors">
                  <div className="flex items-center space-x-2 mb-1 text-purple-800">
                    <Clock className="h-5 w-5" />
                    <h4 className="font-medium">Esta Semana</h4>
                  </div>
                  <p className="text-sm text-purple-700">
                    {events.length} eventos pendientes
                  </p>
                </div>
                
                <div className="rounded-lg border p-4 bg-green-50 hover:bg-green-100 transition-colors">
                  <div className="flex items-center space-x-2 mb-1 text-green-800">
                    <CheckCircle className="h-5 w-5" />
                    <h4 className="font-medium">Completados</h4>
                  </div>
                  <p className="text-sm text-green-700">
                    0 eventos completados
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Add New Event Dialog */}
      <Dialog open={showNewEventDialog} onOpenChange={setShowNewEventDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Agregar Nuevo Evento</DialogTitle>
            <DialogDescription>
              Crea un evento o recordatorio para tu calendario académico
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Título</Label>
              <Input 
                id="title" 
                placeholder="Ej: Entrega de ensayo" 
                value={newEvent.title} 
                onChange={(e) => setNewEvent({...newEvent, title: e.target.value})}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="date">Fecha</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {newEvent.date ? (
                      format(newEvent.date, "PPP", { locale: es })
                    ) : (
                      <span>Seleccionar fecha</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={newEvent.date}
                    onSelect={(date) => setNewEvent({...newEvent, date})}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="description">Descripción (opcional)</Label>
              <Input 
                id="description" 
                placeholder="Detalles del evento" 
                value={newEvent.description || ""} 
                onChange={(e) => setNewEvent({...newEvent, description: e.target.value})}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="type">Tipo de Evento</Label>
              <select 
                id="type"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                value={newEvent.type}
                onChange={(e) => setNewEvent({...newEvent, type: e.target.value as any})}
              >
                <option value="assignment">Tarea</option>
                <option value="exam">Examen</option>
                <option value="project">Proyecto</option>
                <option value="other">Otro</option>
              </select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="priority">Prioridad</Label>
              <select 
                id="priority"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                value={newEvent.priority}
                onChange={(e) => setNewEvent({...newEvent, priority: e.target.value as any})}
              >
                <option value="low">Baja</option>
                <option value="medium">Media</option>
                <option value="high">Alta</option>
              </select>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewEventDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddEvent}>Guardar Evento</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CalendarScheduler;
