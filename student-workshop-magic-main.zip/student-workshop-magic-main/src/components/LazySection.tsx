import React, { memo } from 'react';
import { useLazyRender } from '@/hooks/useIntersectionObserver';
import { Skeleton } from '@/components/ui/skeleton';

interface LazySectionProps {
  children: React.ReactNode;
  height?: string;
  className?: string;
}

/**
 * Componente wrapper que solo renderiza su contenido cuando está cerca del viewport.
 * Reduce el trabajo inicial del navegador al diferir secciones no visibles.
 */
const LazySection = memo(({ children, height = 'h-32', className = '' }: LazySectionProps) => {
  const { ref, shouldRender } = useLazyRender('300px');

  if (!shouldRender) {
    return (
      <div ref={ref} className={`w-full ${height} ${className}`}>
        <div className="w-full h-full flex flex-col space-y-3 p-4">
          <Skeleton className="w-full h-8" />
          <Skeleton className="w-3/4 h-6" />
          <Skeleton className="w-1/2 h-6" />
        </div>
      </div>
    );
  }

  return <div className={className}>{children}</div>;
});

LazySection.displayName = 'LazySection';

export default LazySection;
