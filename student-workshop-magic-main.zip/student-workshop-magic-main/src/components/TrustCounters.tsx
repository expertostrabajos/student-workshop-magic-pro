import AnimatedCounter from "./AnimatedCounter";

const TrustCounters = () => {
  return (
    <section className="py-14 md:py-20 border-y border-border bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          <AnimatedCounter end={500} suffix="+" label="Trabajos Entregados" />
          <AnimatedCounter end={98} suffix="%" label="Clientes Satisfechos" />
          <AnimatedCounter end={50} suffix="+" label="Expertos Disponibles" />
          <AnimatedCounter end={4} suffix=" años" label="De Experiencia" />
        </div>
      </div>
    </section>
  );
};

export default TrustCounters;
