import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import type { Reviewer } from "@/hooks/useReviewers";

interface ReviewerFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reviewer: Reviewer | null; // null = create mode
  onSave: (data: Omit<Reviewer, "id" | "createdAt" | "updatedAt">) => Promise<void>;
}

const SPECIALTIES = [
  "Derecho",
  "Ingeniería",
  "Medicina",
  "Administración de Empresas",
  "Psicología",
  "Educación",
  "Contabilidad",
  "Economía",
  "Informática",
  "Ciencias Sociales",
  "Otro",
];

const ReviewerFormDialog = ({
  open,
  onOpenChange,
  reviewer,
  onSave,
}: ReviewerFormDialogProps) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [customSpecialty, setCustomSpecialty] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const isEditing = !!reviewer;

  useEffect(() => {
    if (reviewer) {
      setName(reviewer.name);
      setEmail(reviewer.email);
      const found = SPECIALTIES.includes(reviewer.specialty);
      setSpecialty(found ? reviewer.specialty : "Otro");
      setCustomSpecialty(found ? "" : reviewer.specialty);
      setIsActive(reviewer.isActive);
    } else {
      setName("");
      setEmail("");
      setSpecialty("");
      setCustomSpecialty("");
      setIsActive(true);
    }
  }, [reviewer, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    const finalSpecialty = specialty === "Otro" ? customSpecialty : specialty;

    try {
      await onSave({
        name: name.trim(),
        email: email.trim(),
        specialty: finalSpecialty,
        currentWorkload: reviewer?.currentWorkload ?? 0,
        completedWorks: reviewer?.completedWorks ?? 0,
        averageQuality: reviewer?.averageQuality ?? 0,
        isActive,
        userId: reviewer?.userId,
      });
      onOpenChange(false);
    } finally {
      setIsSaving(false);
    }
  };

  const isValid =
    name.trim().length >= 2 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) &&
    (specialty !== "" && specialty !== "Otro"
      ? true
      : customSpecialty.trim().length >= 2);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Editar Revisor" : "Nuevo Revisor"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Actualiza la información del revisor."
              : "Completa los datos para registrar un nuevo revisor."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="reviewer-name">Nombre completo</Label>
            <Input
              id="reviewer-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej: María García López"
              required
              minLength={2}
              maxLength={200}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reviewer-email">Correo electrónico</Label>
            <Input
              id="reviewer-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="correo@ejemplo.com"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reviewer-specialty">Especialidad</Label>
            <select
              id="reviewer-specialty"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              value={specialty}
              onChange={(e) => setSpecialty(e.target.value)}
              required
            >
              <option value="">Selecciona una especialidad</option>
              {SPECIALTIES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            {specialty === "Otro" && (
              <Input
                value={customSpecialty}
                onChange={(e) => setCustomSpecialty(e.target.value)}
                placeholder="Escribe la especialidad"
                required
                minLength={2}
              />
            )}
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="reviewer-active">Estado activo</Label>
            <Switch
              id="reviewer-active"
              checked={isActive}
              onCheckedChange={setIsActive}
            />
          </div>

          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={!isValid || isSaving}>
              {isSaving
                ? "Guardando..."
                : isEditing
                ? "Guardar Cambios"
                : "Crear Revisor"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ReviewerFormDialog;
