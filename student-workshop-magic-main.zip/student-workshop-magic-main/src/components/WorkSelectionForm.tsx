
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Check, AlertCircle, Sparkles } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface AIResult {
  text: string;
  aiPercentage: number;
  aiBreakdown: {
    name: string;
    contribution: number;
    color: string;
  }[];
}

const WORK_TYPES = [
  { value: "ensayo", label: "Ensayo" },
  { value: "tesis", label: "Tesis" },
  { value: "proyecto", label: "Proyecto de investigación" },
  { value: "monografia", label: "Monografía" },
  { value: "articulo", label: "Artículo académico" },
];

const PROCESSING_STEPS = [
  { id: "gemini", name: "Gemini 2.0 Flash Thinking", description: "Generando contenido analítico..." },
  { id: "grok", name: "Grok", description: "Añadiendo enfoque conversacional..." },
  { id: "deepseek", name: "DeepSeek", description: "Incorporando contenido técnico..." },
  { id: "anakin", name: "Anakin.AI", description: "Optimizando y combinando resultados..." },
  { id: "humanize", name: "Humanización de texto", description: "Aplicando patrones humanos al texto..." },
  { id: "verify", name: "Análisis de originalidad", description: "Verificando porcentaje de IA..." },
];

const WorkSelectionForm = () => {
  const [workType, setWorkType] = useState("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<AIResult | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!workType || !description) {
      toast.error("Por favor completa todos los campos");
      return;
    }
    
    setIsSubmitting(true);
    setCurrentStep(0);
    setProgress(0);
    
    try {
      // Simular procesamiento con IAs en pasos
      for (let i = 0; i < PROCESSING_STEPS.length; i++) {
        setCurrentStep(i);
        const stepProgress = (i / PROCESSING_STEPS.length) * 100;
        setProgress(stepProgress);
        
        // Simular tiempo de procesamiento variable para cada paso
        const processingTime = Math.floor(Math.random() * 1000) + 500; // Entre 500ms y 1500ms
        await new Promise(resolve => setTimeout(resolve, processingTime));
        
        // Notificar al usuario sobre el progreso
        toast.info(`${PROCESSING_STEPS[i].name} completado`, {
          description: "Procesando siguiente paso...",
          duration: 2000,
        });
      }
      
      // Completar el progreso
      setProgress(100);
      
      // Resultado simulado de IAs
      const processedText = await simulateAIProcessing(workType, description);
      
      // Simular verificación de contenido AI con distribución detallada
      const aiPercentage = Math.floor(Math.random() * 40) + 60; // Entre 60% y 99%
      
      // Crear distribución de contribuciones por IA
      const aiBreakdown = [
        { name: "Gemini 2.0", contribution: Math.floor(Math.random() * 30) + 10, color: "#4285F4" },
        { name: "Grok", contribution: Math.floor(Math.random() * 30) + 10, color: "#EA4335" },
        { name: "DeepSeek", contribution: Math.floor(Math.random() * 30) + 10, color: "#34A853" },
        { name: "Anakin.AI", contribution: Math.floor(Math.random() * 30) + 10, color: "#FBBC05" }
      ];
      
      // Normalizar las contribuciones para que sumen 100%
      const totalContribution = aiBreakdown.reduce((sum, item) => sum + item.contribution, 0);
      aiBreakdown.forEach(item => {
        item.contribution = Math.round((item.contribution / totalContribution) * 100);
      });
      
      setResult({
        text: processedText,
        aiPercentage,
        aiBreakdown
      });
      
      toast.success("¡Trabajo procesado correctamente!", {
        description: "El contenido ha sido generado y analizado."
      });
    } catch (error) {
      toast.error("Error al procesar el trabajo", {
        description: "Por favor intenta nuevamente más tarde."
      });
    } finally {
      setIsSubmitting(false);
      setCurrentStep(-1); // Finalizar el proceso
    }
  };
  
  // Función para simular procesamiento con diferentes IAs
  const simulateAIProcessing = async (workType: string, description: string): Promise<string> => {
    // Simulación de resultados de diferentes IAs
    const geminiResult = `Análisis detallado sobre "${description}" que aborda los aspectos fundamentales del tema desde una perspectiva académica rigurosa.`;
    
    const grokResult = `He examinado a fondo la temática de "${description}" y puedo ofrecerte un ${workType} que cumple con todos los estándares académicos requeridos.`;
    
    const deepSeekResult = `Este ${workType} sobre "${description}" incorpora las metodologías más recientes y fuentes actualizadas para garantizar su relevancia.`;
    
    const anakinResult = `El contenido generado para este ${workType} ha sido optimizado para presentar argumentos coherentes y bien estructurados.`;
    
    // Humanizar el texto combinado
    let combinedText = `${geminiResult} — ${grokResult}... [De hecho]; ${deepSeekResult} (considerando las implicaciones actuales). ${anakinResult} ¡Es importante destacar! que este contenido ha sido revisado exhaustivamente; incorporando elementos de puntuación variados: puntos suspensivos... guiones - y otros elementos típicos de la escritura académica.

Como podemos observar en los datos recientes, la investigación sobre "${description}" ha evolucionado significativamente en los últimos años. Los expertos en el campo señalan que "la metodología aplicada debe ser rigurosa y sistemática" para obtener resultados confiables.

Algunos puntos clave a considerar:
- La estructura del ${workType} debe seguir un formato académico estándar
- Las fuentes deben ser actualizadas y relevantes (preferiblemente de los últimos 5 años)
- El análisis debe ser crítico y reflexivo, no meramente descriptivo
- La conclusión debe sintetizar los hallazgos principales y sugerir líneas futuras de investigación

En conclusión, este ${workType} proporcionará un análisis completo y bien fundamentado sobre "${description}", cumpliendo con todos los requisitos académicos y aportando valor al campo de estudio.`;
    
    return combinedText;
  };

  return (
    <div className="w-full max-w-3xl mx-auto bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 border border-gray-200 dark:border-gray-700">
      <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-6">Solicitud de Trabajo Académico</h3>
      
      {isSubmitting && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">
              {currentStep >= 0 && currentStep < PROCESSING_STEPS.length 
                ? PROCESSING_STEPS[currentStep].description 
                : "Procesando..."}
            </span>
            <span className="text-sm font-medium">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
          
          <div className="mt-4 space-y-2">
            {PROCESSING_STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center">
                {index < currentStep ? (
                  <Check className="mr-2 h-4 w-4 text-green-500" />
                ) : index === currentStep ? (
                  <Sparkles className="mr-2 h-4 w-4 text-amber-500 animate-pulse" />
                ) : (
                  <div className="mr-2 h-4 w-4 rounded-full border border-gray-300"></div>
                )}
                <span className={`text-sm ${
                  index < currentStep 
                    ? "text-gray-700 line-through" 
                    : index === currentStep 
                    ? "text-gray-900 font-medium" 
                    : "text-gray-500"
                }`}>
                  {step.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <label htmlFor="work-type" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Tipo de Trabajo
          </label>
          <Select value={workType} onValueChange={setWorkType}>
            <SelectTrigger id="work-type" className="w-full">
              <SelectValue placeholder="Selecciona el tipo de trabajo" />
            </SelectTrigger>
            <SelectContent>
              {WORK_TYPES.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Descripción Detallada
          </label>
          <Textarea
            id="description"
            placeholder="Describe el tema y requisitos específicos de tu trabajo..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5}
            className="w-full resize-none"
          />
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Incluye detalles como: extensión requerida, estilo de citación, enfoque específico, etc.
          </p>
        </div>
        
        <Button
          type="submit"
          className="w-full bg-green-600 hover:bg-green-700 text-white"
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Procesando con IAs...
            </>
          ) : (
            "Procesar con IAs"
          )}
        </Button>
      </form>
      
      {result && (
        <div className="mt-8 space-y-4 border-t pt-6">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-medium text-gray-900 dark:text-gray-100">Resultado Generado</h4>
            <div className="flex items-center space-x-2 bg-amber-100 dark:bg-amber-900 px-3 py-1 rounded-full">
              <AlertCircle className="h-4 w-4 text-amber-800 dark:text-amber-200" />
              <span className="text-xs font-medium text-amber-800 dark:text-amber-200">
                {result.aiPercentage}% IA
              </span>
            </div>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
            <p className="text-gray-800 dark:text-gray-200 text-sm whitespace-pre-wrap">
              {result.text}
            </p>
          </div>
          
          <div>
            <h5 className="text-sm font-medium text-gray-700 mb-2">Desglose de contribución por IA:</h5>
            <div className="space-y-2">
              {result.aiBreakdown.map((ai, index) => (
                <div key={index} className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-2" 
                    style={{ backgroundColor: ai.color }}
                  ></div>
                  <span className="text-xs text-gray-600 dark:text-gray-400 mr-2">{ai.name}:</span>
                  <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div
                      className="h-2 rounded-full"
                      style={{ 
                        width: `${ai.contribution}%`,
                        backgroundColor: ai.color
                      }}
                    ></div>
                  </div>
                  <span className="text-xs font-medium text-gray-700 dark:text-gray-300 ml-2">
                    {ai.contribution}%
                  </span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400">
            <Check className="h-4 w-4 text-green-500" />
            <span>Contenido verificado con herramientas anti-plagio</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkSelectionForm;
