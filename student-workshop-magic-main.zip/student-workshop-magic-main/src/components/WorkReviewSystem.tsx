
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Award,
  Check,
  CheckCircle,
  FileText,
  GraduationCap,
  ShieldCheck,
  Star,
  AlertTriangle,
  X,
  MessageSquare,
} from "lucide-react";
import RatingForm from "./RatingForm";
import { useNotificationContext } from "@/components/NotificationProvider";

interface WorkReview {
  id: string;
  workType: string;
  subject: string;
  topic: string;
  academicLevel: string;
  status: "pending" | "in_review" | "approved" | "rejected";
  reviewer?: string;
  feedback?: string;
  qualityScore?: number;
  submissionDate?: string;
  completionDate?: string;
  studentRating?: number;
  studentFeedback?: string;
}

const mockWorks: WorkReview[] = [
  {
    id: "1",
    workType: "ensayo",
    subject: "Literatura",
    topic: "Análisis de Cien Años de Soledad",
    academicLevel: "universidad",
    status: "pending",
    submissionDate: "2023-05-15",
  },
  {
    id: "2",
    workType: "investigacion",
    subject: "Psicología",
    topic: "Efectos del estrés en estudiantes",
    academicLevel: "maestria",
    status: "in_review",
    reviewer: "Dr. García",
    submissionDate: "2023-05-10",
  },
  {
    id: "3",
    workType: "tesis",
    subject: "Economía",
    topic: "Impacto económico post-pandemia",
    academicLevel: "doctorado",
    status: "approved",
    reviewer: "Dra. Rodríguez",
    submissionDate: "2023-05-18",
    completionDate: "2023-05-25",
    qualityScore: 8.5,
  },
  {
    id: "4",
    workType: "ensayo",
    subject: "Historia",
    topic: "La Revolución Industrial",
    academicLevel: "secundaria",
    status: "approved",
    submissionDate: "2023-05-20",
    completionDate: "2023-05-27",
    qualityScore: 9.2,
    studentRating: 4,
    studentFeedback: "Excelente trabajo, muy bien estructurado."
  },
];

// Quality assessment criteria
const qualityCriteria = [
  { id: "originality", name: "Originalidad", weight: 0.25 },
  { id: "accuracy", name: "Precisión académica", weight: 0.3 },
  { id: "format", name: "Formato y presentación", weight: 0.15 },
  { id: "depth", name: "Profundidad de análisis", weight: 0.3 },
];

const WorkReviewSystem = () => {
  const { toast: uiToast } = useToast();
  const [works, setWorks] = useState<WorkReview[]>(mockWorks);
  const [selectedWork, setSelectedWork] = useState<WorkReview | null>(null);
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);
  const [isRatingDialogOpen, setIsRatingDialogOpen] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [qualityScore, setQualityScore] = useState<number>(0);
  const [criteriaScores, setCriteriaScores] = useState<Record<string, number>>({});
  const [autoCalculatedScore, setAutoCalculatedScore] = useState<number | null>(null);
  const [showScoreDetails, setShowScoreDetails] = useState(false);
  const { addNotification } = useNotificationContext();

  // Initialize criteria scores when a work is selected
  useEffect(() => {
    if (selectedWork) {
      const initialScores: Record<string, number> = {};
      qualityCriteria.forEach(criterion => {
        initialScores[criterion.id] = 5; // Default value of 5 out of 10
      });
      setCriteriaScores(initialScores);
      calculateQualityScore(initialScores);
    }
  }, [selectedWork]);

  // Calculate weighted quality score based on criteria
  const calculateQualityScore = (scores: Record<string, number>) => {
    let weightedScore = 0;
    qualityCriteria.forEach(criterion => {
      weightedScore += scores[criterion.id] * criterion.weight;
    });
    // Round to one decimal place
    const finalScore = Math.round(weightedScore * 10) / 10;
    setAutoCalculatedScore(finalScore);
    setQualityScore(finalScore);
  };

  // Handle change in criteria scores
  const handleCriteriaScoreChange = (criterionId: string, value: number) => {
    const newScores = { ...criteriaScores, [criterionId]: value };
    setCriteriaScores(newScores);
    calculateQualityScore(newScores);
  };

  const handleReviewSubmit = () => {
    if (!selectedWork) return;

    const qualityLevel = getQualityLevel(qualityScore);
    const now = new Date().toISOString();

    setWorks(prevWorks =>
      prevWorks.map(work =>
        work.id === selectedWork.id
          ? {
              ...work,
              status: qualityScore >= 7 ? "approved" : "rejected",
              feedback,
              qualityScore,
              completionDate: now,
            }
          : work
      )
    );

    toast.success(`Revisión completada: ${qualityLevel}`, {
      description: `El trabajo ha sido ${
        qualityScore >= 7 ? "aprobado" : "rechazado"
      } con una puntuación de ${qualityScore}/10.`,
    });

    // Add notification
    addNotification({
      title: "Trabajo revisado",
      message: `El trabajo "${selectedWork.topic}" ha sido ${qualityScore >= 7 ? "aprobado" : "rechazado"} con una puntuación de ${qualityScore}/10.`,
      type: qualityScore >= 7 ? "success" : "error"
    });

    setIsReviewDialogOpen(false);
    setSelectedWork(null);
    setFeedback("");
    setQualityScore(0);
    setAutoCalculatedScore(null);
    setCriteriaScores({});
    setShowScoreDetails(false);
  };

  const handleRatingSubmit = (rating: number, feedback: string) => {
    if (!selectedWork) return;

    setWorks(prevWorks =>
      prevWorks.map(work =>
        work.id === selectedWork.id
          ? {
              ...work,
              studentRating: rating,
              studentFeedback: feedback
            }
          : work
      )
    );

    toast.success("¡Gracias por tu calificación!", {
      description: "Tu opinión es muy importante para mejorar nuestro servicio."
    });

    // Add notification for admin
    addNotification({
      title: "Nueva calificación recibida",
      message: `El trabajo "${selectedWork.topic}" ha recibido una calificación de ${rating}/5.`,
      type: "info"
    });

    setIsRatingDialogOpen(false);
    setSelectedWork(null);
  };

  const openReviewDialog = (work: WorkReview) => {
    setSelectedWork(work);
    setIsReviewDialogOpen(true);
  };

  const openRatingDialog = (work: WorkReview) => {
    setSelectedWork(work);
    setIsRatingDialogOpen(true);
  };

  // Get quality level based on score
  const getQualityLevel = (score: number): string => {
    if (score >= 9) return "Excelente";
    if (score >= 8) return "Muy bueno";
    if (score >= 7) return "Bueno";
    if (score >= 6) return "Aceptable";
    if (score >= 5) return "Regular";
    return "Insuficiente";
  };

  // Get status icon based on work status
  const getStatusIcon = (status: WorkReview["status"]) => {
    switch (status) {
      case "pending":
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case "in_review":
        return <GraduationCap className="w-4 h-4 text-blue-500" />;
      case "approved":
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "rejected":
        return <X className="w-4 h-4 text-red-500" />;
      default:
        return null;
    }
  };

  // Render student rating stars
  const renderStudentRating = (rating?: number) => {
    if (!rating) return <span className="text-gray-500">Sin calificar</span>;
    
    return (
      <div className="flex items-center">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            className={`w-4 h-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="container mx-auto py-16 mt-8">
      <div className="mb-10 text-center">
        <div className="flex items-center justify-center mb-4">
          <ShieldCheck className="w-8 h-8 text-blue-600 mr-2" />
          <h2 className="text-3xl font-bold">Sistema de Control de Calidad</h2>
        </div>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Nuestro riguroso sistema de control de calidad garantiza que todos los trabajos académicos 
          cumplan con los más altos estándares antes de ser entregados.
        </p>
      </div>
      
      <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold flex items-center">
            <FileText className="w-5 h-5 mr-2 text-blue-600" />
            Trabajos académicos pendientes de revisión
          </h3>
          <div className="flex space-x-2">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
              <CheckCircle className="w-3 h-3 mr-1" />
              Aprobados: {works.filter(w => w.status === "approved").length}
            </span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
              <AlertTriangle className="w-3 h-3 mr-1" />
              Pendientes: {works.filter(w => w.status === "pending").length}
            </span>
          </div>
        </div>
        
        <div className="overflow-hidden rounded-lg border border-gray-200">
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="w-[180px]">Tipo de trabajo</TableHead>
                <TableHead>Materia</TableHead>
                <TableHead className="hidden md:table-cell">Tema</TableHead>
                <TableHead className="hidden md:table-cell">Nivel</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Calidad</TableHead>
                <TableHead>Calificación</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {works.map((work) => (
                <TableRow key={work.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium capitalize">
                    <div className="flex items-center">
                      <FileText className="w-4 h-4 mr-2 text-gray-500" />
                      {work.workType}
                    </div>
                  </TableCell>
                  <TableCell>{work.subject}</TableCell>
                  <TableCell className="hidden md:table-cell max-w-[200px] truncate">
                    {work.topic}
                  </TableCell>
                  <TableCell className="hidden md:table-cell capitalize">
                    <span className="inline-flex items-center">
                      <GraduationCap className="w-4 h-4 mr-1 text-blue-600" />
                      {work.academicLevel}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        {
                          pending: "bg-yellow-100 text-yellow-800",
                          in_review: "bg-blue-100 text-blue-800",
                          approved: "bg-green-100 text-green-800",
                          rejected: "bg-red-100 text-red-800",
                        }[work.status]
                      }`}
                    >
                      {getStatusIcon(work.status)}
                      <span className="ml-1">
                        {
                          {
                            pending: "Pendiente",
                            in_review: "En revisión",
                            approved: "Aprobado",
                            rejected: "Rechazado",
                          }[work.status]
                        }
                      </span>
                    </span>
                  </TableCell>
                  <TableCell>
                    {work.qualityScore ? (
                      <div className="flex items-center">
                        <span className={`font-medium ${
                          work.qualityScore >= 8 ? "text-green-600" : 
                          work.qualityScore >= 7 ? "text-blue-600" : 
                          "text-red-600"
                        }`}>
                          {work.qualityScore}
                        </span>
                        <span className="text-gray-400 ml-1">/10</span>
                        <div className="ml-2">
                          {Array.from({ length: Math.round(work.qualityScore / 2) }).map((_, i) => (
                            <Star key={i} className="w-3 h-3 inline text-yellow-400" />
                          ))}
                        </div>
                      </div>
                    ) : (
                      <span className="text-gray-500">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {renderStudentRating(work.studentRating)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end items-center space-x-2">
                      {work.status === "approved" && !work.studentRating && (
                        <button
                          onClick={() => openRatingDialog(work)}
                          className="text-indigo-600 hover:text-indigo-800 font-medium text-sm flex items-center space-x-1"
                        >
                          <Star className="w-4 h-4" />
                          <span>Calificar</span>
                        </button>
                      )}
                      <button
                        onClick={() => openReviewDialog(work)}
                        className="text-blue-600 hover:text-blue-800 font-medium text-sm flex items-center space-x-1"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>Revisar</span>
                      </button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      <Dialog open={isReviewDialogOpen} onOpenChange={setIsReviewDialogOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Award className="w-5 h-5 text-blue-600 mr-2" />
              Evaluación de Calidad
            </DialogTitle>
            <DialogDescription>
              {selectedWork && (
                <div className="mt-2">
                  <p className="font-medium text-gray-700">{selectedWork.topic}</p>
                  <div className="flex items-center mt-1 text-sm text-gray-500">
                    <span className="capitalize">{selectedWork.workType}</span>
                    <span className="mx-2">•</span>
                    <span>{selectedWork.subject}</span>
                    <span className="mx-2">•</span>
                    <span className="capitalize">{selectedWork.academicLevel}</span>
                  </div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            <div className="bg-blue-50 p-4 rounded-md">
              <h4 className="text-sm font-medium text-blue-800 mb-2 flex items-center">
                <ShieldCheck className="w-4 h-4 mr-1" />
                Sistema de Evaluación Automática
              </h4>
              
              <div className="space-y-3">
                {qualityCriteria.map(criterion => (
                  <div key={criterion.id}>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-sm font-medium text-gray-700 flex items-center">
                        {criterion.name}
                        <span className="text-xs text-gray-500 ml-1">
                          ({Math.round(criterion.weight * 100)}%)
                        </span>
                      </label>
                      <span className="text-sm font-medium">{criteriaScores[criterion.id] || 0}/10</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={criteriaScores[criterion.id] || 0}
                      onChange={(e) => handleCriteriaScoreChange(criterion.id, Number(e.target.value))}
                      className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                ))}
              </div>
              
              <div className="mt-4 pt-3 border-t border-blue-100 flex items-center justify-between">
                <button 
                  onClick={() => setShowScoreDetails(!showScoreDetails)}
                  className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
                >
                  {showScoreDetails ? "Ocultar detalles" : "Ver detalles de calificación"}
                </button>
                <div className="text-right">
                  <div className="text-sm text-gray-600">Calificación automática:</div>
                  <div className="text-2xl font-bold flex items-center">
                    <span className={
                      autoCalculatedScore && autoCalculatedScore >= 8 ? "text-green-600" : 
                      autoCalculatedScore && autoCalculatedScore >= 7 ? "text-blue-600" : 
                      "text-red-600"
                    }>
                      {autoCalculatedScore || 0}
                    </span>
                    <span className="text-gray-400 text-lg ml-1">/10</span>
                    {autoCalculatedScore && (
                      <span className="ml-2 px-2 py-0.5 text-xs rounded-full font-medium bg-gray-100 text-gray-800">
                        {getQualityLevel(autoCalculatedScore)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              
              {showScoreDetails && (
                <div className="mt-3 text-sm text-gray-600 bg-white p-3 rounded border border-blue-100">
                  <p>La calificación automática se calcula ponderando cada criterio según su importancia:</p>
                  <ul className="list-disc list-inside mt-1 space-y-1">
                    {qualityCriteria.map(criterion => (
                      <li key={criterion.id}>
                        {criterion.name}: {criteriaScores[criterion.id] || 0} × {criterion.weight} = {((criteriaScores[criterion.id] || 0) * criterion.weight).toFixed(1)}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Retroalimentación detallada
              </label>
              <textarea
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
                placeholder="Proporcione retroalimentación detallada sobre el trabajo..."
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Calificación de Calidad Final (1-10)
              </label>
              <div className="flex items-center space-x-3">
                <input
                  type="number"
                  min="1"
                  max="10"
                  step="0.1"
                  value={qualityScore}
                  onChange={(e) => setQualityScore(Number(e.target.value))}
                  className="w-24 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                />
                <div className="flex-1">
                  <div className="text-sm font-medium flex items-center">
                    {qualityScore >= 0 && (
                      <>
                        <span className={
                          qualityScore >= 8 ? "text-green-600" : 
                          qualityScore >= 7 ? "text-blue-600" : 
                          "text-red-600"
                        }>
                          {getQualityLevel(qualityScore)}
                        </span>
                        <div className="ml-2">
                          {Array.from({ length: Math.round(qualityScore / 2) }).map((_, i) => (
                            <Star key={i} className="w-4 h-4 inline text-yellow-400" />
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter className="flex items-center justify-between mt-6">
            <button
              onClick={() => setIsReviewDialogOpen(false)}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              onClick={handleReviewSubmit}
              className="flex items-center bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Check className="w-4 h-4 mr-2" />
              Enviar Evaluación
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isRatingDialogOpen} onOpenChange={setIsRatingDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <MessageSquare className="w-5 h-5 text-blue-600 mr-2" />
              Califica tu trabajo académico
            </DialogTitle>
            <DialogDescription>
              {selectedWork && (
                <div className="mt-2">
                  <p className="font-medium text-gray-700">{selectedWork.topic}</p>
                  <div className="flex items-center mt-1 text-sm text-gray-500">
                    <span className="capitalize">{selectedWork.workType}</span>
                    <span className="mx-2">•</span>
                    <span>{selectedWork.subject}</span>
                  </div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <RatingForm
              onSubmit={handleRatingSubmit}
              initialRating={selectedWork?.studentRating}
              initialFeedback={selectedWork?.studentFeedback}
              title=""
              submitLabel="Enviar valoración"
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WorkReviewSystem;
