
import { useState, useCallback } from "react";
import { Search } from "lucide-react";
import { toast } from "sonner";
import { debounce } from "lodash";
import { useLanguage } from "@/contexts/LanguageContext";

const SearchBar = () => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [inputValue, setInputValue] = useState("");
  const { currentLanguage } = useLanguage();

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debouncedSetSearch = useCallback(
    debounce((value: string) => {
      setSearchQuery(value);
    }, 300),
    []
  );

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);
    debouncedSetSearch(value);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      let targetId = "";

      const languageTerms = ["idioma", "language", "traducir", "translate", "lenguaje"];
      const isLanguageSearch = languageTerms.some(term => query.includes(term));

      if (query.includes("precio") || query.includes("costo") || query.includes("tarifa")) {
        targetId = "precios";
      } else if (query.includes("servicio") || query.includes("trabajo") || query.includes("oferta")) {
        targetId = "servicios";
      } else if (query.includes("contacto") || query.includes("comunicar")) {
        targetId = "contacto";
      } else if (query.includes("solicit") || query.includes("pedir")) {
        targetId = "solicitar";
      } else if (query.includes("pregunta") || query.includes("duda") || query.includes("faq")) {
        targetId = "faq";
      } else if (query.includes("garantía") || query.includes("segur")) {
        targetId = "garantias";
      } else if (isLanguageSearch) {
        const translateButton = document.querySelector('button[aria-label="Idioma"]');
        if (translateButton) {
          (translateButton as HTMLButtonElement).click();
          toast.success("Mostrando opciones de idioma");
          setIsSearchOpen(false);
          setInputValue("");
          setSearchQuery("");
          return;
        }
      }

      if (targetId) {
        const element = document.getElementById(targetId);
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "start" });
          toast.success(`Mostrando resultados para "${searchQuery}"`);
        } else {
          toast.error("No se encontraron resultados específicos");
        }
      } else {
        toast.info("Intenta buscar 'precios', 'servicios', 'contacto', 'idioma', etc.");
      }

      setInputValue("");
      setSearchQuery("");
      setIsSearchOpen(false);
    }
  };

  const toggleSearch = () => {
    setIsSearchOpen(!isSearchOpen);
    if (!isSearchOpen) {
      setTimeout(() => {
        document.getElementById("searchInput")?.focus();
      }, 100);
    }
  };

  const getPlaceholderText = () => {
    if (currentLanguage === "es") return "Busca 'precios', 'servicios', 'contacto', 'idioma'...";
    if (currentLanguage === "en") return "Search 'prices', 'services', 'contact', 'language'...";
    return "Search / Buscar...";
  };

  return (
    <>
      <div className={`fixed top-16 w-full bg-background z-40 shadow-md border-b border-border transition-all duration-300 ${isSearchOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'}`}>
        <div className="max-w-3xl mx-auto px-4 py-3">
          <form onSubmit={handleSearch} className="flex items-center">
            <input
              id="searchInput"
              type="text"
              className="flex-grow px-4 py-2 border border-input bg-background text-foreground rounded-l-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
              placeholder={getPlaceholderText()}
              value={inputValue}
              onChange={handleInputChange}
            />
            <button type="submit" className="bg-primary text-primary-foreground px-4 py-2 rounded-r-lg hover:bg-primary/90 transition-colors">
              Buscar
            </button>
          </form>
        </div>
      </div>

      <button
        onClick={toggleSearch}
        className="md:hidden fixed bottom-20 right-5 z-40 bg-primary text-primary-foreground p-3 rounded-full shadow-lg hover:bg-primary/90 transition-all hover:scale-110"
        aria-label="Buscar"
      >
        <Search className="w-5 h-5" />
      </button>
    </>
  );
};

export default SearchBar;
