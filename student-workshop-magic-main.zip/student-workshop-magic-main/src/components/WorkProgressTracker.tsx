import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  MessageSquare,
  RotateCw,
  PenLine,
  ListChecks
} from "lucide-react";
import { useNotificationContext } from "@/components/NotificationProvider";
import { useWorkOrders } from "@/hooks/useWorkOrders";
import { Link } from "react-router-dom";

interface WorkStep {
  id: string;
  title: string;
  description: string;
  status: "pending" | "in_progress" | "completed";
  completedDate?: string;
  notes?: string;
}

const getStatusColor = (status: string) => {
  switch (status) {
    case "created":
    case "pending":
      return "bg-yellow-100 text-yellow-800";
    case "paid":
    case "payment_pending":
      return "bg-blue-100 text-blue-800";
    case "assigned":
    case "in_progress":
      return "bg-indigo-100 text-indigo-800";
    case "review":
      return "bg-purple-100 text-purple-800";
    case "delivered":
    case "completed":
      return "bg-green-100 text-green-800";
    case "revision":
      return "bg-orange-100 text-orange-800";
    case "rejected":
      return "bg-red-100 text-red-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case "created":
    case "pending":
      return <Clock className="h-4 w-4" />;
    case "paid":
    case "assigned":
    case "in_progress":
      return <RotateCw className="h-4 w-4" />;
    case "review":
      return <FileText className="h-4 w-4" />;
    case "delivered":
    case "completed":
      return <CheckCircle className="h-4 w-4" />;
    case "revision":
      return <PenLine className="h-4 w-4" />;
    case "rejected":
      return <XCircle className="h-4 w-4" />;
    default:
      return <Clock className="h-4 w-4" />;
  }
};

const getStatusLabel = (status: string) => {
  switch (status) {
    case "created": return "Recién creado";
    case "payment_pending": return "Pendiente de pago";
    case "paid": return "Pagado";
    case "assigned": return "Asignado";
    case "in_progress": return "En progreso";
    case "review": return "En revisión";
    case "approved": return "Aprobado";
    case "delivered": return "Entregado";
    case "archived": return "Archivado";
    case "rejected": return "Rechazado";
    default: return status;
  }
};

const WorkProgressTracker = () => {
  const { orders, isLoading } = useWorkOrders();
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [isRevisionDialogOpen, setIsRevisionDialogOpen] = useState(false);
  const [revisionRequest, setRevisionRequest] = useState("");
  const { addNotification } = useNotificationContext();

  const selectedOrder = orders.find(o => o.id === selectedOrderId);

  const handleRevisionRequest = () => {
    if (!selectedOrder || !revisionRequest.trim()) return;

    toast.success("Solicitud de revisión enviada", {
      description: "Tu solicitud ha sido registrada y será revisada por el equipo"
    });
    
    addNotification({
      title: "Solicitud de revisión enviada",
      message: `Has solicitado una revisión para el trabajo "${selectedOrder.title}".`,
      type: "info",
      link: "/dashboard?tab=progress"
    });

    setIsRevisionDialogOpen(false);
    setRevisionRequest("");
  };

  const openRevisionDialog = (orderId: string) => {
    setSelectedOrderId(orderId);
    setIsRevisionDialogOpen(true);
  };

  // Calcular progreso basado en el estado
  const calculateProgress = (status: string) => {
    const statusProgress: Record<string, number> = {
      created: 10,
      payment_pending: 15,
      paid: 25,
      assigned: 35,
      in_progress: 60,
      review: 80,
      approved: 90,
      delivered: 100,
      archived: 100,
      rejected: 0
    };
    return statusProgress[status] || 0;
  };


  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
        <p className="mt-4 text-gray-600">Cargando tus trabajos...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-2">Seguimiento de tus Trabajos Académicos</h2>
        <p className="text-gray-600">
          Observa el progreso de tus trabajos y solicita revisiones cuando lo necesites
        </p>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <FileText className="h-12 w-12 mx-auto text-gray-400" />
          <h3 className="mt-4 text-lg font-medium text-gray-900">No tienes trabajos activos</h3>
          <p className="mt-2 text-sm text-gray-500">
            Cuando solicites un trabajo académico, podrás seguir su progreso aquí.
          </p>
          <Button asChild className="mt-4">
            <Link to="/">Solicitar un trabajo</Link>
          </Button>
        </div>
      ) : (
        <div className="grid gap-6">
          {orders.map((order) => (
            <Card key={order.id} className="overflow-hidden">
              <CardHeader className="pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl">{order.title}</CardTitle>
                    <CardDescription className="mt-1">
                      {order.subject} • ID: {order.id.slice(0, 8)}
                    </CardDescription>
                  </div>
                  <span
                    className={`flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}
                  >
                    {getStatusIcon(order.status)}
                    <span className="ml-1">{getStatusLabel(order.status)}</span>
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Progreso del trabajo</span>
                    <span className="text-sm text-gray-500">
                      {calculateProgress(order.status)}%
                    </span>
                  </div>
                  <Progress
                    value={calculateProgress(order.status)}
                    className="h-2"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex items-center text-sm text-gray-500 mb-1">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Fecha de solicitud:</span>
                    </div>
                    <span className="font-medium">
                      {order.createdAt.toLocaleDateString()}
                    </span>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex items-center text-sm text-gray-500 mb-1">
                      <CheckCircle className="h-4 w-4 mr-1" />
                      <span>Fecha límite:</span>
                    </div>
                    <span className="font-medium">
                      {order.deadline.toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {order.description && (
                  <div className="mb-2">
                    <h4 className="text-sm font-medium mb-2">Descripción:</h4>
                    <p className="text-sm text-gray-600">{order.description}</p>
                  </div>
                )}

                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="details">
                    <AccordionTrigger className="text-sm font-medium py-2">
                      Ver detalles adicionales
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2 mt-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Tipo de trabajo:</span>
                          <span>{order.workType}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Nivel académico:</span>
                          <span>{order.academicLevel}</span>
                        </div>
                        {order.wordCount && (
                          <div className="flex justify-between">
                            <span className="text-gray-500">Extensión:</span>
                            <span>{order.wordCount}</span>
                          </div>
                        )}
                        {order.assignedExpertName && (
                          <div className="flex justify-between">
                            <span className="text-gray-500">Experto asignado:</span>
                            <span>{order.assignedExpertName}</span>
                          </div>
                        )}
                        {order.price && (
                          <div className="flex justify-between">
                            <span className="text-gray-500">Precio:</span>
                            <span>${order.price.toLocaleString()} COP</span>
                          </div>
                        )}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
              <CardFooter className="flex justify-between bg-gray-50 py-3">
                <div className="flex items-center text-sm text-gray-500">
                  <ListChecks className="h-4 w-4 mr-1" />
                  <span>Actualizado: {order.updatedAt.toLocaleDateString()}</span>
                </div>
                {order.status !== 'delivered' && order.status !== 'archived' && order.status !== 'rejected' && (
                  <Button
                    variant="outline"
                    className="flex items-center"
                    onClick={() => openRevisionDialog(order.id)}
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Solicitar corrección
                  </Button>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isRevisionDialogOpen} onOpenChange={setIsRevisionDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Solicitar corrección</DialogTitle>
            <DialogDescription>
              Describe específicamente qué aspectos del trabajo necesitan ser corregidos.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Textarea
              placeholder="Necesito que se corrija..."
              value={revisionRequest}
              onChange={(e) => setRevisionRequest(e.target.value)}
              className="min-h-[150px]"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRevisionDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleRevisionRequest} disabled={!revisionRequest.trim()}>
              Enviar solicitud
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WorkProgressTracker;
