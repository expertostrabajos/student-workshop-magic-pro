
import React, { useEffect, useRef } from 'react';
import { useNotificationContext } from './NotificationProvider';
import { toast } from 'sonner';

const NotificationAlert: React.FC = () => {
  const { unreadCount, markAllAsRead } = useNotificationContext();
  const hasShownInitial = useRef(false);

  // Show unread count once on mount only
  useEffect(() => {
    if (hasShownInitial.current) return;
    hasShownInitial.current = true;

    if (unreadCount > 0) {
      toast.info(`Tienes ${unreadCount} notificación${unreadCount > 1 ? 'es' : ''} sin leer`, {
        action: {
          label: "Marcar leídas",
          onClick: () => markAllAsRead()
        },
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return null;
};

export default NotificationAlert;
