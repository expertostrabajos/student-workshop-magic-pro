
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Star, ThumbsUp, User, MessageSquare, Calendar } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface Feedback {
  id: string;
  studentName: string;
  rating: number;
  comment: string;
  date: string;
  workType: string;
  subject: string;
  helpful: number;
}

const mockFeedback: Feedback[] = [
  {
    id: "1",
    studentName: "Carlos M.",
    rating: 5,
    comment: "Excelente trabajo, superó mis expectativas. La estructura y argumentación fueron impecables.",
    date: "2023-05-20",
    workType: "Ensayo",
    subject: "Literatura",
    helpful: 12
  },
  {
    id: "2",
    studentName: "María G.",
    rating: 4,
    comment: "Muy buen trabajo, solo faltaron algunos detalles en las citas bibliográficas.",
    date: "2023-05-18",
    workType: "Investigación",
    subject: "Psicología",
    helpful: 8
  },
  {
    id: "3",
    studentName: "Juan P.",
    rating: 5,
    comment: "Impresionante análisis, me ayudó mucho a entender conceptos complejos de economía.",
    date: "2023-05-15",
    workType: "Tesis",
    subject: "Economía",
    helpful: 15
  },
  {
    id: "4",
    studentName: "Laura B.",
    rating: 4,
    comment: "Trabajo bien desarrollado, cumplió con todos los requisitos solicitados.",
    date: "2023-05-12",
    workType: "Ensayo",
    subject: "Historia",
    helpful: 6
  },
];

const StudentFeedback = () => {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>(mockFeedback);
  const [filter, setFilter] = useState<string>("all");

  const filteredFeedback = filter === "all" 
    ? feedbacks 
    : feedbacks.filter(f => f.workType.toLowerCase() === filter);

  const handleHelpfulClick = (id: string) => {
    setFeedbacks(prev => 
      prev.map(f => 
        f.id === id 
          ? { ...f, helpful: f.helpful + 1 } 
          : f
      )
    );
  };

  const averageRating = feedbacks.reduce((acc, curr) => acc + curr.rating, 0) / feedbacks.length;
  
  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            className={`w-5 h-5 ${
              i < rating
                ? "text-yellow-400 fill-yellow-400"
                : "text-gray-300"
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <Card className="w-full">
      <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <MessageSquare className="w-5 h-5 text-blue-600 mr-2" />
            <span>Valoraciones de Estudiantes</span>
          </div>
          <div className="flex items-center bg-white px-3 py-1 rounded-full border">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400 mr-1" />
            <span className="font-bold text-lg">{averageRating.toFixed(1)}</span>
            <span className="text-gray-500 text-sm ml-1">/5</span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <Tabs defaultValue="all" value={filter} onValueChange={setFilter} className="mb-6">
          <TabsList className="grid grid-cols-4 gap-2 mb-4">
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="ensayo">Ensayos</TabsTrigger>
            <TabsTrigger value="investigacion">Investigación</TabsTrigger>
            <TabsTrigger value="tesis">Tesis</TabsTrigger>
          </TabsList>
          
          <TabsContent value={filter} className="mt-0">
            <div className="space-y-4">
              {filteredFeedback.length > 0 ? (
                filteredFeedback.map((feedback) => (
                  <div key={feedback.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <div className="flex items-start">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-medium mr-3">
                          <User className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center">
                            <h4 className="font-medium text-gray-900">{feedback.studentName}</h4>
                            <div className="flex items-center text-gray-500 text-xs ml-2">
                              <Calendar className="w-3 h-3 mr-1" />
                              {new Date(feedback.date).toLocaleDateString('es-ES', {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric'
                              })}
                            </div>
                          </div>
                          <div className="flex items-center mt-1">
                            {renderStars(feedback.rating)}
                          </div>
                          <div className="mt-2">
                            <p className="text-gray-700">{feedback.comment}</p>
                          </div>
                          <div className="mt-3 flex items-center">
                            <span className="text-xs text-gray-500 mr-2">
                              {feedback.workType} • {feedback.subject}
                            </span>
                            <button 
                              onClick={() => handleHelpfulClick(feedback.id)}
                              className="flex items-center text-xs text-gray-600 hover:text-blue-600 transition-colors"
                            >
                              <ThumbsUp className="w-3 h-3 mr-1" />
                              <span>Útil ({feedback.helpful})</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">
                  No hay valoraciones para mostrar en esta categoría.
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default StudentFeedback;
