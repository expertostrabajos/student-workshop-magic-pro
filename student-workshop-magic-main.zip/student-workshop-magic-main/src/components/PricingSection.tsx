
import { useState, useEffect } from "react";
import PricingCard from "./PricingCard";
import SocialShare from "./SocialShare";
import { Shield } from "lucide-react";

interface PricingPlan {
  title: string;
  price: string;
  features: string[];
  isPopular?: boolean;
}

const PricingSection = () => {
  // In the future, this could be loaded from an API
  const [pricingPlans, setPricingPlans] = useState<PricingPlan[]>([
    {
      title: "Básico",
      price: "$2.500",
      features: [
        "Ensayos cortos",
        "3 días de entrega",
        "1 revisión incluida",
        "Soporte por email",
      ],
    },
    {
      title: "Premium",
      price: "$5.000",
      features: [
        "Trabajos extensos",
        "5 días de entrega",
        "3 revisiones incluidas",
        "Soporte prioritario",
      ],
      isPopular: true,
    },
    {
      title: "Profesional",
      price: "$10.000",
      features: [
        "Proyectos completos",
        "7 días de entrega",
        "Revisiones ilimitadas",
        "Soporte 24/7",
      ],
    },
  ]);

  // This could be uncommented when a real API is available
  // useEffect(() => {
  //   const fetchPricingPlans = async () => {
  //     try {
  //       const response = await fetch('/api/pricing');
  //       if (response.ok) {
  //         const data = await response.json();
  //         setPricingPlans(data);
  //       }
  //     } catch (error) {
  //       console.error("Error fetching pricing plans:", error);
  //     }
  //   };
  //
  //   fetchPricingPlans();
  // }, []);

  return (
    <section id="precios" className="py-12 md:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Precios Transparentes</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Elige el plan que mejor se adapte a tus necesidades académicas.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingPlans.map((plan, index) => (
            <div key={index} className="transform transition duration-500 hover:scale-105">
              <PricingCard {...plan} />
            </div>
          ))}
        </div>
        
        {/* Banner de garantía de precio */}
        <div className="mt-10 bg-green-50 p-4 rounded-lg border border-green-200 max-w-3xl mx-auto">
          <div className="flex items-center justify-center space-x-3">
            <Shield className="w-6 h-6 text-green-500 flex-shrink-0" />
            <p className="text-green-800 text-sm">
              <span className="font-semibold">Garantía de precio:</span> Si encuentras un servicio similar por menos precio, ¡igualaremos la oferta!
            </p>
          </div>
        </div>
        
        <SocialShare section="precios" />
      </div>
    </section>
  );
};

export default PricingSection;
