
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { 
  Smartphone, 
  BookOpen, 
  MessageSquare, 
  Calendar, 
  FileText, 
  Clock, 
  CreditCard, 
  User,
  Bell,
  Home,
  BarChart3,
  Settings,
  ChevronRight,
  Star,
  Bookmark,
  List,
  Gift,
  FileCheck,
  ArrowRight,
  AlertTriangle,
  HelpCircle
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useIsMobile } from "@/hooks/use-mobile";

interface Notification {
  id: string;
  title: string;
  description: string;
  time: string;
  type: "info" | "warning" | "success";
  read: boolean;
}

interface Assignment {
  id: string;
  title: string;
  status: "in_progress" | "reviewing" | "completed" | "pending";
  dueDate: string;
  progress: number;
  type: string;
}

const MobileDashboard = () => {
  const isMobile = useIsMobile();
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      title: "Revisión completada",
      description: "Tu ensayo de literatura ha sido revisado",
      time: "Hace 30 minutos",
      type: "success",
      read: false
    },
    {
      id: "2",
      title: "Mensaje nuevo",
      description: "Has recibido un mensaje de tu escritor asignado",
      time: "Hace 2 horas",
      type: "info",
      read: false
    },
    {
      id: "3",
      title: "Fecha límite próxima",
      description: "Tu proyecto de investigación vence en 3 días",
      time: "Hace 5 horas",
      type: "warning",
      read: true
    }
  ]);
  
  const [assignments, setAssignments] = useState<Assignment[]>([
    {
      id: "1",
      title: "Ensayo de Literatura Comparada",
      status: "in_progress",
      dueDate: "2025-04-15",
      progress: 65,
      type: "Ensayo"
    },
    {
      id: "2",
      title: "Análisis del Impacto Ambiental",
      status: "reviewing",
      dueDate: "2025-04-20",
      progress: 90,
      type: "Investigación"
    },
    {
      id: "3",
      title: "Presentación sobre Energías Renovables",
      status: "completed",
      dueDate: "2025-04-05",
      progress: 100,
      type: "Presentación"
    },
    {
      id: "4",
      title: "Tesis de Maestría en Psicología Clínica",
      status: "pending",
      dueDate: "2025-05-30",
      progress: 20,
      type: "Tesis"
    }
  ]);
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in_progress":
        return <Badge className="bg-blue-500">En progreso</Badge>;
      case "reviewing":
        return <Badge className="bg-yellow-500">En revisión</Badge>;
      case "completed":
        return <Badge className="bg-green-500">Completado</Badge>;
      case "pending":
        return <Badge variant="outline">Pendiente</Badge>;
      default:
        return null;
    }
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "in_progress": return "bg-blue-500";
      case "reviewing": return "bg-yellow-500";
      case "completed": return "bg-green-500";
      case "pending": return "bg-gray-300";
      default: return "bg-gray-300";
    }
  };
  
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "info":
        return <Bell className="h-5 w-5 text-blue-500" />;
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case "success":
        return <FileCheck className="h-5 w-5 text-green-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };
  
  const formatDueDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('es', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    }).format(date);
  };
  
  // Verificar si es mobile y aplicar estilos específicos
  const containerStyles = isMobile 
    ? "pb-16" // Espacio para la navegación en mobile
    : "";

  return (
    <div className={`min-h-screen bg-gray-50 ${containerStyles}`}>
      <div className="max-w-lg mx-auto px-4 py-6">
        {/* Header con perfil de usuario */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Panel Móvil</h1>
            <p className="text-sm text-gray-600">Bienvenido de nuevo</p>
          </div>
          <div className="flex items-center">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
            </Button>
            <Avatar className="ml-2">
              <AvatarImage src="https://i.pravatar.cc/150?img=12" alt="Usuario" />
              <AvatarFallback>US</AvatarFallback>
            </Avatar>
          </div>
        </div>
        
        {/* Resumen rápido */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Card>
            <CardContent className="p-3 flex flex-col items-center justify-center">
              <div className="bg-blue-100 rounded-full p-2 mb-2">
                <FileText className="h-5 w-5 text-blue-600" />
              </div>
              <p className="text-sm font-medium">Trabajos Activos</p>
              <p className="text-xl font-bold text-blue-600">3</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 flex flex-col items-center justify-center">
              <div className="bg-green-100 rounded-full p-2 mb-2">
                <FileCheck className="h-5 w-5 text-green-600" />
              </div>
              <p className="text-sm font-medium">Completados</p>
              <p className="text-xl font-bold text-green-600">12</p>
            </CardContent>
          </Card>
        </div>
        
        {/* Trabajos en curso */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-medium">Trabajos en Curso</h2>
            <Button variant="ghost" size="sm" className="text-blue-600" asChild>
              <Link to="/dashboard">
                Ver todos <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </Button>
          </div>
          <div className="space-y-3">
            {assignments.slice(0, 2).map(assignment => (
              <Card key={assignment.id} className="overflow-hidden">
                <CardContent className="p-3">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-medium text-gray-900">{assignment.title}</h3>
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <p className="mr-2">{assignment.type}</p>
                        <p>Entrega: {formatDueDate(assignment.dueDate)}</p>
                      </div>
                    </div>
                    {getStatusBadge(assignment.status)}
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-xs text-gray-500">Progreso</span>
                      <span className="text-xs font-medium">{assignment.progress}%</span>
                    </div>
                    <Progress value={assignment.progress} className={`h-2 ${getStatusColor(assignment.status)}`} />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        
        {/* Notificaciones recientes */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-medium">Notificaciones</h2>
            <Button variant="ghost" size="sm" className="text-blue-600">
              Marcar todas como leídas
            </Button>
          </div>
          <div className="space-y-3">
            {notifications.map(notification => (
              <Card key={notification.id} className={`overflow-hidden ${!notification.read ? 'border-l-4 border-l-blue-500' : ''}`}>
                <CardContent className="p-3">
                  <div className="flex items-start">
                    <div className="mr-3 mt-1">
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900 text-sm">{notification.title}</h3>
                      <p className="text-xs text-gray-600 mt-1">{notification.description}</p>
                      <p className="text-xs text-gray-400 mt-1">{notification.time}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        
        {/* Acceso rápido */}
        <div className="mb-6">
          <h2 className="text-lg font-medium mb-3">Acceso Rápido</h2>
          <div className="grid grid-cols-3 gap-3">
            <Link to="/document-library">
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-3 flex flex-col items-center text-center">
                  <BookOpen className="h-6 w-6 text-blue-500 mb-1" />
                  <span className="text-xs">Biblioteca</span>
                </CardContent>
              </Card>
            </Link>
            <Link to="#">
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-3 flex flex-col items-center text-center">
                  <MessageSquare className="h-6 w-6 text-green-500 mb-1" />
                  <span className="text-xs">Mensajes</span>
                </CardContent>
              </Card>
            </Link>
            <Link to="#">
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-3 flex flex-col items-center text-center">
                  <Calendar className="h-6 w-6 text-purple-500 mb-1" />
                  <span className="text-xs">Calendario</span>
                </CardContent>
              </Card>
            </Link>
            <Link to="#">
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-3 flex flex-col items-center text-center">
                  <Clock className="h-6 w-6 text-amber-500 mb-1" />
                  <span className="text-xs">Historial</span>
                </CardContent>
              </Card>
            </Link>
            <Link to="#">
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-3 flex flex-col items-center text-center">
                  <CreditCard className="h-6 w-6 text-red-500 mb-1" />
                  <span className="text-xs">Pagos</span>
                </CardContent>
              </Card>
            </Link>
            <Link to="#">
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-3 flex flex-col items-center text-center">
                  <Settings className="h-6 w-6 text-gray-500 mb-1" />
                  <span className="text-xs">Ajustes</span>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
        
        {/* Banner promocional */}
        <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white mb-6">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-bold text-lg mb-1">¡Gana descuento!</h3>
                <p className="text-sm opacity-90 mb-3">Recomienda a un amigo y obtén un 15% de descuento</p>
                <Button size="sm" variant="secondary">
                  <Gift className="h-4 w-4 mr-1" />
                  Invitar ahora
                </Button>
              </div>
              <Gift className="h-10 w-10 opacity-80" />
            </div>
          </CardContent>
        </Card>
        
        {/* Ayuda y soporte */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex items-center">
              <HelpCircle className="h-6 w-6 text-blue-500 mr-3" />
              <div className="flex-1">
                <h3 className="font-medium text-sm">¿Necesitas ayuda?</h3>
                <p className="text-xs text-gray-500">Nuestro equipo está disponible 24/7</p>
              </div>
              <Button size="sm" variant="outline">Contactar</Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Barra de navegación inferior (solo en mobile) */}
        {isMobile && (
          <div className="fixed bottom-0 left-0 right-0 bg-white border-t z-10">
            <div className="flex justify-around items-center p-2">
              <Link to="/" className="flex flex-col items-center p-2">
                <Home className="h-5 w-5 text-blue-600" />
                <span className="text-xs mt-1">Inicio</span>
              </Link>
              <Link to="#" className="flex flex-col items-center p-2">
                <List className="h-5 w-5 text-gray-500" />
                <span className="text-xs mt-1">Trabajos</span>
              </Link>
              <Link to="#" className="flex flex-col items-center p-2">
                <MessageSquare className="h-5 w-5 text-gray-500" />
                <span className="text-xs mt-1">Chat</span>
              </Link>
              <Link to="#" className="flex flex-col items-center p-2">
                <Bookmark className="h-5 w-5 text-gray-500" />
                <span className="text-xs mt-1">Guardados</span>
              </Link>
              <Link to="#" className="flex flex-col items-center p-2">
                <User className="h-5 w-5 text-gray-500" />
                <span className="text-xs mt-1">Perfil</span>
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MobileDashboard;
