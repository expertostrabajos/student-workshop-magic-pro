
import { useState } from "react";
import { Star } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";

interface RatingFormProps {
  onSubmit: (rating: number, feedback: string) => void;
  initialRating?: number;
  initialFeedback?: string;
  title?: string;
  submitLabel?: string;
}

const RatingForm = ({
  onSubmit,
  initialRating = 0,
  initialFeedback = "",
  title = "Calificar Trabajo Académico",
  submitLabel = "Enviar Calificación"
}: RatingFormProps) => {
  const [rating, setRating] = useState(initialRating);
  const [feedback, setFeedback] = useState(initialFeedback);
  const [hoveredRating, setHoveredRating] = useState(0);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(rating, feedback);
  };

  const getRatingLabel = (currentRating: number): string => {
    if (currentRating === 0) return "Sin calificar";
    if (currentRating === 1) return "Deficiente";
    if (currentRating === 2) return "Insuficiente";
    if (currentRating === 3) return "Regular";
    if (currentRating === 4) return "Bueno";
    return "Excelente";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="mb-4">
            <label className="text-sm font-medium text-gray-700 mb-1 block">
              Valoración
            </label>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="focus:outline-none transition-colors"
                >
                  <Star
                    className={`w-8 h-8 ${
                      (hoveredRating ? hoveredRating >= star : rating >= star)
                        ? "text-yellow-400 fill-yellow-400"
                        : "text-gray-300"
                    }`}
                  />
                </button>
              ))}
              <span className="ml-2 text-sm font-medium">
                {getRatingLabel(hoveredRating || rating)}
              </span>
            </div>
          </div>

          <div>
            <label htmlFor="feedback" className="text-sm font-medium text-gray-700 mb-1 block">
              Comentarios
            </label>
            <Textarea
              id="feedback"
              placeholder="Escribe tus comentarios o sugerencias aquí..."
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              rows={4}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit">{submitLabel}</Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default RatingForm;
