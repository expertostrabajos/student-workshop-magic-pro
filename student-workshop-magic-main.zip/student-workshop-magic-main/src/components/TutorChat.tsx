
import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  Send, 
  Paperclip, 
  User, 
  Users, 
  Clock, 
  PhoneCall, 
  Video,
  MoreVertical,
  Search,
  FileText,
  Image as ImageIcon,
  PaperclipIcon
} from "lucide-react";
import { toast } from "sonner";

interface ChatMessage {
  id: string;
  sender: "user" | "tutor";
  content: string;
  timestamp: Date;
  read: boolean;
  attachment?: {
    type: "document" | "image";
    name: string;
    url: string;
  };
}

interface Tutor {
  id: string;
  name: string;
  avatar?: string;
  expertise: string[];
  status: "online" | "offline" | "busy";
  lastActive?: Date;
}

const TutorChat = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      sender: "tutor",
      content: "¡Hola! Soy Maria, tutora especializada en literatura. ¿En qué puedo ayudarte hoy?",
      timestamp: new Date(2025, 3, 8, 10, 30),
      read: true
    },
    {
      id: "2",
      sender: "user",
      content: "Hola Maria, estoy teniendo problemas con mi ensayo sobre García Márquez.",
      timestamp: new Date(2025, 3, 8, 10, 32),
      read: true
    },
    {
      id: "3",
      sender: "tutor",
      content: "Entiendo. ¿Podrías darme más detalles sobre qué aspectos te están resultando difíciles?",
      timestamp: new Date(2025, 3, 8, 10, 33),
      read: true
    },
    {
      id: "4",
      sender: "user",
      content: "No estoy seguro de cómo estructurar el análisis del realismo mágico en sus obras.",
      timestamp: new Date(2025, 3, 8, 10, 35),
      read: true
    },
    {
      id: "5",
      sender: "tutor",
      content: "Excelente pregunta. El realismo mágico se puede analizar desde varias perspectivas. Te recomendaría comenzar identificando los elementos sobrenaturales que aparecen como cotidianos en sus obras, especialmente en 'Cien años de soledad'. Luego, puedes contrastar cómo estos elementos reflejan la realidad latinoamericana.",
      timestamp: new Date(2025, 3, 8, 10, 38),
      read: true
    }
  ]);
  
  const [tutors, setTutors] = useState<Tutor[]>([
    {
      id: "1",
      name: "Maria Sánchez",
      expertise: ["Literatura", "Historia"],
      status: "online",
      avatar: "https://i.pravatar.cc/150?img=29"
    },
    {
      id: "2",
      name: "Carlos Rodríguez",
      expertise: ["Matemáticas", "Física"],
      status: "online",
      avatar: "https://i.pravatar.cc/150?img=59"
    },
    {
      id: "3",
      name: "Ana Martínez",
      expertise: ["Biología", "Química"],
      status: "busy",
      avatar: "https://i.pravatar.cc/150?img=5"
    },
    {
      id: "4",
      name: "Javier López",
      expertise: ["Economía", "Estadística"],
      status: "offline",
      lastActive: new Date(2025, 3, 7, 15, 20),
      avatar: "https://i.pravatar.cc/150?img=68"
    }
  ]);
  
  const [selectedTutor, setSelectedTutor] = useState<Tutor>(tutors[0]);
  const [newMessage, setNewMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState("chats");
  const [searchQuery, setSearchQuery] = useState("");
  
  // Auto scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  // Filter tutors based on search query
  const filteredTutors = tutors.filter(tutor => 
    tutor.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    tutor.expertise.some(e => e.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  const sendMessage = () => {
    if (!newMessage.trim()) return;
    
    // Add user message
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: "user",
      content: newMessage,
      timestamp: new Date(),
      read: true
    };
    
    setMessages([...messages, userMessage]);
    setNewMessage("");
    
    // Simulate "typing" indicator
    setIsTyping(true);
    
    // Simulate tutor response after delay
    setTimeout(() => {
      const tutorResponses = [
        "Esa es una excelente pregunta. Déjame ayudarte con eso.",
        "Entiendo tu duda. Basándome en mi experiencia, te recomendaría enfocarte en los siguientes puntos...",
        "Comprendo el problema. Vamos a abordarlo paso a paso.",
        "Buena observación. La clave para resolver esto es analizar el contexto histórico.",
        "Interesante planteamiento. Te sugiero revisar estas fuentes adicionales para profundizar en el tema."
      ];
      
      const randomResponse = tutorResponses[Math.floor(Math.random() * tutorResponses.length)];
      
      const tutorMessage: ChatMessage = {
        id: `tutor-${Date.now()}`,
        sender: "tutor",
        content: randomResponse,
        timestamp: new Date(),
        read: false
      };
      
      setIsTyping(false);
      setMessages(prev => [...prev, tutorMessage]);
      
      toast.success("Nuevo mensaje del tutor");
    }, 1500 + Math.random() * 2000);
  };
  
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };
  
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const getStatusIndicator = (status: string) => {
    switch(status) {
      case "online":
        return <div className="w-3 h-3 bg-green-500 rounded-full"></div>;
      case "busy":
        return <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>;
      case "offline":
        return <div className="w-3 h-3 bg-gray-400 rounded-full"></div>;
      default:
        return null;
    }
  };
  
  return (
    <div className="w-full max-w-6xl mx-auto">
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Chat con Tutores</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="grid grid-cols-1 md:grid-cols-4 h-[600px]">
            <div className="md:col-span-1 border-r">
              <Tabs defaultValue="chats" value={activeTab} onValueChange={setActiveTab}>
                <div className="px-4 py-2 border-b">
                  <TabsList className="grid grid-cols-2 w-full">
                    <TabsTrigger value="chats">Chats</TabsTrigger>
                    <TabsTrigger value="tutors">Tutores</TabsTrigger>
                  </TabsList>
                </div>
                
                <div className="p-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Buscar..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                
                <TabsContent value="chats" className="m-0 overflow-auto h-[480px]">
                  <div className="space-y-1 p-2">
                    {tutors.slice(0, 3).map((tutor) => (
                      <div 
                        key={tutor.id}
                        className={`flex items-center space-x-3 px-3 py-2 rounded-md cursor-pointer ${
                          selectedTutor.id === tutor.id ? 'bg-gray-100' : 'hover:bg-gray-50'
                        }`}
                        onClick={() => setSelectedTutor(tutor)}
                      >
                        <div className="relative">
                          <Avatar>
                            <AvatarImage src={tutor.avatar} />
                            <AvatarFallback>{tutor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                          </Avatar>
                          <span className="absolute bottom-0 right-0">
                            {getStatusIndicator(tutor.status)}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-center">
                            <p className="text-sm font-medium truncate">{tutor.name}</p>
                            <span className="text-xs text-gray-500">12:30</span>
                          </div>
                          <p className="text-xs text-gray-500 truncate">
                            {tutor.id === "1" ? "¿En qué puedo ayudarte hoy?" : "Último mensaje..."}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                <TabsContent value="tutors" className="m-0 overflow-auto h-[480px]">
                  <div className="space-y-1 p-2">
                    {filteredTutors.map((tutor) => (
                      <div 
                        key={tutor.id}
                        className="flex items-center space-x-3 px-3 py-2 rounded-md cursor-pointer hover:bg-gray-50"
                        onClick={() => {
                          setSelectedTutor(tutor);
                          setActiveTab("chats");
                        }}
                      >
                        <div className="relative">
                          <Avatar>
                            <AvatarImage src={tutor.avatar} />
                            <AvatarFallback>{tutor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                          </Avatar>
                          <span className="absolute bottom-0 right-0">
                            {getStatusIndicator(tutor.status)}
                          </span>
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{tutor.name}</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {tutor.expertise.map((skill, i) => (
                              <Badge key={i} variant="outline" className="text-xs py-0">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
            
            <div className="md:col-span-3 flex flex-col">
              {/* Chat header */}
              <div className="px-6 py-3 border-b flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar>
                      <AvatarImage src={selectedTutor.avatar} />
                      <AvatarFallback>{selectedTutor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <span className="absolute bottom-0 right-0">
                      {getStatusIndicator(selectedTutor.status)}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium">{selectedTutor.name}</p>
                    <div className="flex items-center text-xs text-gray-500">
                      {selectedTutor.status === "online" ? (
                        <span>En línea</span>
                      ) : selectedTutor.status === "busy" ? (
                        <span>Ocupado</span>
                      ) : (
                        <span>Última vez activo hace 2h</span>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="icon">
                    <PhoneCall className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              {/* Chat messages */}
              <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div 
                      key={message.id}
                      className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                    >
                      {message.sender === "tutor" && (
                        <Avatar className="mr-2 flex-shrink-0 self-end mb-1">
                          <AvatarImage src={selectedTutor.avatar} />
                          <AvatarFallback>{selectedTutor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                      )}
                      <div 
                        className={`max-w-[70%] rounded-lg px-4 py-2 ${
                          message.sender === "user" 
                            ? "bg-blue-500 text-white" 
                            : "bg-white border text-gray-800"
                        }`}
                      >
                        {message.content}
                        {message.attachment && (
                          <div className={`mt-2 p-2 rounded-md ${
                            message.sender === "user" ? "bg-blue-600" : "bg-gray-100"
                          }`}>
                            <div className="flex items-center">
                              {message.attachment.type === "document" ? (
                                <FileText className="h-4 w-4 mr-2" />
                              ) : (
                                <ImageIcon className="h-4 w-4 mr-2" />
                              )}
                              <span className="text-sm truncate">{message.attachment.name}</span>
                            </div>
                          </div>
                        )}
                        <div 
                          className={`text-xs mt-1 ${
                            message.sender === "user" ? "text-blue-100" : "text-gray-500"
                          }`}
                        >
                          {formatTime(message.timestamp)}
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {isTyping && (
                    <div className="flex justify-start">
                      <Avatar className="mr-2 flex-shrink-0 self-end mb-1">
                        <AvatarImage src={selectedTutor.avatar} />
                        <AvatarFallback>{selectedTutor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="bg-white border text-gray-800 max-w-[70%] rounded-lg px-4 py-2">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce"></div>
                          <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                          <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: "0.4s" }}></div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div ref={messagesEndRef} />
                </div>
              </div>
              
              {/* Input area */}
              <div className="px-4 py-3 border-t bg-white">
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="icon">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Input
                    placeholder="Escribe un mensaje..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={handleKeyPress}
                    className="flex-1"
                  />
                  <Button
                    disabled={!newMessage.trim()}
                    onClick={sendMessage}
                    size="icon"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TutorChat;
