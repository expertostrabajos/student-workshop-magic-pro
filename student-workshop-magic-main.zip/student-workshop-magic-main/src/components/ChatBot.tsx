import { useState, useEffect, useRef, useCallback } from "react";
import { Send, X, Minimize2, Maximize2, RefreshCcw, Sparkles, Bot, GraduationCap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";
import { motion, AnimatePresence } from "framer-motion";

interface ChatMessage {
  text: string;
  sender: "user" | "bot";
  isAIGenerated?: boolean;
}

type AIMessage = { role: "user" | "assistant"; content: string };

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/academic-chat`;

const QUICK_PROMPTS = [
  { label: "📚 Precios", message: "¿Cuáles son los precios de los servicios?" },
  { label: "💳 Pago Nequi", message: "¿Cómo pago con Nequi?" },
  { label: "📝 Solicitar trabajo", message: "Quiero solicitar un trabajo académico" },
  { label: "🧠 Ayuda con tarea", message: "Necesito ayuda con una tarea" },
];

const ChatBot = () => {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      text: "¡Hola! 👋 Soy tu **asistente académico con IA** de StudentHelp. Puedo ayudarte con:\n\n- 📖 Preguntas de cualquier materia\n- ✍️ Estructurar trabajos y ensayos\n- 🧮 Resolver ejercicios paso a paso\n- 💡 Consejos de estudio\n\n¿En qué puedo ayudarte hoy?",
      sender: "bot",
      isAIGenerated: true,
    },
  ]);
  const [aiConversation, setAiConversation] = useState<AIMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isMinimized, setIsMinimized] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const toggleChat = () => {
    setIsOpen(!isOpen);
    if (!isOpen) setIsMinimized(false);
  };

  const generateAIResponse = useCallback(async (userMessage: string, conversationHistory: AIMessage[]) => {
    setIsStreaming(true);

    const newUserMessage: AIMessage = { role: "user", content: userMessage };
    const updatedHistory = [...conversationHistory, newUserMessage];
    setAiConversation(updatedHistory);

    let assistantContent = "";

    try {
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ messages: updatedHistory }),
      });

      if (!resp.ok) {
        const errorData = await resp.json().catch(() => ({}));
        if (resp.status === 429) {
          throw new Error("Demasiadas solicitudes. Intenta en unos segundos.");
        }
        if (resp.status === 402) {
          throw new Error("Servicio temporalmente no disponible.");
        }
        throw new Error(errorData.error || `Error ${resp.status}`);
      }

      if (!resp.body) throw new Error("No response body");

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = "";

      setMessages(prev => [...prev, { text: "", sender: "bot", isAIGenerated: true }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        textBuffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          let line = textBuffer.slice(0, newlineIndex);
          textBuffer = textBuffer.slice(newlineIndex + 1);

          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) {
              assistantContent += content;
              setMessages(prev => {
                const updated = [...prev];
                const lastIndex = updated.length - 1;
                if (lastIndex >= 0 && updated[lastIndex].sender === "bot") {
                  updated[lastIndex] = { ...updated[lastIndex], text: assistantContent };
                }
                return updated;
              });
            }
          } catch {
            textBuffer = line + "\n" + textBuffer;
            break;
          }
        }
      }

      // Flush remaining buffer
      if (textBuffer.trim()) {
        for (let raw of textBuffer.split("\n")) {
          if (!raw) continue;
          if (raw.endsWith("\r")) raw = raw.slice(0, -1);
          if (raw.startsWith(":") || raw.trim() === "") continue;
          if (!raw.startsWith("data: ")) continue;
          const jsonStr = raw.slice(6).trim();
          if (jsonStr === "[DONE]") continue;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) {
              assistantContent += content;
              setMessages(prev => {
                const updated = [...prev];
                const lastIndex = updated.length - 1;
                if (lastIndex >= 0 && updated[lastIndex].sender === "bot") {
                  updated[lastIndex] = { ...updated[lastIndex], text: assistantContent };
                }
                return updated;
              });
            }
          } catch { /* ignore */ }
        }
      }

      setAiConversation(prev => [...prev, { role: "assistant", content: assistantContent }]);
    } catch (error) {
      console.error("Error AI:", error);
      const errorMessage = error instanceof Error ? error.message : "Error desconocido";

      toast({ title: "Error", description: errorMessage, variant: "destructive" });

      setMessages(prev => {
        const updated = [...prev];
        const lastIndex = updated.length - 1;
        if (lastIndex >= 0 && updated[lastIndex].sender === "bot" && updated[lastIndex].text === "") {
          updated[lastIndex] = {
            text: "Lo siento, tuve un problema. ¿Puedes intentar de nuevo?",
            sender: "bot",
            isAIGenerated: false,
          };
        }
        return updated;
      });
    } finally {
      setIsStreaming(false);
    }
  }, [toast]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim() === "" || isStreaming) return;

    const userMessageText = newMessage.trim();
    setMessages(prev => [...prev, { text: userMessageText, sender: "user" }]);
    setNewMessage("");
    generateAIResponse(userMessageText, aiConversation);
  };

  const handleQuickPrompt = (message: string) => {
    if (isStreaming) return;
    setMessages(prev => [...prev, { text: message, sender: "user" }]);
    generateAIResponse(message, aiConversation);
  };

  const resetConversation = () => {
    setMessages([
      {
        text: "¡Hola! 👋 Soy tu **asistente académico con IA** de StudentHelp. Puedo ayudarte con:\n\n- 📖 Preguntas de cualquier materia\n- ✍️ Estructurar trabajos y ensayos\n- 🧮 Resolver ejercicios paso a paso\n- 💡 Consejos de estudio\n\n¿En qué puedo ayudarte hoy?",
        sender: "bot",
        isAIGenerated: true,
      },
    ]);
    setAiConversation([]);
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (isOpen && !isMinimized) {
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [isOpen, isMinimized]);

  return (
    <>
      {/* Floating button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleChat}
            className="fixed bottom-5 right-5 bg-primary text-primary-foreground p-4 rounded-full shadow-2xl z-40 group"
            aria-label="Abrir asistente de IA"
          >
            <div className="relative">
              <GraduationCap className="h-6 w-6" />
              <span className="absolute -top-1 -right-1 h-3 w-3 bg-green-400 rounded-full border-2 border-primary animate-pulse" />
            </div>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className={`fixed right-4 bottom-4 rounded-2xl shadow-2xl overflow-hidden z-50 border border-border bg-background ${
              isMinimized ? "w-72 h-14" : "w-[360px] sm:w-[400px] h-[560px]"
            }`}
          >
            {/* Header */}
            <div className="bg-primary text-primary-foreground px-4 py-3 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="bg-primary-foreground/20 p-1.5 rounded-lg">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div>
                  <span className="font-semibold text-sm">Asistente IA</span>
                  <div className="flex items-center gap-1 text-xs opacity-80">
                    <span className="h-1.5 w-1.5 bg-green-400 rounded-full" />
                    GPT-5 · En línea
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={resetConversation} className="p-1.5 hover:bg-primary-foreground/10 rounded-lg transition" title="Nueva conversación">
                  <RefreshCcw className="h-4 w-4" />
                </button>
                <button onClick={() => setIsMinimized(!isMinimized)} className="p-1.5 hover:bg-primary-foreground/10 rounded-lg transition">
                  {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
                </button>
                <button onClick={toggleChat} className="p-1.5 hover:bg-primary-foreground/10 rounded-lg transition">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {!isMinimized && (
              <>
                {/* Messages */}
                <div className="flex-1 p-4 overflow-y-auto bg-muted/30" style={{ height: "calc(560px - 56px - 120px)" }}>
                  {messages.map((msg, index) => (
                    <div key={index} className={`mb-4 flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                      {msg.sender === "bot" && (
                        <div className="flex-shrink-0 mr-2 mt-1">
                          <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center">
                            <Bot className="h-4 w-4 text-primary" />
                          </div>
                        </div>
                      )}
                      <div
                        className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                          msg.sender === "user"
                            ? "bg-primary text-primary-foreground rounded-br-md"
                            : "bg-card border border-border text-card-foreground rounded-bl-md shadow-sm"
                        }`}
                      >
                        {msg.sender === "bot" ? (
                          <div className="prose prose-sm dark:prose-invert max-w-none [&_p]:mb-2 [&_p:last-child]:mb-0 [&_ul]:mb-2 [&_ol]:mb-2 [&_li]:mb-0.5">
                            <ReactMarkdown>{msg.text}</ReactMarkdown>
                          </div>
                        ) : (
                          msg.text
                        )}
                      </div>
                    </div>
                  ))}

                  {isStreaming && messages[messages.length - 1]?.text === "" && (
                    <div className="flex items-center gap-2 text-muted-foreground text-xs ml-9">
                      <div className="flex gap-1">
                        <span className="h-2 w-2 bg-primary/50 rounded-full animate-bounce" />
                        <span className="h-2 w-2 bg-primary/50 rounded-full animate-bounce [animation-delay:150ms]" />
                        <span className="h-2 w-2 bg-primary/50 rounded-full animate-bounce [animation-delay:300ms]" />
                      </div>
                      Pensando...
                    </div>
                  )}

                  <div ref={messagesEndRef} />
                </div>

                {/* Quick prompts + Input */}
                <div className="border-t border-border bg-background p-3">
                  {messages.length <= 1 && (
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {QUICK_PROMPTS.map((prompt, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => handleQuickPrompt(prompt.message)}
                          className="text-xs bg-muted hover:bg-accent text-muted-foreground hover:text-accent-foreground px-2.5 py-1.5 rounded-full transition-colors"
                          disabled={isStreaming}
                        >
                          {prompt.label}
                        </button>
                      ))}
                    </div>
                  )}

                  <form onSubmit={handleSubmit} className="flex gap-2">
                    <input
                      ref={inputRef}
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Escribe tu pregunta..."
                      className="flex-1 px-3 py-2 text-sm rounded-xl border border-input bg-background focus:outline-none focus:ring-2 focus:ring-primary/50 placeholder:text-muted-foreground"
                      disabled={isStreaming}
                    />
                    <button
                      type="submit"
                      className="bg-primary text-primary-foreground p-2.5 rounded-xl hover:bg-primary/90 transition disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={isStreaming || !newMessage.trim()}
                    >
                      <Send className="h-4 w-4" />
                    </button>
                  </form>
                  <p className="text-[10px] text-muted-foreground text-center mt-2">
                    Impulsado por GPT-5 · Puede cometer errores
                  </p>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default ChatBot;
