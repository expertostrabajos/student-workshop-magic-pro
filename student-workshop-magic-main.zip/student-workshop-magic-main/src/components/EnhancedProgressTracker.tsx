import { useState, useEffect } from "react";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Calendar } from "@/components/ui/calendar";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  BookOpen,
  BarChart,
  ArrowRight,
  UserCheck,
  FileCheck,
  Eye,
  Lightbulb,
  ThumbsUp,
  Flag,
  Calendar as CalendarIcon,
  CheckCircle2,
  CircleDashed,
  Award,
  MessageSquare,
  Download
} from "lucide-react";
import { toast } from "sonner";
import RatingForm from "@/components/RatingForm";

interface WorkPhase {
  id: string;
  name: string;
  status: "pending" | "in_progress" | "completed" | "review";
  progress: number;
  startDate?: Date;
  endDate?: Date;
  description: string;
  milestones: Milestone[];
}

interface Milestone {
  id: string;
  name: string;
  completed: boolean;
  dueDate?: Date;
}

interface WorkProject {
  id: string;
  title: string;
  subject: string;
  type: string;
  deadline: Date;
  status: "pending" | "in_progress" | "review" | "completed";
  progress: number;
  assignedTo: string;
  phases: WorkPhase[];
  lastUpdate: Date;
}

const EnhancedProgressTracker = () => {
  const [activeProject, setActiveProject] = useState<WorkProject>({
    id: "proj1",
    title: "Análisis del Impacto Ambiental en Zonas Urbanas",
    subject: "Ciencias Ambientales",
    type: "Ensayo Investigativo",
    deadline: new Date(2025, 4, 20),
    status: "in_progress",
    progress: 65,
    assignedTo: "Carlos Rodríguez",
    phases: [
      {
        id: "phase1",
        name: "Investigación y Recopilación",
        status: "completed",
        progress: 100,
        startDate: new Date(2025, 3, 1),
        endDate: new Date(2025, 3, 10),
        description: "Investigación de fuentes y recopilación de datos relevantes.",
        milestones: [
          { id: "m1", name: "Búsqueda inicial de fuentes académicas", completed: true },
          { id: "m2", name: "Selección de datos estadísticos relevantes", completed: true },
          { id: "m3", name: "Organización de material bibliográfico", completed: true }
        ]
      },
      {
        id: "phase2",
        name: "Análisis de Datos",
        status: "completed",
        progress: 100,
        startDate: new Date(2025, 3, 11),
        endDate: new Date(2025, 3, 22),
        description: "Análisis detallado de los datos recopilados.",
        milestones: [
          { id: "m4", name: "Categorización de factores ambientales", completed: true },
          { id: "m5", name: "Interpretación de tendencias estadísticas", completed: true },
          { id: "m6", name: "Desarrollo de hipótesis preliminares", completed: true }
        ]
      },
      {
        id: "phase3",
        name: "Redacción Inicial",
        status: "in_progress",
        progress: 75,
        startDate: new Date(2025, 3, 23),
        endDate: new Date(2025, 4, 5),
        description: "Primera redacción del documento completo.",
        milestones: [
          { id: "m7", name: "Elaboración de estructura y esquema", completed: true },
          { id: "m8", name: "Redacción de introducción y marco teórico", completed: true },
          { id: "m9", name: "Desarrollo del cuerpo del ensayo", completed: false }
        ]
      },
      {
        id: "phase4",
        name: "Revisión y Correcciones",
        status: "pending",
        progress: 0,
        startDate: new Date(2025, 4, 6),
        endDate: new Date(2025, 4, 15),
        description: "Revisión por pares y correcciones finales.",
        milestones: [
          { id: "m10", name: "Revisión de coherencia y cohesión", completed: false },
          { id: "m11", name: "Verificación de citas y referencias", completed: false },
          { id: "m12", name: "Corrección de estilo y formato", completed: false }
        ]
      },
      {
        id: "phase5",
        name: "Finalización y Entrega",
        status: "pending",
        progress: 0,
        startDate: new Date(2025, 4, 16),
        endDate: new Date(2025, 4, 20),
        description: "Últimos ajustes y entrega final del trabajo.",
        milestones: [
          { id: "m13", name: "Revisión final del documento", completed: false },
          { id: "m14", name: "Formateo según normas requeridas", completed: false },
          { id: "m15", name: "Entrega y confirmación de recepción", completed: false }
        ]
      }
    ],
    lastUpdate: new Date(2025, 3, 28)
  });
  
  const [showRatingDialog, setShowRatingDialog] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [projectHistory, setProjectHistory] = useState<{date: Date, action: string, details: string}[]>([
    {
      date: new Date(2025, 3, 1),
      action: "Proyecto iniciado",
      details: "Se ha asignado el proyecto y comenzado la fase de investigación."
    },
    {
      date: new Date(2025, 3, 10),
      action: "Fase completada",
      details: "Fase de 'Investigación y Recopilación' finalizada satisfactoriamente."
    },
    {
      date: new Date(2025, 3, 22),
      action: "Fase completada",
      details: "Fase de 'Análisis de Datos' finalizada satisfactoriamente."
    },
    {
      date: new Date(2025, 3, 23),
      action: "Fase iniciada",
      details: "Se ha comenzado la 'Redacción Inicial' del trabajo."
    },
    {
      date: new Date(2025, 3, 28),
      action: "Actualización de progreso",
      details: "75% de avance en la fase de 'Redacción Inicial'."
    }
  ]);
  
  const today = new Date();
  const daysRemaining = Math.max(0, Math.ceil((activeProject.deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-gray-100 text-gray-800">Pendiente</Badge>;
      case "in_progress":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">En Progreso</Badge>;
      case "review":
        return <Badge variant="outline" className="bg-purple-100 text-purple-800">En Revisión</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800">Completado</Badge>;
      default:
        return null;
    }
  };
  
  const progressColor = (progress: number) => {
    if (progress < 25) return "bg-red-500";
    if (progress < 50) return "bg-yellow-500";
    if (progress < 75) return "bg-blue-500";
    return "bg-green-500";
  };
  
  const handleMilestoneToggle = (phaseId: string, milestoneId: string) => {
    const updatedProject = { ...activeProject };
    const phase = updatedProject.phases.find(p => p.id === phaseId);
    
    if (phase) {
      const milestone = phase.milestones.find(m => m.id === milestoneId);
      if (milestone) {
        milestone.completed = !milestone.completed;
        
        const completedMilestones = phase.milestones.filter(m => m.completed).length;
        phase.progress = Math.round((completedMilestones / phase.milestones.length) * 100);
        
        if (phase.progress === 100) {
          phase.status = "completed";
          setProjectHistory([
            ...projectHistory,
            {
              date: new Date(),
              action: "Hito completado",
              details: `Hito "${milestone.name}" marcado como completado.`
            }
          ]);
          toast.success(`¡Hito "${milestone.name}" completado!`);
        } else if (phase.progress > 0) {
          phase.status = "in_progress";
        }
        
        const totalProgress = updatedProject.phases.reduce((sum, phase) => sum + phase.progress, 0);
        updatedProject.progress = Math.round(totalProgress / updatedProject.phases.length);
        
        setActiveProject(updatedProject);
      }
    }
  };
  
  const handleRatingSubmit = (rating: number, feedback: string) => {
    toast.success(`¡Gracias por tu valoración de ${rating} estrellas!`);
    setShowRatingDialog(false);
    
    console.log("Rating submitted:", { rating, feedback });
  };
  
  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-bold">{activeProject.title}</h2>
        <div className="flex flex-wrap items-center gap-2 mt-2">
          <Badge variant="secondary">{activeProject.subject}</Badge>
          <Badge variant="outline">{activeProject.type}</Badge>
          {getStatusBadge(activeProject.status)}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Progreso General</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold mb-1">{activeProject.progress}%</div>
            <Progress value={activeProject.progress} className={progressColor(activeProject.progress)} />
            <p className="text-xs text-gray-500 mt-2">
              Última actualización: {activeProject.lastUpdate.toLocaleDateString()}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Tiempo Restante</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold mb-1">{daysRemaining} días</div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 text-orange-500 mr-2" />
              <span className="text-sm">
                Fecha límite: {activeProject.deadline.toLocaleDateString()}
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Experto Asignado</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold mb-1">{activeProject.assignedTo}</div>
            <div className="flex items-center">
              <UserCheck className="h-4 w-4 text-green-500 mr-2" />
              <span className="text-sm">Especialista en {activeProject.subject}</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="overview">
            <Eye className="h-4 w-4 mr-2" />
            General
          </TabsTrigger>
          <TabsTrigger value="phases">
            <Flag className="h-4 w-4 mr-2" />
            Fases
          </TabsTrigger>
          <TabsTrigger value="milestones">
            <CheckCircle className="h-4 w-4 mr-2" />
            Hitos
          </TabsTrigger>
          <TabsTrigger value="history">
            <Clock className="h-4 w-4 mr-2" />
            Historial
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Resumen del Proyecto</CardTitle>
              <CardDescription>Estado general y próximos pasos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-medium mb-3">Progreso por Fases</h4>
                  {activeProject.phases.map(phase => (
                    <div key={phase.id} className="mb-4">
                      <div className="flex justify-between mb-1">
                        <div className="flex items-center">
                          {phase.status === "completed" ? (
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          ) : phase.status === "in_progress" ? (
                            <CircleDashed className="h-4 w-4 text-blue-500 mr-2" />
                          ) : (
                            <CircleDashed className="h-4 w-4 text-gray-300 mr-2" />
                          )}
                          <span className="text-sm">{phase.name}</span>
                        </div>
                        <span className="text-sm font-medium">{phase.progress}%</span>
                      </div>
                      <Progress value={phase.progress} className={progressColor(phase.progress)} />
                    </div>
                  ))}
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-3">Próximos Hitos</h4>
                  <div className="space-y-3">
                    {activeProject.phases
                      .filter(phase => phase.status !== "completed")
                      .flatMap(phase => 
                        phase.milestones
                          .filter(milestone => !milestone.completed)
                          .slice(0, 3)
                          .map(milestone => (
                            <div key={milestone.id} className="flex items-start p-3 bg-gray-50 rounded-md">
                              <div className="shrink-0 mr-3">
                                <CircleDashed className="h-5 w-5 text-blue-500" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">{milestone.name}</p>
                                <p className="text-xs text-gray-500 mt-1">
                                  Fase: {activeProject.phases.find(p => 
                                    p.milestones.some(m => m.id === milestone.id)
                                  )?.name}
                                </p>
                              </div>
                            </div>
                          ))
                      )
                    }
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h4 className="text-sm font-medium mb-3">Información del Trabajo</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-3 bg-gray-50 rounded-md">
                    <div className="flex items-center">
                      <BookOpen className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-sm font-medium">Tipo de Trabajo</span>
                    </div>
                    <p className="text-sm mt-1 ml-6">{activeProject.type}</p>
                  </div>
                  
                  <div className="p-3 bg-gray-50 rounded-md">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-sm font-medium">Fecha de Inicio</span>
                    </div>
                    <p className="text-sm mt-1 ml-6">
                      {activeProject.phases[0].startDate?.toLocaleDateString()}
                    </p>
                  </div>
                  
                  <div className="p-3 bg-gray-50 rounded-md">
                    <div className="flex items-center">
                      <FileText className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-sm font-medium">Asignatura</span>
                    </div>
                    <p className="text-sm mt-1 ml-6">{activeProject.subject}</p>
                  </div>
                  
                  <div className="p-3 bg-gray-50 rounded-md">
                    <div className="flex items-center">
                      <AlertTriangle className="h-4 w-4 text-orange-500 mr-2" />
                      <span className="text-sm font-medium">Fecha Límite</span>
                    </div>
                    <p className="text-sm mt-1 ml-6">
                      {activeProject.deadline.toLocaleDateString()} 
                      <span className="text-orange-500 ml-2">
                        ({daysRemaining} días restantes)
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setShowRatingDialog(true)}>
                <ThumbsUp className="h-4 w-4 mr-2" />
                Valorar Progreso
              </Button>
              
              <Button>
                <MessageSquare className="h-4 w-4 mr-2" />
                Contactar Experto
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="phases" className="space-y-6">
          {activeProject.phases.map((phase, index) => (
            <Card key={phase.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                      <span className="font-medium">{index + 1}</span>
                    </div>
                    <div>
                      <CardTitle>{phase.name}</CardTitle>
                      <CardDescription>{phase.description}</CardDescription>
                    </div>
                  </div>
                  {getStatusBadge(phase.status)}
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-500">Progreso</span>
                    <span className="text-sm font-medium">{phase.progress}%</span>
                  </div>
                  <Progress value={phase.progress} className={progressColor(phase.progress)} />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  {phase.startDate && (
                    <div className="flex items-center">
                      <CalendarIcon className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-sm">
                        Inicio: {phase.startDate.toLocaleDateString()}
                      </span>
                    </div>
                  )}
                  
                  {phase.endDate && (
                    <div className="flex items-center">
                      <Flag className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-sm">
                        Fin: {phase.endDate.toLocaleDateString()}
                      </span>
                    </div>
                  )}
                </div>
                
                <Separator className="my-4" />
                
                <h4 className="text-sm font-medium mb-3">Hitos de la Fase</h4>
                <div className="space-y-2">
                  {phase.milestones.map(milestone => (
                    <div key={milestone.id} className="flex items-center p-2 hover:bg-gray-50 rounded-md">
                      <div
                        className="cursor-pointer flex items-center justify-center h-5 w-5 rounded-md border mr-3"
                        onClick={() => handleMilestoneToggle(phase.id, milestone.id)}
                      >
                        {milestone.completed ? (
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                        ) : null}
                      </div>
                      <span className={`text-sm ${milestone.completed ? 'line-through text-gray-500' : ''}`}>
                        {milestone.name}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                {phase.status === "completed" ? (
                  <div className="bg-green-50 border border-green-200 rounded-md p-3 w-full">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                      <span className="text-sm text-green-800">
                        Fase completada el {phase.endDate?.toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ) : phase.status === "in_progress" ? (
                  <div className="bg-blue-50 border border-blue-200 rounded-md p-3 w-full">
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-blue-500 mr-2" />
                      <span className="text-sm text-blue-800">
                        Fase en progreso - {phase.progress}% completado
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="bg-gray-50 border border-gray-200 rounded-md p-3 w-full">
                    <div className="flex items-center">
                      <CalendarIcon className="h-5 w-5 text-gray-500 mr-2" />
                      <span className="text-sm text-gray-800">
                        Fase programada para iniciar el {phase.startDate?.toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                )}
              </CardFooter>
            </Card>
          ))}
        </TabsContent>
        
        <TabsContent value="milestones">
          <Card>
            <CardHeader>
              <CardTitle>Lista de Hitos</CardTitle>
              <CardDescription>
                Seguimiento de todos los hitos del proyecto
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {activeProject.phases.map((phase) => (
                  <div key={phase.id}>
                    <h3 className="font-medium flex items-center mb-3">
                      <span className={`h-2 w-2 rounded-full mr-2 ${
                        phase.status === 'completed' ? 'bg-green-500' :
                        phase.status === 'in_progress' ? 'bg-blue-500' : 'bg-gray-300'
                      }`}></span>
                      {phase.name}
                      <span className="text-sm text-gray-500 ml-2">
                        ({phase.milestones.filter(m => m.completed).length}/{phase.milestones.length})
                      </span>
                    </h3>
                    <div className="space-y-2 ml-4">
                      {phase.milestones.map(milestone => (
                        <div 
                          key={milestone.id} 
                          className={`p-3 border rounded-md ${
                            milestone.completed ? 'bg-green-50 border-green-200' : 'bg-white'
                          }`}
                        >
                          <div className="flex items-start">
                            <div 
                              className="cursor-pointer flex-shrink-0 mt-0.5"
                              onClick={() => handleMilestoneToggle(phase.id, milestone.id)}
                            >
                              {milestone.completed ? (
                                <CheckCircle className="h-5 w-5 text-green-500" />
                              ) : (
                                <Circle className="h-5 w-5 text-gray-300" />
                              )}
                            </div>
                            <div className="ml-3 flex-1">
                              <div className="flex justify-between">
                                <h4 className={`font-medium ${milestone.completed ? 'line-through text-gray-500' : ''}`}>
                                  {milestone.name}
                                </h4>
                                {milestone.dueDate && (
                                  <span className="text-xs text-gray-500">
                                    Fecha límite: {milestone.dueDate.toLocaleDateString()}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                <Download className="h-4 w-4 mr-2" />
                Exportar Lista de Hitos
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Historial del Proyecto</CardTitle>
              <CardDescription>Registro cronológico de actividades y cambios</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <div className="absolute h-full w-px bg-gray-200 left-2.5 top-0"></div>
                
                <div className="space-y-6 ml-6">
                  {projectHistory.sort((a, b) => b.date.getTime() - a.date.getTime()).map((entry, i) => (
                    <div key={i} className="relative">
                      <div className="absolute w-5 h-5 rounded-full bg-blue-100 border-2 border-blue-500 left-[-1.625rem] top-0"></div>
                      
                      <div className="bg-gray-50 p-4 rounded-lg border">
                        <div className="flex justify-between items-start">
                          <h4 className="font-medium">{entry.action}</h4>
                          <span className="text-xs text-gray-500">
                            {entry.date.toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{entry.details}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {showRatingDialog && (
        <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
          <DialogContent>
            <RatingForm 
              onSubmit={handleRatingSubmit}
              title="Valorar Progreso del Trabajo"
              submitLabel="Enviar Valoración"
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default EnhancedProgressTracker;

function Circle(props: any) {
  return (
    <div className="rounded-full border-2 border-gray-300 w-5 h-5" {...props} />
  );
}
