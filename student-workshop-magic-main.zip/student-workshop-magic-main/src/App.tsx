
import { useEffect, lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { updateMetaTags } from "./utils/seoUtils";
import { LanguageProvider } from "./contexts/LanguageContext";
import { NotificationProvider } from "./components/NotificationProvider";
import { AuthProvider } from "./contexts/AuthContext";

import { Skeleton } from "@/components/ui/skeleton";

// ==========================================
// Route-level code splitting (lazy loading)
// Cada ruta se carga solo cuando el usuario navega a ella,
// reduciendo drásticamente el tamaño del bundle inicial.
// ==========================================
const Index = lazy(() => import("./pages/Index"));
const NotFound = lazy(() => import("./pages/NotFound"));
const WorkReviewSystem = lazy(() => import("./components/WorkReviewSystem"));
const AdminPanel = lazy(() => import("./components/AdminPanel"));
const AdminDashboard = lazy(() => import("./components/AdminDashboard"));
const PrivacyPolicy = lazy(() => import("./pages/PrivacyPolicy"));
const TermsOfService = lazy(() => import("./pages/TermsOfService"));
const RefundPolicy = lazy(() => import("./pages/RefundPolicy"));
const HowItWorks = lazy(() => import("./pages/HowItWorks"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const DocumentLibrary = lazy(() => import("./pages/DocumentLibrary"));
const ResourceLibrary = lazy(() => import("./pages/ResourceLibrary"));
const Checkout = lazy(() => import("./pages/Checkout"));
const ChatBot = lazy(() => import("./components/ChatBot"));
const ReminderService = lazy(() => import("./components/ReminderService"));
const AcercaDe = lazy(() => import("./pages/AcercaDe"));
const Login = lazy(() => import("./pages/Login"));
const Register = lazy(() => import("./pages/Register"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const StudentFeedback = lazy(() => import("./components/StudentFeedback"));
const AcademicTools = lazy(() => import("./pages/AcademicTools"));

// Fallback de carga para rutas
const RouteLoader = () => (
  <div className="min-h-screen flex flex-col items-center justify-center p-8 space-y-4">
    <Skeleton className="w-64 h-8" />
    <Skeleton className="w-48 h-6" />
    <Skeleton className="w-32 h-4" />
  </div>
);

// Configuración QueryClient con mejoras para refetch y manejo de errores
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutos
      gcTime: 10 * 60 * 1000, // 10 minutos (antes cacheTime)
      refetchOnWindowFocus: false,
      retry: 1,
      retryDelay: attempt => Math.min(attempt > 1 ? 2 ** attempt * 1000 : 1000, 30 * 1000),
    },
  },
});

// Mapa de rutas a metadatos SEO para evitar cadena de if-else
const ROUTE_META: Record<string, { title: string; description: string; keywords: string[] }> = {
  "/": {
    title: "StudentHelp | Expertos en Trabajos Académicos",
    description: "Servicio profesional de ayuda con trabajos académicos en Colombia",
    keywords: ["trabajos académicos", "ensayos", "tesis", "Colombia"]
  },
  "/review": {
    title: "Sistema de Control de Calidad | StudentHelp",
    description: "Nuestro sistema de control de calidad para trabajos académicos",
    keywords: ["control de calidad", "revisión académica", "garantía"]
  },
  "/admin": {
    title: "Panel de Administración | StudentHelp",
    description: "Administración de servicios académicos",
    keywords: ["admin", "gestión", "control"]
  },
  "/admin-dashboard": {
    title: "Panel de Administración Avanzado | StudentHelp",
    description: "Administración completa del sistema",
    keywords: ["admin", "gestión", "control", "sistema"]
  },
  "/privacy-policy": {
    title: "Política de Privacidad | StudentHelp",
    description: "Política de privacidad y protección de datos",
    keywords: ["privacidad", "datos personales", "política"]
  },
  "/terms-of-service": {
    title: "Términos de Servicio | StudentHelp",
    description: "Términos y condiciones de nuestros servicios",
    keywords: ["términos", "condiciones", "servicio"]
  },
  "/refund-policy": {
    title: "Política de Reembolsos | StudentHelp",
    description: "Política de reembolsos y devoluciones",
    keywords: ["reembolso", "devolución", "política"]
  },
  "/how-it-works": {
    title: "Cómo Funciona | StudentHelp",
    description: "Descubre cómo funciona nuestro servicio de ayuda académica",
    keywords: ["proceso", "metodología", "ayuda académica"]
  },
  "/dashboard": {
    title: "Mi Cuenta | StudentHelp",
    description: "Gestiona tus proyectos académicos",
    keywords: ["cuenta", "proyectos", "gestión"]
  },
  "/checkout": {
    title: "Checkout | StudentHelp",
    description: "Finaliza tu pedido de trabajo académico",
    keywords: ["pago", "checkout", "finalizar pedido"]
  },
  "/acerca-de": {
    title: "Acerca de Nosotros | StudentHelp",
    description: "Conoce más sobre nuestra misión, visión y servicios",
    keywords: ["misión", "visión", "quiénes somos", "contacto"]
  },
  "/login": {
    title: "Iniciar Sesión | StudentHelp",
    description: "Accede a tu cuenta o al panel de administración",
    keywords: ["login", "iniciar sesión", "acceso", "cuenta"]
  },
  "/register": {
    title: "Registrarse | StudentHelp",
    description: "Crea una cuenta para gestionar tus proyectos",
    keywords: ["registro", "cuenta", "crear"]
  },
  "/reset-password": {
    title: "Restablecer Contraseña | StudentHelp",
    description: "Restablece tu contraseña de acceso",
    keywords: ["contraseña", "restablecer", "recuperar"]
  },
  "/document-library": {
    title: "Biblioteca de Documentos | StudentHelp",
    description: "Gestiona tus materiales académicos y archivos",
    keywords: ["documentos", "biblioteca", "materiales", "archivos"]
  },
  "/feedback": {
    title: "Valoraciones y Opiniones | StudentHelp",
    description: "Opiniones y calificaciones de nuestros estudiantes",
    keywords: ["valoraciones", "opiniones", "calificaciones", "feedback"]
  },
  "/academic-tools": {
    title: "Herramientas Académicas | StudentHelp",
    description: "Conjunto integrado de herramientas para apoyar tu éxito académico",
    keywords: ["herramientas", "calendario", "chat", "tutores", "progreso", "recomendaciones"]
  },
  "/resource-library": {
    title: "Biblioteca de Recursos | StudentHelp",
    description: "Guías, plantillas y ejemplos para tus trabajos académicos",
    keywords: ["recursos", "guías", "plantillas", "ejemplos", "académicos"]
  },
};

const TitleUpdater = () => {
  const location = useLocation();

  useEffect(() => {
    const meta = ROUTE_META[location.pathname] || ROUTE_META["/"];
    document.title = meta.title;
    updateMetaTags(meta.title, meta.description, meta.keywords);
  }, [location]);

  return null;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <AuthProvider>
        <NotificationProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <TitleUpdater />
              <Suspense fallback={<RouteLoader />}>
                <Routes>
                  <Route path="/" element={<Index />} />
                  <Route path="/review" element={<WorkReviewSystem />} />
                  <Route path="/admin" element={<AdminPanel />} />
                  <Route path="/admin-dashboard" element={<AdminDashboard />} />
                  <Route path="/privacy-policy" element={<PrivacyPolicy />} />
                  <Route path="/terms-of-service" element={<TermsOfService />} />
                  <Route path="/refund-policy" element={<RefundPolicy />} />
                  <Route path="/how-it-works" element={<HowItWorks />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/document-library" element={<DocumentLibrary />} />
                  <Route path="/resource-library" element={<ResourceLibrary />} />
                  <Route path="/checkout" element={<Checkout />} />
                  <Route path="/acerca-de" element={<AcercaDe />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/register" element={<Register />} />
                  <Route path="/reset-password" element={<ResetPassword />} />
                  <Route path="/feedback" element={<StudentFeedback />} />
                  <Route path="/academic-tools" element={<AcademicTools />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </Suspense>
              <Suspense fallback={null}>
                <ChatBot />
                <ReminderService />
              </Suspense>
              
            </BrowserRouter>
          </TooltipProvider>
        </NotificationProvider>
      </AuthProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
